// Verilog netlist written by  TetraMAX (TM)  U-2003.06-1-i030623_113114 
// Date: Fri Sep 19 09:25:49 2003

`celldefine
module ora311d4 (C3, C2, C1, B, A, Z);
input C3, C2, C1, B, A;
output Z;
wire g_3_out;
   or or0 (g_3_out, C1, C3, C2);
   and and1 (Z, B, A, g_3_out);
endmodule
`endcelldefine

`celldefine
module ora211d4 (C2, C1, B, A, Z);
input C2, C1, B, A;
output Z;
wire g_1_out, g_2_out;
   and and0 (g_1_out, B, A, C2);
   and and1 (g_2_out, B, A, C1);
   or or2 (Z, g_1_out, g_2_out);
endmodule
`endcelldefine

`celldefine
module ora311d2 (C3, C2, C1, B, A, Z);
input C3, C2, C1, B, A;
output Z;
wire g_3_out;
   or or0 (g_3_out, C1, C3, C2);
   and and1 (Z, B, A, g_3_out);
endmodule
`endcelldefine

`celldefine
module ora211d2 (C2, C1, B, A, Z);
input C2, C1, B, A;
output Z;
wire g_1_out, g_2_out;
   and and0 (g_1_out, B, A, C2);
   and and1 (g_2_out, B, A, C1);
   or or2 (Z, g_1_out, g_2_out);
endmodule
`endcelldefine

`celldefine
module ora311d1 (C3, C2, C1, B, A, Z);
input C3, C2, C1, B, A;
output Z;
wire g_3_out;
   or or0 (g_3_out, C1, C3, C2);
   and and1 (Z, B, A, g_3_out);
endmodule
`endcelldefine

`celldefine
module ora211d1 (C2, C1, B, A, Z);
input C2, C1, B, A;
output Z;
wire g_1_out, g_2_out;
   and and0 (g_1_out, B, A, C2);
   and and1 (g_2_out, B, A, C1);
   or or2 (Z, g_1_out, g_2_out);
endmodule
`endcelldefine

`celldefine
module ora31d4 (B3, B2, B1, A, Z);
input B3, B2, B1, A;
output Z;
wire g_2_out;
   or or0 (g_2_out, B2, B1, B3);
   and and1 (Z, A, g_2_out);
endmodule
`endcelldefine

`celldefine
module ora31d2 (B3, B2, B1, A, Z);
input B3, B2, B1, A;
output Z;
wire g_2_out;
   or or0 (g_2_out, B2, B1, B3);
   and and1 (Z, A, g_2_out);
endmodule
`endcelldefine

`celldefine
module ora31d1 (B3, B2, B1, A, Z);
input B3, B2, B1, A;
output Z;
wire g_2_out;
   or or0 (g_2_out, B2, B1, B3);
   and and1 (Z, A, g_2_out);
endmodule
`endcelldefine

`celldefine
module ora21d4 (B2, B1, A, Z);
input B2, B1, A;
output Z;
wire g_2_out;
   or or0 (g_2_out, B1, B2);
   and and1 (Z, A, g_2_out);
endmodule
`endcelldefine

`celldefine
module ora21d2 (B2, B1, A, Z);
input B2, B1, A;
output Z;
wire g_2_out;
   or or0 (g_2_out, B1, B2);
   and and1 (Z, A, g_2_out);
endmodule
`endcelldefine

`celldefine
module ora21d1 (B2, B1, A, Z);
input B2, B1, A;
output Z;
wire g_2_out;
   or or0 (g_2_out, B1, B2);
   and and1 (Z, A, g_2_out);
endmodule
`endcelldefine

`celldefine
module nr23d4 (A1, A2, A3, ZN);
input A1, A2, A3;
output ZN;
wire not_A3;
   not not0 (not_A3, A3);
   and and1 (ZN, not_A3, A2, A1);
endmodule
`endcelldefine

`celldefine
module nr23d2 (A1, A2, A3, ZN);
input A1, A2, A3;
output ZN;
wire not_A3;
   not not0 (not_A3, A3);
   and and1 (ZN, not_A3, A2, A1);
endmodule
`endcelldefine

`celldefine
module nr23d1 (A1, A2, A3, ZN);
input A1, A2, A3;
output ZN;
wire not_A3;
   not not0 (not_A3, A3);
   and and1 (ZN, not_A3, A2, A1);
endmodule
`endcelldefine

`celldefine
module nd23d4 (A1, A2, A3, ZN);
input A1, A2, A3;
output ZN;
wire not_A3;
   not not0 (not_A3, A3);
   or or1 (ZN, not_A3, A2, A1);
endmodule
`endcelldefine

`celldefine
module nd23d2 (A1, A2, A3, ZN);
input A1, A2, A3;
output ZN;
wire not_A3;
   not not0 (not_A3, A3);
   or or1 (ZN, not_A3, A2, A1);
endmodule
`endcelldefine

`celldefine
module nd23d1 (A1, A2, A3, ZN);
input A1, A2, A3;
output ZN;
wire not_A3;
   not not0 (not_A3, A3);
   or or1 (ZN, not_A3, A2, A1);
endmodule
`endcelldefine

`celldefine
module aor211d4 (C2, C1, B, A, Z);
input C2, C1, B, A;
output Z;
wire g_1_out, g_2_out;
   or or0 (g_1_out, B, A, C1);
   or or1 (g_2_out, B, A, C2);
   and and2 (Z, g_1_out, g_2_out);
endmodule
`endcelldefine

`celldefine
module aor221d4 (C2, C1, B2, B1, A, Z);
input C2, C1, B2, B1, A;
output Z;
wire g_1_out, g_2_out;
   and and0 (g_1_out, C1, C2);
   and and1 (g_2_out, B2, B1);
   or or2 (Z, g_1_out, g_2_out, A);
endmodule
`endcelldefine

`celldefine
module aor222d4 (C2, C1, B2, B1, A2, A1, Z);
input C2, C1, B2, B1, A2, A1;
output Z;
wire g_1_out, g_2_out, g_3_out;
   and and0 (g_1_out, C2, C1);
   and and1 (g_2_out, B2, B1);
   and and2 (g_3_out, A2, A1);
   or or3 (Z, g_1_out, g_2_out, g_3_out);
endmodule
`endcelldefine

`celldefine
module aor311d4 (C3, C2, C1, B, A, Z);
input C3, C2, C1, B, A;
output Z;
wire g_1_out;
   and and0 (g_1_out, C1, C3, C2);
   or or1 (Z, g_1_out, B, A);
endmodule
`endcelldefine

`celldefine
module aor211d2 (C2, C1, B, A, Z);
input C2, C1, B, A;
output Z;
wire g_1_out, g_2_out;
   or or0 (g_1_out, B, A, C1);
   or or1 (g_2_out, B, A, C2);
   and and2 (Z, g_1_out, g_2_out);
endmodule
`endcelldefine

`celldefine
module aor221d2 (C2, C1, B2, B1, A, Z);
input C2, C1, B2, B1, A;
output Z;
wire g_1_out, g_2_out;
   and and0 (g_1_out, C1, C2);
   and and1 (g_2_out, B2, B1);
   or or2 (Z, g_1_out, g_2_out, A);
endmodule
`endcelldefine

`celldefine
module aor222d2 (C2, C1, B2, B1, A2, A1, Z);
input C2, C1, B2, B1, A2, A1;
output Z;
wire g_1_out, g_2_out, g_3_out;
   and and0 (g_1_out, C2, C1);
   and and1 (g_2_out, B2, B1);
   and and2 (g_3_out, A2, A1);
   or or3 (Z, g_1_out, g_2_out, g_3_out);
endmodule
`endcelldefine

`celldefine
module aor311d2 (C3, C2, C1, B, A, Z);
input C3, C2, C1, B, A;
output Z;
wire g_1_out;
   and and0 (g_1_out, C1, C3, C2);
   or or1 (Z, g_1_out, B, A);
endmodule
`endcelldefine

`celldefine
module aor211d1 (C2, C1, B, A, Z);
input C2, C1, B, A;
output Z;
wire g_1_out, g_2_out;
   or or0 (g_1_out, B, A, C1);
   or or1 (g_2_out, B, A, C2);
   and and2 (Z, g_1_out, g_2_out);
endmodule
`endcelldefine

`celldefine
module aor221d1 (C2, C1, B2, B1, A, Z);
input C2, C1, B2, B1, A;
output Z;
wire g_1_out, g_2_out;
   and and0 (g_1_out, C1, C2);
   and and1 (g_2_out, B2, B1);
   or or2 (Z, g_1_out, g_2_out, A);
endmodule
`endcelldefine

`celldefine
module aor222d1 (C2, C1, B2, B1, A2, A1, Z);
input C2, C1, B2, B1, A2, A1;
output Z;
wire g_1_out, g_2_out, g_3_out;
   and and0 (g_1_out, C2, C1);
   and and1 (g_2_out, B2, B1);
   and and2 (g_3_out, A2, A1);
   or or3 (Z, g_1_out, g_2_out, g_3_out);
endmodule
`endcelldefine

`celldefine
module aor311d1 (C3, C2, C1, B, A, Z);
input C3, C2, C1, B, A;
output Z;
wire g_1_out;
   and and0 (g_1_out, C1, C3, C2);
   or or1 (Z, g_1_out, B, A);
endmodule
`endcelldefine

`celldefine
module aor21d1 (B2, B1, A, Z);
input B2, B1, A;
output Z;
wire g_1_out;
   and and0 (g_1_out, B1, B2);
   or or1 (Z, g_1_out, A);
endmodule
`endcelldefine

`celldefine
module aor21d2 (B2, B1, A, Z);
input B2, B1, A;
output Z;
wire g_1_out;
   and and0 (g_1_out, B1, B2);
   or or1 (Z, g_1_out, A);
endmodule
`endcelldefine

`celldefine
module aor21d4 (B2, B1, A, Z);
input B2, B1, A;
output Z;
wire g_1_out;
   and and0 (g_1_out, B1, B2);
   or or1 (Z, g_1_out, A);
endmodule
`endcelldefine

`celldefine
module aor22d1 (B2, B1, A2, A1, Z);
input B2, B1, A2, A1;
output Z;
wire g_1_out, g_2_out;
   and and0 (g_1_out, B2, B1);
   and and1 (g_2_out, A2, A1);
   or or2 (Z, g_1_out, g_2_out);
endmodule
`endcelldefine

`celldefine
module aor22d2 (B2, B1, A2, A1, Z);
input B2, B1, A2, A1;
output Z;
wire g_1_out, g_2_out;
   and and0 (g_1_out, B2, B1);
   and and1 (g_2_out, A2, A1);
   or or2 (Z, g_1_out, g_2_out);
endmodule
`endcelldefine

`celldefine
module aor22d4 (B2, B1, A2, A1, Z);
input B2, B1, A2, A1;
output Z;
wire g_1_out, g_2_out;
   and and0 (g_1_out, B2, B1);
   and and1 (g_2_out, A2, A1);
   or or2 (Z, g_1_out, g_2_out);
endmodule
`endcelldefine

`celldefine
module aor31d1 (B3, B2, B1, A, Z);
input B3, B2, B1, A;
output Z;
wire g_1_out;
   and and0 (g_1_out, B2, B1, B3);
   or or1 (Z, g_1_out, A);
endmodule
`endcelldefine

`celldefine
module aor31d2 (B3, B2, B1, A, Z);
input B3, B2, B1, A;
output Z;
wire g_1_out;
   and and0 (g_1_out, B2, B1, B3);
   or or1 (Z, g_1_out, A);
endmodule
`endcelldefine

`celldefine
module aor31d4 (B3, B2, B1, A, Z);
input B3, B2, B1, A;
output Z;
wire g_1_out;
   and and0 (g_1_out, B2, B1, B3);
   or or1 (Z, g_1_out, A);
endmodule
`endcelldefine

`celldefine
module s_seprq2 (Q, CP, SC, ENN, SDN, D, SD, notifier);
input CP, SC, ENN, SDN, D, SD, notifier;
output Q;
wire _mux1, _mux2;
   _DFF _dff0 (!SDN, 1'b0, CP, _mux2, Q);
   _MUX _mux1 (ENN, !D, !Q, _mux1);
   _MUX _mux2 (SC, !_mux1, SD, _mux2);
endmodule
`endcelldefine

`celldefine
module seprq2 (CP, SDN, ENN, D, SC, SD, Q);
input CP, SDN, ENN, D, SC, SD;
output Q;
wire notifier, SDN_buf, SC_buf, ENN_buf, vcond1, vcond_SDN_vio, vcond_ENN_vio,
       vcond_D_vio, vcond2;
reg notifier;
   s_seprq2 s_seprq20 (Q, CP, SC, ENN, SDN, D, SD, notifier);
   buf buf1 (SDN_buf, SDN);
   buf buf2 (SC_buf, SC);
   buf buf3 (ENN_buf, ENN);
   and _and4 (vcond1, SDN_buf, SC_buf);
   or _or5 (vcond_SDN_vio, ENN_buf, SC_buf);
   and _and6 (vcond_ENN_vio, SDN_buf, SC_buf);
   and _and7 (vcond_D_vio, SDN_buf, SC_buf, ENN_buf);
   and _and8 (vcond2, SDN_buf, SC_buf);
endmodule
`endcelldefine

`celldefine
module s_seprq1 (Q, CP, SC, ENN, SDN, D, SD, notifier);
input CP, SC, ENN, SDN, D, SD, notifier;
output Q;
wire _mux1, _mux2;
   _DFF _dff0 (!SDN, 1'b0, CP, _mux2, Q);
   _MUX _mux1 (ENN, !D, !Q, _mux1);
   _MUX _mux2 (SC, !_mux1, SD, _mux2);
endmodule
`endcelldefine

`celldefine
module seprq1 (CP, SDN, ENN, D, SC, SD, Q);
input CP, SDN, ENN, D, SC, SD;
output Q;
wire notifier, SDN_buf, SC_buf, ENN_buf, vcond1, vcond_SDN_vio, vcond_ENN_vio,
       vcond_D_vio, vcond2;
reg notifier;
   s_seprq1 s_seprq10 (Q, CP, SC, ENN, SDN, D, SD, notifier);
   buf buf1 (SDN_buf, SDN);
   buf buf2 (SC_buf, SC);
   buf buf3 (ENN_buf, ENN);
   and _and4 (vcond1, SDN_buf, SC_buf);
   or _or5 (vcond_SDN_vio, ENN_buf, SC_buf);
   and _and6 (vcond_ENN_vio, SDN_buf, SC_buf);
   and _and7 (vcond_D_vio, SDN_buf, SC_buf, ENN_buf);
   and _and8 (vcond2, SDN_buf, SC_buf);
endmodule
`endcelldefine

`celldefine
module U_FD_P_SB_NO (Q, D, CP, SB, NOTIFIER_REG);
input D, CP, SB, NOTIFIER_REG;
output Q;
   _DFF _dff0 (!SB, 1'b0, CP, D, Q);
endmodule
`endcelldefine

`celldefine
module U_MUX_2_1 (Q, A, B, SL);
input A, B, SL;
output Q;
   _MUX _mux0 (SL, A, B, Q);
endmodule
`endcelldefine

`celldefine
module sdprb2 (D, SD, SC, CP, SDN, Q, QN);
input D, SD, SC, CP, SDN;
output Q, QN;
wire notifier, buf_Q, mux_out, SC_buf, SDN_buf, vcond1, vcond2;
reg notifier;
   U_FD_P_SB_NO U_FD_P_SB_NO0 (buf_Q, mux_out, CP, SDN, notifier);
   U_MUX_2_1 U_MUX_2_11 (mux_out, D, SD, SC);
   buf buf2 (Q, buf_Q);
   not not3 (QN, buf_Q);
   buf buf4 (SC_buf, SC);
   buf buf5 (SDN_buf, SDN);
   and _and6 (vcond1, SC_buf, SDN_buf);
   and _and7 (vcond2, SC_buf, SDN_buf);
endmodule
`endcelldefine

`celldefine
module sdprb1 (D, SD, SC, CP, SDN, Q, QN);
input D, SD, SC, CP, SDN;
output Q, QN;
wire notifier, buf_Q, mux_out, SC_buf, SDN_buf, vcond1, vcond2;
reg notifier;
   U_FD_P_SB_NO U_FD_P_SB_NO0 (buf_Q, mux_out, CP, SDN, notifier);
   U_MUX_2_1 U_MUX_2_11 (mux_out, D, SD, SC);
   buf buf2 (Q, buf_Q);
   not not3 (QN, buf_Q);
   buf buf4 (SC_buf, SC);
   buf buf5 (SDN_buf, SDN);
   and _and6 (vcond1, SC_buf, SDN_buf);
   and _and7 (vcond2, SC_buf, SDN_buf);
endmodule
`endcelldefine

`celldefine
module dfprb2 (D, CP, SDN, Q, QN);
input D, CP, SDN;
output Q, QN;
wire notifier, buf_Q;
reg notifier;
   U_FD_P_SB_NO U_FD_P_SB_NO0 (buf_Q, D, CP, SDN, notifier);
   buf buf1 (Q, buf_Q);
   not not2 (QN, buf_Q);
endmodule
`endcelldefine

`celldefine
module dfprb1 (D, CP, SDN, Q, QN);
input D, CP, SDN;
output Q, QN;
wire notifier, buf_Q;
reg notifier;
   U_FD_P_SB_NO U_FD_P_SB_NO0 (buf_Q, D, CP, SDN, notifier);
   buf buf1 (Q, buf_Q);
   not not2 (QN, buf_Q);
endmodule
`endcelldefine

`celldefine
module U_FD_N_SB_NO (Q, D, CP, SB, NOTIFIER_REG);
input D, CP, SB, NOTIFIER_REG;
output Q;
   _DFF _dff0 (!SB, 1'b0, !CP, D, Q);
endmodule
`endcelldefine

`celldefine
module dfpfb2 (D, CPN, SDN, Q, QN);
input D, CPN, SDN;
output Q, QN;
wire notifier, buf_Q;
reg notifier;
   U_FD_N_SB_NO U_FD_N_SB_NO0 (buf_Q, D, CPN, SDN, notifier);
   buf buf1 (Q, buf_Q);
   not not2 (QN, buf_Q);
endmodule
`endcelldefine

`celldefine
module dfpfb1 (D, CPN, SDN, Q, QN);
input D, CPN, SDN;
output Q, QN;
wire notifier, buf_Q;
reg notifier;
   U_FD_N_SB_NO U_FD_N_SB_NO0 (buf_Q, D, CPN, SDN, notifier);
   buf buf1 (Q, buf_Q);
   not not2 (QN, buf_Q);
endmodule
`endcelldefine

`celldefine
module s_deprq2 (Q, CP, ENN, SDN, D, notifier);
input CP, ENN, SDN, D, notifier;
output Q;
wire _mux1;
   _DFF _dff0 (!SDN, 1'b0, CP, _mux1, Q);
   _MUX _mux1 (ENN, D, Q, _mux1);
endmodule
`endcelldefine

`celldefine
module deprq2 (CP, SDN, D, ENN, Q);
input CP, SDN, D, ENN;
output Q;
wire CP_buf, SDN_buf, D_buf, ENN_buf, BOOL_OUT, _or5, _and4, notifier,
       vcond1;
reg notifier;
   buf buf0 (CP_buf, CP);
   buf buf1 (SDN_buf, SDN);
   buf buf2 (D_buf, D);
   buf buf3 (ENN_buf, ENN);
   and _and4 (_and4, !ENN_buf, D_buf, !ENN_buf);
   or _or5 (_or5, !Q, !ENN_buf);
   or _or6 (BOOL_OUT, _and4, !_or5);
   s_deprq2 s_deprq27 (Q, CP, ENN, SDN, D, notifier);
   and _and8 (vcond1, SDN_buf, ENN_buf);
endmodule
`endcelldefine

`celldefine
module s_deprq1 (Q, CP, ENN, SDN, D, notifier);
input CP, ENN, SDN, D, notifier;
output Q;
wire _mux1;
   _DFF _dff0 (!SDN, 1'b0, CP, _mux1, Q);
   _MUX _mux1 (ENN, D, Q, _mux1);
endmodule
`endcelldefine

`celldefine
module deprq1 (CP, SDN, D, ENN, Q);
input CP, SDN, D, ENN;
output Q;
wire CP_buf, SDN_buf, D_buf, ENN_buf, BOOL_OUT, _or5, _and4, notifier,
       vcond1;
reg notifier;
   buf buf0 (CP_buf, CP);
   buf buf1 (SDN_buf, SDN);
   buf buf2 (D_buf, D);
   buf buf3 (ENN_buf, ENN);
   and _and4 (_and4, !ENN_buf, D_buf, !ENN_buf);
   or _or5 (_or5, !Q, !ENN_buf);
   or _or6 (BOOL_OUT, _and4, !_or5);
   s_deprq1 s_deprq17 (Q, CP, ENN, SDN, D, notifier);
   and _and8 (vcond1, SDN_buf, ENN_buf);
endmodule
`endcelldefine

`celldefine
module s_depfq2 (Q, CPN, ENN, SDN, D, notifier);
input CPN, ENN, SDN, D, notifier;
output Q;
wire _mux1;
   _DFF _dff0 (!SDN, 1'b0, !CPN, _mux1, Q);
   _MUX _mux1 (ENN, D, Q, _mux1);
endmodule
`endcelldefine

`celldefine
module depfq2 (CPN, SDN, D, ENN, Q);
input CPN, SDN, D, ENN;
output Q;
wire CPN_buf, SDN_buf, D_buf, ENN_buf, BOOL_OUT, _or5, _and4, notifier,
       vcond1;
reg notifier;
   buf buf0 (CPN_buf, CPN);
   buf buf1 (SDN_buf, SDN);
   buf buf2 (D_buf, D);
   buf buf3 (ENN_buf, ENN);
   and _and4 (_and4, !ENN_buf, D_buf, !ENN_buf);
   or _or5 (_or5, !Q, !ENN_buf);
   or _or6 (BOOL_OUT, _and4, !_or5);
   s_depfq2 s_depfq27 (Q, CPN, ENN, SDN, D, notifier);
   and _and8 (vcond1, SDN_buf, ENN_buf);
endmodule
`endcelldefine

`celldefine
module s_depfq1 (Q, CPN, ENN, SDN, D, notifier);
input CPN, ENN, SDN, D, notifier;
output Q;
wire _mux1;
   _DFF _dff0 (!SDN, 1'b0, !CPN, _mux1, Q);
   _MUX _mux1 (ENN, D, Q, _mux1);
endmodule
`endcelldefine

`celldefine
module depfq1 (CPN, SDN, D, ENN, Q);
input CPN, SDN, D, ENN;
output Q;
wire CPN_buf, SDN_buf, D_buf, ENN_buf, BOOL_OUT, _or5, _and4, notifier,
       vcond1;
reg notifier;
   buf buf0 (CPN_buf, CPN);
   buf buf1 (SDN_buf, SDN);
   buf buf2 (D_buf, D);
   buf buf3 (ENN_buf, ENN);
   and _and4 (_and4, !ENN_buf, D_buf, !ENN_buf);
   or _or5 (_or5, !Q, !ENN_buf);
   or _or6 (BOOL_OUT, _and4, !_or5);
   s_depfq1 s_depfq17 (Q, CPN, ENN, SDN, D, notifier);
   and _and8 (vcond1, SDN_buf, ENN_buf);
endmodule
`endcelldefine

`celldefine
module s_seprq4 (Q, CP, SC, ENN, SDN, D, SD, notifier);
input CP, SC, ENN, SDN, D, SD, notifier;
output Q;
wire _mux1, _mux2;
   _DFF _dff0 (!SDN, 1'b0, CP, _mux2, Q);
   _MUX _mux1 (ENN, !D, !Q, _mux1);
   _MUX _mux2 (SC, !_mux1, SD, _mux2);
endmodule
`endcelldefine

`celldefine
module seprq4 (CP, SDN, ENN, D, SC, SD, Q);
input CP, SDN, ENN, D, SC, SD;
output Q;
wire notifier, SDN_buf, SC_buf, ENN_buf, vcond1, vcond_SDN_vio, vcond_ENN_vio,
       vcond_D_vio, vcond2;
reg notifier;
   s_seprq4 s_seprq40 (Q, CP, SC, ENN, SDN, D, SD, notifier);
   buf buf1 (SDN_buf, SDN);
   buf buf2 (SC_buf, SC);
   buf buf3 (ENN_buf, ENN);
   and _and4 (vcond1, SDN_buf, SC_buf);
   or _or5 (vcond_SDN_vio, ENN_buf, SC_buf);
   and _and6 (vcond_ENN_vio, SDN_buf, SC_buf);
   and _and7 (vcond_D_vio, SDN_buf, SC_buf, ENN_buf);
   and _and8 (vcond2, SDN_buf, SC_buf);
endmodule
`endcelldefine

`celldefine
module s_sepfq4 (Q, CPN, SC, ENN, SDN, D, SD, notifier);
input CPN, SC, ENN, SDN, D, SD, notifier;
output Q;
wire _mux1, _mux2;
   _DFF _dff0 (!SDN, 1'b0, !CPN, _mux2, Q);
   _MUX _mux1 (ENN, !D, !Q, _mux1);
   _MUX _mux2 (SC, !_mux1, SD, _mux2);
endmodule
`endcelldefine

`celldefine
module sepfq4 (CPN, SDN, ENN, D, SC, SD, Q);
input CPN, SDN, ENN, D, SC, SD;
output Q;
wire notifier, SDN_buf, SC_buf, ENN_buf, vcond1, vcond_SDN_vio, vcond_ENN_vio,
       vcond_D_vio, vcond2;
reg notifier;
   s_sepfq4 s_sepfq40 (Q, CPN, SC, ENN, SDN, D, SD, notifier);
   buf buf1 (SDN_buf, SDN);
   buf buf2 (SC_buf, SC);
   buf buf3 (ENN_buf, ENN);
   and _and4 (vcond1, SDN_buf, SC_buf);
   or _or5 (vcond_SDN_vio, ENN_buf, SC_buf);
   and _and6 (vcond_ENN_vio, SDN_buf, SC_buf);
   and _and7 (vcond_D_vio, SDN_buf, SC_buf, ENN_buf);
   and _and8 (vcond2, SDN_buf, SC_buf);
endmodule
`endcelldefine

`celldefine
module s_sepfq2 (Q, CPN, SC, ENN, SDN, D, SD, notifier);
input CPN, SC, ENN, SDN, D, SD, notifier;
output Q;
wire _mux1, _mux2;
   _DFF _dff0 (!SDN, 1'b0, !CPN, _mux2, Q);
   _MUX _mux1 (ENN, !D, !Q, _mux1);
   _MUX _mux2 (SC, !_mux1, SD, _mux2);
endmodule
`endcelldefine

`celldefine
module sepfq2 (CPN, SDN, ENN, D, SC, SD, Q);
input CPN, SDN, ENN, D, SC, SD;
output Q;
wire notifier, SDN_buf, SC_buf, ENN_buf, vcond1, vcond_SDN_vio, vcond_ENN_vio,
       vcond_D_vio, vcond2;
reg notifier;
   s_sepfq2 s_sepfq20 (Q, CPN, SC, ENN, SDN, D, SD, notifier);
   buf buf1 (SDN_buf, SDN);
   buf buf2 (SC_buf, SC);
   buf buf3 (ENN_buf, ENN);
   and _and4 (vcond1, SDN_buf, SC_buf);
   or _or5 (vcond_SDN_vio, ENN_buf, SC_buf);
   and _and6 (vcond_ENN_vio, SDN_buf, SC_buf);
   and _and7 (vcond_D_vio, SDN_buf, SC_buf, ENN_buf);
   and _and8 (vcond2, SDN_buf, SC_buf);
endmodule
`endcelldefine

`celldefine
module s_sepfq1 (Q, CPN, SC, ENN, SDN, D, SD, notifier);
input CPN, SC, ENN, SDN, D, SD, notifier;
output Q;
wire _mux1, _mux2;
   _DFF _dff0 (!SDN, 1'b0, !CPN, _mux2, Q);
   _MUX _mux1 (ENN, !D, !Q, _mux1);
   _MUX _mux2 (SC, !_mux1, SD, _mux2);
endmodule
`endcelldefine

`celldefine
module sepfq1 (CPN, SDN, ENN, D, SC, SD, Q);
input CPN, SDN, ENN, D, SC, SD;
output Q;
wire notifier, SDN_buf, SC_buf, ENN_buf, vcond1, vcond_SDN_vio, vcond_ENN_vio,
       vcond_D_vio, vcond2;
reg notifier;
   s_sepfq1 s_sepfq10 (Q, CPN, SC, ENN, SDN, D, SD, notifier);
   buf buf1 (SDN_buf, SDN);
   buf buf2 (SC_buf, SC);
   buf buf3 (ENN_buf, ENN);
   and _and4 (vcond1, SDN_buf, SC_buf);
   or _or5 (vcond_SDN_vio, ENN_buf, SC_buf);
   and _and6 (vcond_ENN_vio, SDN_buf, SC_buf);
   and _and7 (vcond_D_vio, SDN_buf, SC_buf, ENN_buf);
   and _and8 (vcond2, SDN_buf, SC_buf);
endmodule
`endcelldefine

`celldefine
module sdprb4 (D, SD, SC, CP, SDN, Q, QN);
input D, SD, SC, CP, SDN;
output Q, QN;
wire notifier, buf_Q, mux_out, SC_buf, SDN_buf, vcond1, vcond2;
reg notifier;
   U_FD_P_SB_NO U_FD_P_SB_NO0 (buf_Q, mux_out, CP, SDN, notifier);
   U_MUX_2_1 U_MUX_2_11 (mux_out, D, SD, SC);
   buf buf2 (Q, buf_Q);
   not not3 (QN, buf_Q);
   buf buf4 (SC_buf, SC);
   buf buf5 (SDN_buf, SDN);
   and _and6 (vcond1, SC_buf, SDN_buf);
   and _and7 (vcond2, SC_buf, SDN_buf);
endmodule
`endcelldefine

`celldefine
module sdpfb4 (D, SD, SC, CPN, SDN, Q, QN);
input D, SD, SC, CPN, SDN;
output Q, QN;
wire notifier, buf_Q, mux_out, SC_buf, SDN_buf, vcond1, vcond2;
reg notifier;
   U_FD_N_SB_NO U_FD_N_SB_NO0 (buf_Q, mux_out, CPN, SDN, notifier);
   U_MUX_2_1 U_MUX_2_11 (mux_out, D, SD, SC);
   buf buf2 (Q, buf_Q);
   not not3 (QN, buf_Q);
   buf buf4 (SC_buf, SC);
   buf buf5 (SDN_buf, SDN);
   and _and6 (vcond1, SC_buf, SDN_buf);
   and _and7 (vcond2, SC_buf, SDN_buf);
endmodule
`endcelldefine

`celldefine
module sdpfb2 (D, SD, SC, CPN, SDN, Q, QN);
input D, SD, SC, CPN, SDN;
output Q, QN;
wire notifier, buf_Q, mux_out, SC_buf, SDN_buf, vcond1, vcond2;
reg notifier;
   U_FD_N_SB_NO U_FD_N_SB_NO0 (buf_Q, mux_out, CPN, SDN, notifier);
   U_MUX_2_1 U_MUX_2_11 (mux_out, D, SD, SC);
   buf buf2 (Q, buf_Q);
   not not3 (QN, buf_Q);
   buf buf4 (SC_buf, SC);
   buf buf5 (SDN_buf, SDN);
   and _and6 (vcond1, SC_buf, SDN_buf);
   and _and7 (vcond2, SC_buf, SDN_buf);
endmodule
`endcelldefine

`celldefine
module sdpfb1 (D, SD, SC, CPN, SDN, Q, QN);
input D, SD, SC, CPN, SDN;
output Q, QN;
wire notifier, buf_Q, mux_out, SC_buf, SDN_buf, vcond1, vcond2;
reg notifier;
   U_FD_N_SB_NO U_FD_N_SB_NO0 (buf_Q, mux_out, CPN, SDN, notifier);
   U_MUX_2_1 U_MUX_2_11 (mux_out, D, SD, SC);
   buf buf2 (Q, buf_Q);
   not not3 (QN, buf_Q);
   buf buf4 (SC_buf, SC);
   buf buf5 (SDN_buf, SDN);
   and _and6 (vcond1, SC_buf, SDN_buf);
   and _and7 (vcond2, SC_buf, SDN_buf);
endmodule
`endcelldefine

`celldefine
module adp1d4 (A, B, CI, S, P, CO);
input A, B, CI;
output S, P, CO;
wire A_buf, B_buf, CI_buf, S_OUT, _and4, _and3, _and6, _and7, P_OUT, _and10,
       _and9, CO_OUT, _and14, _and13, _and16;
   buf buf0 (A_buf, A);
   buf buf1 (B_buf, B);
   buf buf2 (CI_buf, CI);
   and _and3 (_and3, !CI_buf, !B_buf, A_buf);
   and _and4 (_and4, !CI_buf, B_buf, !A_buf);
   or _or5 (S_OUT, _and3, _and4, _and6, _and7);
   and _and6 (_and6, CI_buf, B_buf, A_buf);
   and _and7 (_and7, CI_buf, !B_buf, !A_buf);
   buf buf8 (S, S_OUT);
   and _and9 (_and9, !B_buf, A_buf);
   and _and10 (_and10, B_buf, !A_buf);
   or _or11 (P_OUT, _and9, _and10);
   buf buf12 (P, P_OUT);
   and _and13 (_and13, B_buf, A_buf);
   and _and14 (_and14, CI_buf, B_buf);
   or _or15 (CO_OUT, _and13, _and14, _and16);
   and _and16 (_and16, CI_buf, A_buf);
   buf buf17 (CO, CO_OUT);
endmodule
`endcelldefine

`celldefine
module s_depfq4 (Q, CPN, ENN, SDN, D, notifier);
input CPN, ENN, SDN, D, notifier;
output Q;
wire _mux1;
   _DFF _dff0 (!SDN, 1'b0, !CPN, _mux1, Q);
   _MUX _mux1 (ENN, D, Q, _mux1);
endmodule
`endcelldefine

`celldefine
module depfq4 (CPN, SDN, D, ENN, Q);
input CPN, SDN, D, ENN;
output Q;
wire CPN_buf, SDN_buf, D_buf, ENN_buf, BOOL_OUT, _or5, _and4, notifier,
       vcond1;
reg notifier;
   buf buf0 (CPN_buf, CPN);
   buf buf1 (SDN_buf, SDN);
   buf buf2 (D_buf, D);
   buf buf3 (ENN_buf, ENN);
   and _and4 (_and4, !ENN_buf, D_buf, !ENN_buf);
   or _or5 (_or5, !Q, !ENN_buf);
   or _or6 (BOOL_OUT, _and4, !_or5);
   s_depfq4 s_depfq47 (Q, CPN, ENN, SDN, D, notifier);
   and _and8 (vcond1, SDN_buf, ENN_buf);
endmodule
`endcelldefine

`celldefine
module s_deprq4 (Q, CP, ENN, SDN, D, notifier);
input CP, ENN, SDN, D, notifier;
output Q;
wire _mux1;
   _DFF _dff0 (!SDN, 1'b0, CP, _mux1, Q);
   _MUX _mux1 (ENN, D, Q, _mux1);
endmodule
`endcelldefine

`celldefine
module deprq4 (CP, SDN, D, ENN, Q);
input CP, SDN, D, ENN;
output Q;
wire CP_buf, SDN_buf, D_buf, ENN_buf, BOOL_OUT, _or5, _and4, notifier,
       vcond1;
reg notifier;
   buf buf0 (CP_buf, CP);
   buf buf1 (SDN_buf, SDN);
   buf buf2 (D_buf, D);
   buf buf3 (ENN_buf, ENN);
   and _and4 (_and4, !ENN_buf, D_buf, !ENN_buf);
   or _or5 (_or5, !Q, !ENN_buf);
   or _or6 (BOOL_OUT, _and4, !_or5);
   s_deprq4 s_deprq47 (Q, CP, ENN, SDN, D, notifier);
   and _and8 (vcond1, SDN_buf, ENN_buf);
endmodule
`endcelldefine

`celldefine
module dfpfb4 (D, CPN, SDN, Q, QN);
input D, CPN, SDN;
output Q, QN;
wire notifier, buf_Q;
reg notifier;
   U_FD_N_SB_NO U_FD_N_SB_NO0 (buf_Q, D, CPN, SDN, notifier);
   buf buf1 (Q, buf_Q);
   not not2 (QN, buf_Q);
endmodule
`endcelldefine

`celldefine
module dfprb4 (D, CP, SDN, Q, QN);
input D, CP, SDN;
output Q, QN;
wire notifier, buf_Q;
reg notifier;
   U_FD_P_SB_NO U_FD_P_SB_NO0 (buf_Q, D, CP, SDN, notifier);
   buf buf1 (Q, buf_Q);
   not not2 (QN, buf_Q);
endmodule
`endcelldefine

`celldefine
module adp1d0 (A, B, CI, S, P, CO);
input A, B, CI;
output S, P, CO;
wire A_buf, B_buf, CI_buf, S_OUT, _and4, _and3, _and6, _and7, P_OUT, _and10,
       _and9, CO_OUT, _and14, _and13, _and16;
   buf buf0 (A_buf, A);
   buf buf1 (B_buf, B);
   buf buf2 (CI_buf, CI);
   and _and3 (_and3, !CI_buf, !B_buf, A_buf);
   and _and4 (_and4, !CI_buf, B_buf, !A_buf);
   or _or5 (S_OUT, _and3, _and4, _and6, _and7);
   and _and6 (_and6, CI_buf, B_buf, A_buf);
   and _and7 (_and7, CI_buf, !B_buf, !A_buf);
   buf buf8 (S, S_OUT);
   and _and9 (_and9, !B_buf, A_buf);
   and _and10 (_and10, B_buf, !A_buf);
   or _or11 (P_OUT, _and9, _and10);
   buf buf12 (P, P_OUT);
   and _and13 (_and13, B_buf, A_buf);
   and _and14 (_and14, CI_buf, B_buf);
   or _or15 (CO_OUT, _and13, _and14, _and16);
   and _and16 (_and16, CI_buf, A_buf);
   buf buf17 (CO, CO_OUT);
endmodule
`endcelldefine

`celldefine
module adp1d1 (A, B, CI, S, P, CO);
input A, B, CI;
output S, P, CO;
wire A_buf, B_buf, CI_buf, S_OUT, _and4, _and3, _and6, _and7, P_OUT, _and10,
       _and9, CO_OUT, _and14, _and13, _and16;
   buf buf0 (A_buf, A);
   buf buf1 (B_buf, B);
   buf buf2 (CI_buf, CI);
   and _and3 (_and3, !CI_buf, !B_buf, A_buf);
   and _and4 (_and4, !CI_buf, B_buf, !A_buf);
   or _or5 (S_OUT, _and3, _and4, _and6, _and7);
   and _and6 (_and6, CI_buf, B_buf, A_buf);
   and _and7 (_and7, CI_buf, !B_buf, !A_buf);
   buf buf8 (S, S_OUT);
   and _and9 (_and9, !B_buf, A_buf);
   and _and10 (_and10, B_buf, !A_buf);
   or _or11 (P_OUT, _and9, _and10);
   buf buf12 (P, P_OUT);
   and _and13 (_and13, B_buf, A_buf);
   and _and14 (_and14, CI_buf, B_buf);
   or _or15 (CO_OUT, _and13, _and14, _and16);
   and _and16 (_and16, CI_buf, A_buf);
   buf buf17 (CO, CO_OUT);
endmodule
`endcelldefine

`celldefine
module adp1d2 (A, B, CI, S, P, CO);
input A, B, CI;
output S, P, CO;
wire A_buf, B_buf, CI_buf, S_OUT, _and4, _and3, _and6, _and7, P_OUT, _and10,
       _and9, CO_OUT, _and14, _and13, _and16;
   buf buf0 (A_buf, A);
   buf buf1 (B_buf, B);
   buf buf2 (CI_buf, CI);
   and _and3 (_and3, !CI_buf, !B_buf, A_buf);
   and _and4 (_and4, !CI_buf, B_buf, !A_buf);
   or _or5 (S_OUT, _and3, _and4, _and6, _and7);
   and _and6 (_and6, CI_buf, B_buf, A_buf);
   and _and7 (_and7, CI_buf, !B_buf, !A_buf);
   buf buf8 (S, S_OUT);
   and _and9 (_and9, !B_buf, A_buf);
   and _and10 (_and10, B_buf, !A_buf);
   or _or11 (P_OUT, _and9, _and10);
   buf buf12 (P, P_OUT);
   and _and13 (_and13, B_buf, A_buf);
   and _and14 (_and14, CI_buf, B_buf);
   or _or15 (CO_OUT, _and13, _and14, _and16);
   and _and16 (_and16, CI_buf, A_buf);
   buf buf17 (CO, CO_OUT);
endmodule
`endcelldefine

`celldefine
module nr13d4 (A1, A2, A3, ZN);
input A1, A2, A3;
output ZN;
wire not_A3, not_A2;
   not not0 (not_A3, A3);
   not not1 (not_A2, A2);
   and and2 (ZN, not_A3, not_A2, A1);
endmodule
`endcelldefine

`celldefine
module nr13d2 (A1, A2, A3, ZN);
input A1, A2, A3;
output ZN;
wire not_A3, not_A2;
   not not0 (not_A3, A3);
   not not1 (not_A2, A2);
   and and2 (ZN, not_A3, not_A2, A1);
endmodule
`endcelldefine

`celldefine
module nr13d1 (A1, A2, A3, ZN);
input A1, A2, A3;
output ZN;
wire not_A3, not_A2;
   not not0 (not_A3, A3);
   not not1 (not_A2, A2);
   and and2 (ZN, not_A3, not_A2, A1);
endmodule
`endcelldefine

`celldefine
module nd13d4 (A1, A2, A3, ZN);
input A1, A2, A3;
output ZN;
wire not_A3, not_A2;
   not not0 (not_A3, A3);
   not not1 (not_A2, A2);
   or or2 (ZN, not_A3, not_A2, A1);
endmodule
`endcelldefine

`celldefine
module nd13d2 (A1, A2, A3, ZN);
input A1, A2, A3;
output ZN;
wire not_A3, not_A2;
   not not0 (not_A3, A3);
   not not1 (not_A2, A2);
   or or2 (ZN, not_A3, not_A2, A1);
endmodule
`endcelldefine

`celldefine
module nd13d1 (A1, A2, A3, ZN);
input A1, A2, A3;
output ZN;
wire not_A3, not_A2;
   not not0 (not_A3, A3);
   not not1 (not_A2, A2);
   or or2 (ZN, not_A3, not_A2, A1);
endmodule
`endcelldefine

`celldefine
module nd12d4 (A1, A2, ZN);
input A1, A2;
output ZN;
wire not_A2;
   not not0 (not_A2, A2);
   or or1 (ZN, not_A2, A1);
endmodule
`endcelldefine

`celldefine
module nd12d2 (A1, A2, ZN);
input A1, A2;
output ZN;
wire not_A2;
   not not0 (not_A2, A2);
   or or1 (ZN, not_A2, A1);
endmodule
`endcelldefine

`celldefine
module nd12d1 (A1, A2, ZN);
input A1, A2;
output ZN;
wire not_A2;
   not not0 (not_A2, A2);
   or or1 (ZN, not_A2, A1);
endmodule
`endcelldefine

`celldefine
module nd12d0 (A1, A2, ZN);
input A1, A2;
output ZN;
wire not_A2;
   not not0 (not_A2, A2);
   or or1 (ZN, not_A2, A1);
endmodule
`endcelldefine

`celldefine
module an12d1 (A1, A2, Z);
input A1, A2;
output Z;
wire not_A1;
   not not0 (not_A1, A1);
   and and1 (Z, A2, not_A1);
endmodule
`endcelldefine

`celldefine
module an12d2 (A1, A2, Z);
input A1, A2;
output Z;
wire not_A1;
   not not0 (not_A1, A1);
   and and1 (Z, A2, not_A1);
endmodule
`endcelldefine

`celldefine
module an12d4 (A1, A2, Z);
input A1, A2;
output Z;
wire not_A1;
   not not0 (not_A1, A1);
   and and1 (Z, A2, not_A1);
endmodule
`endcelldefine

`celldefine
module cload1 (I);
input I;
wire DeadEnd;
   buf E0 (DeadEnd, I);
endmodule
`endcelldefine

`celldefine
module xr03d4 (A1, A2, A3, Z);
input A1, A2, A3;
output Z;
   xor xor0 (Z, A3, A2, A1);
endmodule
`endcelldefine

`celldefine
module xr03d2 (A1, A2, A3, Z);
input A1, A2, A3;
output Z;
   xor xor0 (Z, A3, A2, A1);
endmodule
`endcelldefine

`celldefine
module xr03d1 (A1, A2, A3, Z);
input A1, A2, A3;
output Z;
   xor xor0 (Z, A3, A2, A1);
endmodule
`endcelldefine

`celldefine
module xr02d4 (A1, A2, Z);
input A1, A2;
output Z;
   xor xor0 (Z, A2, A1);
endmodule
`endcelldefine

`celldefine
module xr02d2 (A1, A2, Z);
input A1, A2;
output Z;
   xor xor0 (Z, A2, A1);
endmodule
`endcelldefine

`celldefine
module xr02d1 (A1, A2, Z);
input A1, A2;
output Z;
   xor xor0 (Z, A2, A1);
endmodule
`endcelldefine

`celldefine
module xn02d4 (A1, A2, ZN);
input A1, A2;
output ZN;
   xnor xnor0 (ZN, A2, A1);
endmodule
`endcelldefine

`celldefine
module xn02d2 (A1, A2, ZN);
input A1, A2;
output ZN;
   xnor xnor0 (ZN, A2, A1);
endmodule
`endcelldefine

`celldefine
module xn02d1 (A1, A2, ZN);
input A1, A2;
output ZN;
   xnor xnor0 (ZN, A2, A1);
endmodule
`endcelldefine

`celldefine
module U_SUB2_D (S, A, B, CI);
input A, B, CI;
output S;
   _XNOR _xor0 (A, B, CI, S);
endmodule
`endcelldefine

`celldefine
module U_SUB2_C (CO, A, B, CI);
input A, B, CI;
output CO;
wire _or1, _and0, _and2;
   _AND _and0 (CI, !B, _and0);
   _OR _or1 (CI, !B, _or1);
   _AND _and2 (_or1, A, _and2);
   _OR _or3 (_and0, _and2, CO);
endmodule
`endcelldefine

`celldefine
module su01d2 (A, B, CI, S, CO);
input A, B, CI;
output S, CO;
   U_SUB2_D U_SUB2_D0 (S, A, B, CI);
   U_SUB2_C U_SUB2_C1 (CO, A, B, CI);
endmodule
`endcelldefine

`celldefine
module su01d1 (A, B, CI, S, CO);
input A, B, CI;
output S, CO;
   U_SUB2_D U_SUB2_D0 (S, A, B, CI);
   U_SUB2_C U_SUB2_C1 (CO, A, B, CI);
endmodule
`endcelldefine

`celldefine
module su01d0 (A, B, CI, S, CO);
input A, B, CI;
output S, CO;
   U_SUB2_D U_SUB2_D0 (S, A, B, CI);
   U_SUB2_C U_SUB2_C1 (CO, A, B, CI);
endmodule
`endcelldefine

`celldefine
module or04d4 (A1, A2, A3, A4, Z);
input A1, A2, A3, A4;
output Z;
   or or0 (Z, A4, A3, A2, A1);
endmodule
`endcelldefine

`celldefine
module or04d2 (A1, A2, A3, A4, Z);
input A1, A2, A3, A4;
output Z;
   or or0 (Z, A4, A3, A2, A1);
endmodule
`endcelldefine

`celldefine
module or04d1 (A1, A2, A3, A4, Z);
input A1, A2, A3, A4;
output Z;
   or or0 (Z, A4, A3, A2, A1);
endmodule
`endcelldefine

`celldefine
module or04d0 (A1, A2, A3, A4, Z);
input A1, A2, A3, A4;
output Z;
   or or0 (Z, A4, A3, A2, A1);
endmodule
`endcelldefine

`celldefine
module or03d4 (A1, A2, A3, Z);
input A1, A2, A3;
output Z;
   or or0 (Z, A3, A2, A1);
endmodule
`endcelldefine

`celldefine
module or03d2 (A1, A2, A3, Z);
input A1, A2, A3;
output Z;
   or or0 (Z, A3, A2, A1);
endmodule
`endcelldefine

`celldefine
module or03d1 (A1, A2, A3, Z);
input A1, A2, A3;
output Z;
   or or0 (Z, A3, A2, A1);
endmodule
`endcelldefine

`celldefine
module or03d0 (A1, A2, A3, Z);
input A1, A2, A3;
output Z;
   or or0 (Z, A3, A2, A1);
endmodule
`endcelldefine

`celldefine
module or02d4 (A1, A2, Z);
input A1, A2;
output Z;
   or or0 (Z, A2, A1);
endmodule
`endcelldefine

`celldefine
module or02d2 (A1, A2, Z);
input A1, A2;
output Z;
   or or0 (Z, A2, A1);
endmodule
`endcelldefine

`celldefine
module or02d1 (A1, A2, Z);
input A1, A2;
output Z;
   or or0 (Z, A2, A1);
endmodule
`endcelldefine

`celldefine
module or02d0 (A1, A2, Z);
input A1, A2;
output Z;
   or or0 (Z, A2, A1);
endmodule
`endcelldefine

`celldefine
module nr04d4 (A1, A2, A3, A4, ZN);
input A1, A2, A3, A4;
output ZN;
   nor nor0 (ZN, A4, A3, A2, A1);
endmodule
`endcelldefine

`celldefine
module nr04d2 (A1, A2, A3, A4, ZN);
input A1, A2, A3, A4;
output ZN;
   nor nor0 (ZN, A4, A3, A2, A1);
endmodule
`endcelldefine

`celldefine
module nr04d1 (A1, A2, A3, A4, ZN);
input A1, A2, A3, A4;
output ZN;
   nor nor0 (ZN, A4, A3, A2, A1);
endmodule
`endcelldefine

`celldefine
module nr04d0 (A1, A2, A3, A4, ZN);
input A1, A2, A3, A4;
output ZN;
   nor nor0 (ZN, A4, A3, A2, A1);
endmodule
`endcelldefine

`celldefine
module nr03d4 (A1, A2, A3, ZN);
input A1, A2, A3;
output ZN;
   nor nor0 (ZN, A3, A2, A1);
endmodule
`endcelldefine

`celldefine
module nr03d2 (A1, A2, A3, ZN);
input A1, A2, A3;
output ZN;
   nor nor0 (ZN, A3, A2, A1);
endmodule
`endcelldefine

`celldefine
module nr03d1 (A1, A2, A3, ZN);
input A1, A2, A3;
output ZN;
   nor nor0 (ZN, A3, A2, A1);
endmodule
`endcelldefine

`celldefine
module nr03d0 (A1, A2, A3, ZN);
input A1, A2, A3;
output ZN;
   nor nor0 (ZN, A3, A2, A1);
endmodule
`endcelldefine

`celldefine
module nr02d4 (A1, A2, ZN);
input A1, A2;
output ZN;
   nor nor0 (ZN, A2, A1);
endmodule
`endcelldefine

`celldefine
module nr02d2 (A1, A2, ZN);
input A1, A2;
output ZN;
   nor nor0 (ZN, A2, A1);
endmodule
`endcelldefine

`celldefine
module nr02d1 (A1, A2, ZN);
input A1, A2;
output ZN;
   nor nor0 (ZN, A2, A1);
endmodule
`endcelldefine

`celldefine
module nr02d0 (A1, A2, ZN);
input A1, A2;
output ZN;
   nor nor0 (ZN, A2, A1);
endmodule
`endcelldefine

`celldefine
module nd04d4 (A1, A2, A3, A4, ZN);
input A1, A2, A3, A4;
output ZN;
   nand nand0 (ZN, A4, A3, A2, A1);
endmodule
`endcelldefine

`celldefine
module nd04d2 (A1, A2, A3, A4, ZN);
input A1, A2, A3, A4;
output ZN;
   nand nand0 (ZN, A4, A3, A2, A1);
endmodule
`endcelldefine

`celldefine
module nd04d1 (A1, A2, A3, A4, ZN);
input A1, A2, A3, A4;
output ZN;
   nand nand0 (ZN, A4, A3, A2, A1);
endmodule
`endcelldefine

`celldefine
module nd04d0 (A1, A2, A3, A4, ZN);
input A1, A2, A3, A4;
output ZN;
   nand nand0 (ZN, A4, A3, A2, A1);
endmodule
`endcelldefine

`celldefine
module nd03d4 (A1, A2, A3, ZN);
input A1, A2, A3;
output ZN;
   nand nand0 (ZN, A3, A2, A1);
endmodule
`endcelldefine

`celldefine
module nd03d2 (A1, A2, A3, ZN);
input A1, A2, A3;
output ZN;
   nand nand0 (ZN, A3, A2, A1);
endmodule
`endcelldefine

`celldefine
module nd03d1 (A1, A2, A3, ZN);
input A1, A2, A3;
output ZN;
   nand nand0 (ZN, A3, A2, A1);
endmodule
`endcelldefine

`celldefine
module nd03d0 (A1, A2, A3, ZN);
input A1, A2, A3;
output ZN;
   nand nand0 (ZN, A3, A2, A1);
endmodule
`endcelldefine

`celldefine
module nd02d4 (A1, A2, ZN);
input A1, A2;
output ZN;
   nand nand0 (ZN, A2, A1);
endmodule
`endcelldefine

`celldefine
module nd02d2 (A1, A2, ZN);
input A1, A2;
output ZN;
   nand nand0 (ZN, A2, A1);
endmodule
`endcelldefine

`celldefine
module nd02d1 (A1, A2, ZN);
input A1, A2;
output ZN;
   nand nand0 (ZN, A2, A1);
endmodule
`endcelldefine

`celldefine
module nd02d0 (A1, A2, ZN);
input A1, A2;
output ZN;
   nand nand0 (ZN, A2, A1);
endmodule
`endcelldefine

`celldefine
module U_MUX_4_2 (Y, D0, D1, D2, D3, S0, S1);
input D0, D1, D2, D3, S0, S1;
output Y;
wire _mux0, _mux1;
   _MUX _mux0 (S1, D0, D2, _mux0);
   _MUX _mux1 (S1, D1, D3, _mux1);
   _MUX _mux2 (S0, _mux0, _mux1, Y);
endmodule
`endcelldefine

`celldefine
module mx04d4 (I0, I1, I2, I3, S0, S1, Z);
input I0, I1, I2, I3, S0, S1;
output Z;
   U_MUX_4_2 U_MUX_4_20 (Z, I0, I1, I2, I3, S0, S1);
endmodule
`endcelldefine

`celldefine
module mx04d2 (I0, I1, I2, I3, S0, S1, Z);
input I0, I1, I2, I3, S0, S1;
output Z;
   U_MUX_4_2 U_MUX_4_20 (Z, I0, I1, I2, I3, S0, S1);
endmodule
`endcelldefine

`celldefine
module mx04d1 (I0, I1, I2, I3, S0, S1, Z);
input I0, I1, I2, I3, S0, S1;
output Z;
   U_MUX_4_2 U_MUX_4_20 (Z, I0, I1, I2, I3, S0, S1);
endmodule
`endcelldefine

`celldefine
module mx04d0 (I0, I1, I2, I3, S0, S1, Z);
input I0, I1, I2, I3, S0, S1;
output Z;
   U_MUX_4_2 U_MUX_4_20 (Z, I0, I1, I2, I3, S0, S1);
endmodule
`endcelldefine

`celldefine
module mx02d4 (I0, I1, S, Z);
input I0, I1, S;
output Z;
   U_MUX_2_1 U_MUX_2_10 (Z, I0, I1, S);
endmodule
`endcelldefine

`celldefine
module mx02d2 (I0, I1, S, Z);
input I0, I1, S;
output Z;
   U_MUX_2_1 U_MUX_2_10 (Z, I0, I1, S);
endmodule
`endcelldefine

`celldefine
module mx02d1 (I0, I1, S, Z);
input I0, I1, S;
output Z;
   U_MUX_2_1 U_MUX_2_10 (Z, I0, I1, S);
endmodule
`endcelldefine

`celldefine
module mx02d0 (I0, I1, S, Z);
input I0, I1, S;
output Z;
   U_MUX_2_1 U_MUX_2_10 (Z, I0, I1, S);
endmodule
`endcelldefine

`celldefine
module U_MUX_2_1_INV (Y, D0, D1, S);
input D0, D1, S;
output Y;
   _MUX _mux0 (S, !D0, !D1, Y);
endmodule
`endcelldefine

`celldefine
module mi02d4 (I0, I1, S, ZN);
input I0, I1, S;
output ZN;
   U_MUX_2_1_INV U_MUX_2_1_INV0 (ZN, I0, I1, S);
endmodule
`endcelldefine

`celldefine
module mi02d2 (I0, I1, S, ZN);
input I0, I1, S;
output ZN;
   U_MUX_2_1_INV U_MUX_2_1_INV0 (ZN, I0, I1, S);
endmodule
`endcelldefine

`celldefine
module mi02d1 (I0, I1, S, ZN);
input I0, I1, S;
output ZN;
   U_MUX_2_1_INV U_MUX_2_1_INV0 (ZN, I0, I1, S);
endmodule
`endcelldefine

`celldefine
module mi02d0 (I0, I1, S, ZN);
input I0, I1, S;
output ZN;
   U_MUX_2_1_INV U_MUX_2_1_INV0 (ZN, I0, I1, S);
endmodule
`endcelldefine

`celldefine
module dl04d1 (I, Z);
input I;
output Z;
   buf buf0 (Z, I);
endmodule
`endcelldefine

`celldefine
module dl03d1 (I, Z);
input I;
output Z;
   buf buf0 (Z, I);
endmodule
`endcelldefine

`celldefine
module dl02d1 (I, Z);
input I;
output Z;
   buf buf0 (Z, I);
endmodule
`endcelldefine

`celldefine
module dl01d1 (I, Z);
input I;
output Z;
   buf buf0 (Z, I);
endmodule
`endcelldefine

`celldefine
module or04da (A1, A2, A3, A4, Z);
input A1, A2, A3, A4;
output Z;
   or or0 (Z, A4, A3, A2, A1);
endmodule
`endcelldefine

`celldefine
module or04d7 (A1, A2, A3, A4, Z);
input A1, A2, A3, A4;
output Z;
   or or0 (Z, A4, A3, A2, A1);
endmodule
`endcelldefine

`celldefine
module or03da (A1, A2, A3, Z);
input A1, A2, A3;
output Z;
   or or0 (Z, A3, A2, A1);
endmodule
`endcelldefine

`celldefine
module or03d7 (A1, A2, A3, Z);
input A1, A2, A3;
output Z;
   or or0 (Z, A3, A2, A1);
endmodule
`endcelldefine

`celldefine
module or02da (A1, A2, Z);
input A1, A2;
output Z;
   or or0 (Z, A2, A1);
endmodule
`endcelldefine

`celldefine
module or02d7 (A1, A2, Z);
input A1, A2;
output Z;
   or or0 (Z, A2, A1);
endmodule
`endcelldefine

`celldefine
module nr04da (A1, A2, A3, A4, ZN);
input A1, A2, A3, A4;
output ZN;
   nor nor0 (ZN, A4, A3, A2, A1);
endmodule
`endcelldefine

`celldefine
module nr04d7 (A1, A2, A3, A4, ZN);
input A1, A2, A3, A4;
output ZN;
   nor nor0 (ZN, A4, A3, A2, A1);
endmodule
`endcelldefine

`celldefine
module nr03da (A1, A2, A3, ZN);
input A1, A2, A3;
output ZN;
   nor nor0 (ZN, A3, A2, A1);
endmodule
`endcelldefine

`celldefine
module nr03d7 (A1, A2, A3, ZN);
input A1, A2, A3;
output ZN;
   nor nor0 (ZN, A3, A2, A1);
endmodule
`endcelldefine

`celldefine
module nr02da (A1, A2, ZN);
input A1, A2;
output ZN;
   nor nor0 (ZN, A2, A1);
endmodule
`endcelldefine

`celldefine
module nr02d7 (A1, A2, ZN);
input A1, A2;
output ZN;
   nor nor0 (ZN, A2, A1);
endmodule
`endcelldefine

`celldefine
module nd04da (A1, A2, A3, A4, ZN);
input A1, A2, A3, A4;
output ZN;
   nand nand0 (ZN, A4, A3, A2, A1);
endmodule
`endcelldefine

`celldefine
module nd04d7 (A1, A2, A3, A4, ZN);
input A1, A2, A3, A4;
output ZN;
   nand nand0 (ZN, A4, A3, A2, A1);
endmodule
`endcelldefine

`celldefine
module nd03da (A1, A2, A3, ZN);
input A1, A2, A3;
output ZN;
   nand nand0 (ZN, A3, A2, A1);
endmodule
`endcelldefine

`celldefine
module nd03d7 (A1, A2, A3, ZN);
input A1, A2, A3;
output ZN;
   nand nand0 (ZN, A3, A2, A1);
endmodule
`endcelldefine

`celldefine
module nd02da (A1, A2, ZN);
input A1, A2;
output ZN;
   nand nand0 (ZN, A2, A1);
endmodule
`endcelldefine

`celldefine
module nd02d7 (A1, A2, ZN);
input A1, A2;
output ZN;
   nand nand0 (ZN, A2, A1);
endmodule
`endcelldefine

module s_mx08d4 (I0, I1, I2, I3, I4, I5, I6, I7, S0, S1, S2, Z);
input I0, I1, I2, I3, I4, I5, I6, I7, S0, S1, S2;
output Z;
wire reg_Z, xreg_Z, flag_Z;
reg reg_Z, xreg_Z, flag_Z;
   buf buf0 (Z, reg_Z);
endmodule

`celldefine
module mx08d4 (I0, I1, I2, I3, I4, I5, I6, I7, S0, S1, S2, Z);
input I0, I1, I2, I3, I4, I5, I6, I7, S0, S1, S2;
output Z;
wire I0_buf, I1_buf, I2_buf, I3_buf, I4_buf, I5_buf, I6_buf, I7_buf, S0_buf,
       S1_buf, S2_buf;
   buf b_I0 (I0_buf, I0);
   buf b_I1 (I1_buf, I1);
   buf b_I2 (I2_buf, I2);
   buf b_I3 (I3_buf, I3);
   buf b_I4 (I4_buf, I4);
   buf b_I5 (I5_buf, I5);
   buf b_I6 (I6_buf, I6);
   buf b_I7 (I7_buf, I7);
   buf b_S0 (S0_buf, S0);
   buf b_S1 (S1_buf, S1);
   buf b_S2 (S2_buf, S2);
   s_mx08d4 g1_s_mx08d4_1 (I0_buf, I1_buf, I2_buf, I3_buf, I4_buf, I5_buf,
          I6_buf, I7_buf, S0_buf, S1_buf, S2_buf, Z);
endmodule
`endcelldefine

module s_mx08d2 (I0, I1, I2, I3, I4, I5, I6, I7, S0, S1, S2, Z);
input I0, I1, I2, I3, I4, I5, I6, I7, S0, S1, S2;
output Z;
wire reg_Z, xreg_Z, flag_Z;
reg reg_Z, xreg_Z, flag_Z;
   buf buf0 (Z, reg_Z);
endmodule

`celldefine
module mx08d2 (I0, I1, I2, I3, I4, I5, I6, I7, S0, S1, S2, Z);
input I0, I1, I2, I3, I4, I5, I6, I7, S0, S1, S2;
output Z;
wire I0_buf, I1_buf, I2_buf, I3_buf, I4_buf, I5_buf, I6_buf, I7_buf, S0_buf,
       S1_buf, S2_buf;
   buf b_I0 (I0_buf, I0);
   buf b_I1 (I1_buf, I1);
   buf b_I2 (I2_buf, I2);
   buf b_I3 (I3_buf, I3);
   buf b_I4 (I4_buf, I4);
   buf b_I5 (I5_buf, I5);
   buf b_I6 (I6_buf, I6);
   buf b_I7 (I7_buf, I7);
   buf b_S0 (S0_buf, S0);
   buf b_S1 (S1_buf, S1);
   buf b_S2 (S2_buf, S2);
   s_mx08d2 g1_s_mx08d2_1 (I0_buf, I1_buf, I2_buf, I3_buf, I4_buf, I5_buf,
          I6_buf, I7_buf, S0_buf, S1_buf, S2_buf, Z);
endmodule
`endcelldefine

module s_mx08d1 (I0, I1, I2, I3, I4, I5, I6, I7, S0, S1, S2, Z);
input I0, I1, I2, I3, I4, I5, I6, I7, S0, S1, S2;
output Z;
wire reg_Z, xreg_Z, flag_Z;
reg reg_Z, xreg_Z, flag_Z;
   buf buf0 (Z, reg_Z);
endmodule

`celldefine
module mx08d1 (I0, I1, I2, I3, I4, I5, I6, I7, S0, S1, S2, Z);
input I0, I1, I2, I3, I4, I5, I6, I7, S0, S1, S2;
output Z;
wire I0_buf, I1_buf, I2_buf, I3_buf, I4_buf, I5_buf, I6_buf, I7_buf, S0_buf,
       S1_buf, S2_buf;
   buf b_I0 (I0_buf, I0);
   buf b_I1 (I1_buf, I1);
   buf b_I2 (I2_buf, I2);
   buf b_I3 (I3_buf, I3);
   buf b_I4 (I4_buf, I4);
   buf b_I5 (I5_buf, I5);
   buf b_I6 (I6_buf, I6);
   buf b_I7 (I7_buf, I7);
   buf b_S0 (S0_buf, S0);
   buf b_S1 (S1_buf, S1);
   buf b_S2 (S2_buf, S2);
   s_mx08d1 g1_s_mx08d1_1 (I0_buf, I1_buf, I2_buf, I3_buf, I4_buf, I5_buf,
          I6_buf, I7_buf, S0_buf, S1_buf, S2_buf, Z);
endmodule
`endcelldefine

`celldefine
module U_ADDR2_S (S, A, B, CI);
input A, B, CI;
output S;
   _XOR _xor0 (A, B, CI, S);
endmodule
`endcelldefine

`celldefine
module U_ADDR2_C (CO, A, B, CI);
input A, B, CI;
output CO;
wire _or1, _and0, _and2;
   _AND _and0 (CI, B, _and0);
   _OR _or1 (CI, B, _or1);
   _AND _and2 (_or1, A, _and2);
   _OR _or3 (_and0, _and2, CO);
endmodule
`endcelldefine

`celldefine
module ad01d4 (A, B, CI, S, CO);
input A, B, CI;
output S, CO;
   U_ADDR2_S U_ADDR2_S0 (S, A, B, CI);
   U_ADDR2_C U_ADDR2_C1 (CO, A, B, CI);
endmodule
`endcelldefine

`celldefine
module ah01d4 (A, B, S, CO);
input A, B;
output S, CO;
   xor xor0 (S, B, A);
   and and1 (CO, B, A);
endmodule
`endcelldefine

`celldefine
module an02d7 (A1, A2, Z);
input A1, A2;
output Z;
   and and0 (Z, A2, A1);
endmodule
`endcelldefine

`celldefine
module an02da (A1, A2, Z);
input A1, A2;
output Z;
   and and0 (Z, A2, A1);
endmodule
`endcelldefine

`celldefine
module an03d7 (A1, A2, A3, Z);
input A1, A2, A3;
output Z;
   and and0 (Z, A3, A2, A1);
endmodule
`endcelldefine

`celldefine
module an03da (A1, A2, A3, Z);
input A1, A2, A3;
output Z;
   and and0 (Z, A3, A2, A1);
endmodule
`endcelldefine

`celldefine
module an04d7 (A1, A2, A3, A4, Z);
input A1, A2, A3, A4;
output Z;
   and and0 (Z, A4, A3, A2, A1);
endmodule
`endcelldefine

`celldefine
module an04da (A1, A2, A3, A4, Z);
input A1, A2, A3, A4;
output Z;
   and and0 (Z, A4, A3, A2, A1);
endmodule
`endcelldefine

`celldefine
module cg01d4 (A, B, CI, CO);
input A, B, CI;
output CO;
wire g_1_out, g_2_out, g_3_out;
   and and0 (g_1_out, B, A);
   and and1 (g_2_out, CI, B);
   and and2 (g_3_out, CI, A);
   or or3 (CO, g_1_out, g_2_out, g_3_out);
endmodule
`endcelldefine

`celldefine
module dl01d2 (I, Z);
input I;
output Z;
   buf buf0 (Z, I);
endmodule
`endcelldefine

`celldefine
module dl01d4 (I, Z);
input I;
output Z;
   buf buf0 (Z, I);
endmodule
`endcelldefine

`celldefine
module dl02d2 (I, Z);
input I;
output Z;
   buf buf0 (Z, I);
endmodule
`endcelldefine

`celldefine
module dl02d4 (I, Z);
input I;
output Z;
   buf buf0 (Z, I);
endmodule
`endcelldefine

`celldefine
module dl03d2 (I, Z);
input I;
output Z;
   buf buf0 (Z, I);
endmodule
`endcelldefine

`celldefine
module dl03d4 (I, Z);
input I;
output Z;
   buf buf0 (Z, I);
endmodule
`endcelldefine

`celldefine
module dl04d2 (I, Z);
input I;
output Z;
   buf buf0 (Z, I);
endmodule
`endcelldefine

`celldefine
module dl04d4 (I, Z);
input I;
output Z;
   buf buf0 (Z, I);
endmodule
`endcelldefine

`celldefine
module su01d4 (A, B, CI, S, CO);
input A, B, CI;
output S, CO;
   U_SUB2_D U_SUB2_D0 (S, A, B, CI);
   U_SUB2_C U_SUB2_C1 (CO, A, B, CI);
endmodule
`endcelldefine

`celldefine
module xn02d7 (A1, A2, ZN);
input A1, A2;
output ZN;
   xnor xnor0 (ZN, A2, A1);
endmodule
`endcelldefine

`celldefine
module xn02da (A1, A2, ZN);
input A1, A2;
output ZN;
   xnor xnor0 (ZN, A2, A1);
endmodule
`endcelldefine

`celldefine
module xr02d7 (A1, A2, Z);
input A1, A2;
output Z;
   xor xor0 (Z, A2, A1);
endmodule
`endcelldefine

`celldefine
module xr02da (A1, A2, Z);
input A1, A2;
output Z;
   xor xor0 (Z, A2, A1);
endmodule
`endcelldefine

`celldefine
module xr03d7 (A1, A2, A3, Z);
input A1, A2, A3;
output Z;
   xor xor0 (Z, A3, A2, A1);
endmodule
`endcelldefine

`celldefine
module xr03da (A1, A2, A3, Z);
input A1, A2, A3;
output Z;
   xor xor0 (Z, A3, A2, A1);
endmodule
`endcelldefine

`celldefine
module ad01d0 (A, B, CI, S, CO);
input A, B, CI;
output S, CO;
   U_ADDR2_S U_ADDR2_S0 (S, A, B, CI);
   U_ADDR2_C U_ADDR2_C1 (CO, A, B, CI);
endmodule
`endcelldefine

`celldefine
module ad01d1 (A, B, CI, S, CO);
input A, B, CI;
output S, CO;
   U_ADDR2_S U_ADDR2_S0 (S, A, B, CI);
   U_ADDR2_C U_ADDR2_C1 (CO, A, B, CI);
endmodule
`endcelldefine

`celldefine
module ad01d2 (A, B, CI, S, CO);
input A, B, CI;
output S, CO;
   U_ADDR2_S U_ADDR2_S0 (S, A, B, CI);
   U_ADDR2_C U_ADDR2_C1 (CO, A, B, CI);
endmodule
`endcelldefine

`celldefine
module ah01d0 (A, B, S, CO);
input A, B;
output S, CO;
   xor xor0 (S, B, A);
   and and1 (CO, B, A);
endmodule
`endcelldefine

`celldefine
module ah01d1 (A, B, S, CO);
input A, B;
output S, CO;
   xor xor0 (S, B, A);
   and and1 (CO, B, A);
endmodule
`endcelldefine

`celldefine
module ah01d2 (A, B, S, CO);
input A, B;
output S, CO;
   xor xor0 (S, B, A);
   and and1 (CO, B, A);
endmodule
`endcelldefine

`celldefine
module an02d0 (A1, A2, Z);
input A1, A2;
output Z;
   and and0 (Z, A2, A1);
endmodule
`endcelldefine

`celldefine
module an02d1 (A1, A2, Z);
input A1, A2;
output Z;
   and and0 (Z, A2, A1);
endmodule
`endcelldefine

`celldefine
module an02d2 (A1, A2, Z);
input A1, A2;
output Z;
   and and0 (Z, A2, A1);
endmodule
`endcelldefine

`celldefine
module an02d4 (A1, A2, Z);
input A1, A2;
output Z;
   and and0 (Z, A2, A1);
endmodule
`endcelldefine

`celldefine
module an03d0 (A1, A2, A3, Z);
input A1, A2, A3;
output Z;
   and and0 (Z, A3, A2, A1);
endmodule
`endcelldefine

`celldefine
module an03d1 (A1, A2, A3, Z);
input A1, A2, A3;
output Z;
   and and0 (Z, A3, A2, A1);
endmodule
`endcelldefine

`celldefine
module an03d2 (A1, A2, A3, Z);
input A1, A2, A3;
output Z;
   and and0 (Z, A3, A2, A1);
endmodule
`endcelldefine

`celldefine
module an03d4 (A1, A2, A3, Z);
input A1, A2, A3;
output Z;
   and and0 (Z, A3, A2, A1);
endmodule
`endcelldefine

`celldefine
module an04d0 (A1, A2, A3, A4, Z);
input A1, A2, A3, A4;
output Z;
   and and0 (Z, A4, A3, A2, A1);
endmodule
`endcelldefine

`celldefine
module an04d1 (A1, A2, A3, A4, Z);
input A1, A2, A3, A4;
output Z;
   and and0 (Z, A4, A3, A2, A1);
endmodule
`endcelldefine

`celldefine
module an04d2 (A1, A2, A3, A4, Z);
input A1, A2, A3, A4;
output Z;
   and and0 (Z, A4, A3, A2, A1);
endmodule
`endcelldefine

`celldefine
module an04d4 (A1, A2, A3, A4, Z);
input A1, A2, A3, A4;
output Z;
   and and0 (Z, A4, A3, A2, A1);
endmodule
`endcelldefine

`celldefine
module bh01d1 (I);
inout I;
   buf (weak0,weak1) buf0 (I, I);
endmodule
`endcelldefine

`celldefine
module cg01d0 (A, B, CI, CO);
input A, B, CI;
output CO;
wire g_1_out, g_2_out, g_3_out;
   and and0 (g_1_out, B, A);
   and and1 (g_2_out, CI, B);
   and and2 (g_3_out, CI, A);
   or or3 (CO, g_1_out, g_2_out, g_3_out);
endmodule
`endcelldefine

`celldefine
module cg01d1 (A, B, CI, CO);
input A, B, CI;
output CO;
wire g_1_out, g_2_out, g_3_out;
   and and0 (g_1_out, B, A);
   and and1 (g_2_out, CI, B);
   and and2 (g_3_out, CI, A);
   or or3 (CO, g_1_out, g_2_out, g_3_out);
endmodule
`endcelldefine

`celldefine
module cg01d2 (A, B, CI, CO);
input A, B, CI;
output CO;
wire g_1_out, g_2_out, g_3_out;
   and and0 (g_1_out, B, A);
   and and1 (g_2_out, CI, B);
   and and2 (g_3_out, CI, A);
   or or3 (CO, g_1_out, g_2_out, g_3_out);
endmodule
`endcelldefine

`celldefine
module U_FD_N_SD_RB_SB_NO_QN (QN, D, CP, TI, TE, RB, SB, NOTIFIER_REG);
input D, CP, TI, TE, RB, SB, NOTIFIER_REG;
output QN;
wire _mux1;
   _DFF _dff0 (!RB, !SB, !CP, _mux1, QN);
   _MUX _mux1 (TE, !D, !TI, _mux1);
endmodule
`endcelldefine

`celldefine
module U_FD_N_SD_RB_SB_QN (QN, D, CP, TI, TE, RB, SB);
input D, CP, TI, TE, RB, SB;
output QN;
wire _mux1;
   _DFF _dff0 (!RB, !SB, !CP, _mux1, QN);
   _MUX _mux1 (TE, !D, !TI, _mux1);
endmodule
`endcelldefine

`celldefine
module U_FD_N_SD_RB_SB_NO (Q, D, CP, TI, TE, RB, SB, NOTIFIER_REG);
input D, CP, TI, TE, RB, SB, NOTIFIER_REG;
output Q;
wire _mux1;
   _DFF _dff0 (!SB, !RB, !CP, _mux1, Q);
   _MUX _mux1 (TE, D, TI, _mux1);
endmodule
`endcelldefine

`celldefine
module U_FD_P_SD_RB_SB_NO_QN (QN, D, CP, TI, TE, RB, SB, NOTIFIER_REG);
input D, CP, TI, TE, RB, SB, NOTIFIER_REG;
output QN;
wire _mux1;
   _DFF _dff0 (!RB, !SB, CP, _mux1, QN);
   _MUX _mux1 (TE, !D, !TI, _mux1);
endmodule
`endcelldefine

`celldefine
module U_FD_P_SD_RB_SB_QN (QN, D, CP, TI, TE, RB, SB);
input D, CP, TI, TE, RB, SB;
output QN;
wire _mux1;
   _DFF _dff0 (!RB, !SB, CP, _mux1, QN);
   _MUX _mux1 (TE, !D, !TI, _mux1);
endmodule
`endcelldefine

`celldefine
module U_FD_P_SD_RB_SB_NO (Q, D, CP, TI, TE, RB, SB, NOTIFIER_REG);
input D, CP, TI, TE, RB, SB, NOTIFIER_REG;
output Q;
wire _mux1;
   _DFF _dff0 (!SB, !RB, CP, _mux1, Q);
   _MUX _mux1 (TE, D, TI, _mux1);
endmodule
`endcelldefine

`celldefine
module U_FJK_N_RB_SB_X_NO (Q, J, K, CP, RB, SB, NOTIFIER_REG);
input J, K, CP, RB, SB, NOTIFIER_REG;
output Q;
wire _mux1;
   _DFF _dff0 (!SB, !RB, !CP, _mux1, Q);
   _MUX _mux1 (Q, J, !K, _mux1);
endmodule
`endcelldefine

`celldefine
module U_FJK_P_RB_SB_X_NO (Q, J, K, CP, RB, SB, NOTIFIER_REG);
input J, K, CP, RB, SB, NOTIFIER_REG;
output Q;
wire _mux1;
   _DFF _dff0 (!SB, !RB, CP, _mux1, Q);
   _MUX _mux1 (Q, J, !K, _mux1);
endmodule
`endcelldefine

`celldefine
module U_FT_N_RB_SB_X_NO (Q, CP, RB, SB, NOTIFIER_REG);
input CP, RB, SB, NOTIFIER_REG;
output Q;
   _DFF _dff0 (!SB, !RB, !CP, !Q, Q);
endmodule
`endcelldefine

`celldefine
module U_FT_N_TE_RB_SB_NO (Q, TE, CP, RB, SB, NOTIFIER_REG);
input TE, CP, RB, SB, NOTIFIER_REG;
output Q;
wire _and2, _and1, _or3, _and4;
   _DFF _dff0 (!SB, !RB, !CP, _or3, Q);
   _AND _and1 (1'bX, _and2, _and1);
   _NAND _and2 (Q, TE, _and2);
   _OR _or3 (_and1, _and4, _or3);
   _AND _and4 (TE, !Q, _and4);
endmodule
`endcelldefine

`celldefine
module U_FT_P_RB_SB_X_NO (Q, CP, RB, SB, NOTIFIER_REG);
input CP, RB, SB, NOTIFIER_REG;
output Q;
   _DFF _dff0 (!SB, !RB, CP, !Q, Q);
endmodule
`endcelldefine

`celldefine
module U_FT_P_TE_RB_SB_NO (Q, TE, CP, RB, SB, NOTIFIER_REG);
input TE, CP, RB, SB, NOTIFIER_REG;
output Q;
wire _and2, _and1, _or3, _and4;
   _DFF _dff0 (!SB, !RB, CP, _or3, Q);
   _AND _and1 (1'bX, _and2, _and1);
   _NAND _and2 (Q, TE, _and2);
   _OR _or3 (_and1, _and4, _or3);
   _AND _and4 (TE, !Q, _and4);
endmodule
`endcelldefine

`celldefine
module U_LD_N_RB_SB_X_NO (Q, D, CK, RB, SB, NOTIFIER_REG);
input D, CK, RB, SB, NOTIFIER_REG;
output Q;
   _DLAT _dlat0 (!SB, !RB, !CK, D, Q);
endmodule
`endcelldefine

`celldefine
module U_LD_N_SB_RB_QN_NO (QN, D, CK, RB, SB, NOTIFIER_REG);
input D, CK, RB, SB, NOTIFIER_REG;
output QN;
   _DLAT _dlat0 (!RB, !SB, !CK, !D, QN);
endmodule
`endcelldefine

`celldefine
module U_LD_P_RB_SB_X_NO (Q, D, CK, RB, SB, NOTIFIER_REG);
input D, CK, RB, SB, NOTIFIER_REG;
output Q;
   _DLAT _dlat0 (!SB, !RB, CK, D, Q);
endmodule
`endcelldefine

`celldefine
module U_FT_N_TE_RB_SB_QN (QN, TE, CP, RB, SB);
input TE, CP, RB, SB;
output QN;
wire _and2, _and1, _or3, _and4;
   _DFF _dff0 (!RB, !SB, !CP, _or3, QN);
   _AND _and1 (1'bX, _and2, _and1);
   _NAND _and2 (QN, TE, _and2);
   _OR _or3 (_and1, _and4, _or3);
   _AND _and4 (TE, !QN, _and4);
endmodule
`endcelldefine

`celldefine
module U_FT_N_TE_RB_SB_QN_NO (QN, TE, CP, RB, SB, NOTIFIER_REG);
input TE, CP, RB, SB, NOTIFIER_REG;
output QN;
wire _and2, _and1, _or3, _and4;
   _DFF _dff0 (!RB, !SB, !CP, _or3, QN);
   _AND _and1 (1'bX, _and2, _and1);
   _NAND _and2 (QN, TE, _and2);
   _OR _or3 (_and1, _and4, _or3);
   _AND _and4 (TE, !QN, _and4);
endmodule
`endcelldefine

`celldefine
module U_FJK_N_RB_SB_QN_NO (QN, J, K, CP, RB, SB, NOTIFIER_REG);
input J, K, CP, RB, SB, NOTIFIER_REG;
output QN;
wire _mux1;
   _DFF _dff0 (!RB, !SB, !CP, _mux1, QN);
   _MUX _mux1 (QN, K, !J, _mux1);
endmodule
`endcelldefine

`celldefine
module U_FD_N_SD_RB_NO_QN (QN, D, CP, TI, TE, RB, NOTIFIER_REG);
input D, CP, TI, TE, RB, NOTIFIER_REG;
output QN;
wire _mux1;
   _DFF _dff0 (!RB, 1'b0, !CP, _mux1, QN);
   _MUX _mux1 (TE, !D, !TI, _mux1);
endmodule
`endcelldefine

`celldefine
module U_A2_OI2_OI (Z, A, B, C, D);
input A, B, C, D;
output Z;
wire _nor0, _and1;
   _NOR _nor0 (C, D, _nor0);
   _AND _and1 (B, A, _and1);
   _NOR _or2 (_nor0, _and1, Z);
endmodule
`endcelldefine

`celldefine
module U_AO3 (Z, A, B, C);
input A, B, C;
output Z;
wire _or1, _and0, _and2;
   _AND _and0 (C, B, _and0);
   _OR _or1 (C, B, _or1);
   _AND _and2 (_or1, A, _and2);
   _OR _or3 (_and0, _and2, Z);
endmodule
`endcelldefine

`celldefine
module U_AOI_1_2_2 (Y, A, B, C, D, E);
input A, B, C, D, E;
output Y;
wire _and0, _and1;
   _AND _and0 (D, C, _and0);
   _AND _and1 (B, A, _and1);
   _NOR _or2 (_and0, _and1, E, Y);
endmodule
`endcelldefine

`celldefine
module U_AOI_1_2_3 (Y, A, B, C, D, E, F);
input A, B, C, D, E, F;
output Y;
wire _and0, _and1;
   _AND _and0 (C, B, A, _and0);
   _AND _and1 (E, D, _and1);
   _NOR _or2 (_and0, _and1, F, Y);
endmodule
`endcelldefine

`celldefine
module U_AOI_2_2 (Z, A, B, C, D);
input A, B, C, D;
output Z;
wire _and0, _and1;
   _AND _and0 (D, C, _and0);
   _AND _and1 (B, A, _and1);
   _NOR _or2 (_and0, _and1, Z);
endmodule
`endcelldefine

`celldefine
module U_AOI_2_2_2 (Y, A, B, C, D, E, F);
input A, B, C, D, E, F;
output Y;
wire _and0, _and1, _and3;
   _AND _and0 (F, E, _and0);
   _AND _and1 (D, C, _and1);
   _NOR _or2 (_and0, _and1, _and3, Y);
   _AND _and3 (B, A, _and3);
endmodule
`endcelldefine

`celldefine
module U_AOI_2_3 (Y, A, B, C, D, E);
input A, B, C, D, E;
output Y;
wire _and0, _and1;
   _AND _and0 (C, B, A, _and0);
   _AND _and1 (E, D, _and1);
   _NOR _or2 (_and0, _and1, Y);
endmodule
`endcelldefine

`celldefine
module U_AOI_3 (Z, A, B, C);
input A, B, C;
output Z;
wire _nand1, _nor0, _and2;
   _NOR _nor0 (B, C, _nor0);
   _NAND _nand1 (B, C, _nand1);
   _AND _and2 (_nand1, !A, _and2);
   _OR _or3 (_nor0, _and2, Z);
endmodule
`endcelldefine

`celldefine
module U_AOI_3_3 (Y, A, B, C, D, E, F);
input A, B, C, D, E, F;
output Y;
wire _and0, _and1;
   _AND _and0 (F, E, D, _and0);
   _AND _and1 (C, B, A, _and1);
   _NOR _or2 (_and0, _and1, Y);
endmodule
`endcelldefine

`celldefine
module U_AO_2_2 (Z, A, B, C, D);
input A, B, C, D;
output Z;
wire _and0, _and1;
   _AND _and0 (D, C, _and0);
   _AND _and1 (B, A, _and1);
   _OR _or2 (_and0, _and1, Z);
endmodule
`endcelldefine

`celldefine
module U_AO_2_2_2 (Y, A, B, C, D, E, F);
input A, B, C, D, E, F;
output Y;
wire _and0, _and1, _and3;
   _AND _and0 (F, E, _and0);
   _AND _and1 (D, C, _and1);
   _OR _or2 (_and0, _and1, _and3, Y);
   _AND _and3 (B, A, _and3);
endmodule
`endcelldefine

`celldefine
module U_AO_2_3 (Y, A, B, C, D, E);
input A, B, C, D, E;
output Y;
wire _and0, _and1;
   _AND _and0 (C, B, A, _and0);
   _AND _and1 (E, D, _and1);
   _OR _or2 (_and0, _and1, Y);
endmodule
`endcelldefine

`celldefine
module U_AO_3 (Z, A, B, C);
input A, B, C;
output Z;
wire _and0;
   _AND _and0 (C, B, _and0);
   _OR _or1 (_and0, A, Z);
endmodule
`endcelldefine

`celldefine
module U_AO_3_3 (Y, A, B, C, D, E, F);
input A, B, C, D, E, F;
output Y;
wire _and0, _and1;
   _AND _and0 (F, E, D, _and0);
   _AND _and1 (C, B, A, _and1);
   _OR _or2 (_and0, _and1, Y);
endmodule
`endcelldefine

`celldefine
module U_AXO_2_2 (Z, A, B, C, D);
input A, B, C, D;
output Z;
wire _and0, _and1, _nand3, _and4;
   _AND _and0 (D, C, !B, _and0);
   _AND _and1 (D, C, !A, _and1);
   _OR _or2 (_and0, _and1, _and4, Z);
   _NAND _nand3 (C, D, _nand3);
   _AND _and4 (_nand3, B, A, _and4);
endmodule
`endcelldefine

`celldefine
module U_AXO_2_3 (Z, A, B, C, D, E);
input A, B, C, D, E;
output Z;
wire _and0, _and1, _nand3, _and4;
   _AND _and0 (E, D, C, !B, _and0);
   _AND _and1 (E, D, C, !A, _and1);
   _OR _or2 (_and0, _and1, _and4, Z);
   _NAND _nand3 (D, E, C, _nand3);
   _AND _and4 (_nand3, B, A, _and4);
endmodule
`endcelldefine

`celldefine
module U_AXO_2_4 (Z, A, B, C, D, E, F);
input A, B, C, D, E, F;
output Z;
wire _and0, _and1, _nand3, _and4;
   _AND _and0 (F, E, D, C, !B, _and0);
   _AND _and1 (F, E, D, C, !A, _and1);
   _OR _or2 (_and0, _and1, _and4, Z);
   _NAND _nand3 (E, F, D, C, _nand3);
   _AND _and4 (_nand3, B, A, _and4);
endmodule
`endcelldefine

`celldefine
module U_BUF (Z, TN, EN);
input TN, EN;
output Z;
   _NAND _and0 (TN, !EN, Z);
endmodule
`endcelldefine

`celldefine
module U_BUF_1 (Z, TN, EN);
input TN, EN;
output Z;
   _AND _and0 (TN, !EN, Z);
endmodule
`endcelldefine

`celldefine
module U_DIFF_BUF (Y, A, AN);
input A, AN;
output Y;
wire _and1, _and2;
   _DLAT _dlat0 (_and1, _and2, 1'b0, 1'b0, Y);
   _AND _and1 (A, !AN, _and1);
   _AND _and2 (AN, !A, _and2);
endmodule
`endcelldefine

`celldefine
module U_FD_LD_P_RB_SB (Q, CNTRL, D, CP, RB, SB);
input CNTRL, D, CP, RB, SB;
output Q;
   _TIEX _tiex0 (CNTRL, D, CP, RB, SB, Q);
endmodule
`endcelldefine

`celldefine
module U_FD_N (Q, D, CP);
input D, CP;
output Q;
   _DFF _dff0 (1'b0, 1'b0, !CP, D, Q);
endmodule
`endcelldefine

`celldefine
module U_FD_N_CEB_NO (Q, D, CP, CEB, NOTIFIER_REG);
input D, CP, CEB, NOTIFIER_REG;
output Q;
wire _mux1;
   _DFF _dff0 (1'b0, 1'b0, !CP, _mux1, Q);
   _MUX _mux1 (CEB, D, Q, _mux1);
endmodule
`endcelldefine

`celldefine
module U_FD_N_CEB_S_NO (Q, D, CP, S, CEB, NOTIFIER_REG);
input D, CP, S, CEB, NOTIFIER_REG;
output Q;
wire _mux1;
   _DFF _dff0 (S, 1'b0, !CP, _mux1, Q);
   _MUX _mux1 (CEB, D, Q, _mux1);
endmodule
`endcelldefine

`celldefine
module U_FD_N_CE_NO (Q, D, CP, CEB, NOTIFIER_REG);
input D, CP, CEB, NOTIFIER_REG;
output Q;
wire _mux1;
   _DFF _dff0 (1'b0, 1'b0, !CP, _mux1, Q);
   _MUX _mux1 (CEB, Q, D, _mux1);
endmodule
`endcelldefine

`celldefine
module U_FD_N_CE_RB_NO (Q, D, CP, RB, CE, NOTIFIER_REG);
input D, CP, RB, CE, NOTIFIER_REG;
output Q;
wire _mux1;
   _DFF _dff0 (1'b0, !RB, !CP, _mux1, Q);
   _MUX _mux1 (CE, Q, D, _mux1);
endmodule
`endcelldefine

`celldefine
module U_FD_N_CE_S_NO (Q, D, CP, S, CE, NOTIFIER_REG);
input D, CP, S, CE, NOTIFIER_REG;
output Q;
wire _mux1;
   _DFF _dff0 (S, 1'b0, !CP, _mux1, Q);
   _MUX _mux1 (CE, Q, D, _mux1);
endmodule
`endcelldefine

`celldefine
module U_FD_N_RB_SB (Q, D, CP, RB, SB);
input D, CP, RB, SB;
output Q;
   _DFF _dff0 (!SB, !RB, !CP, D, Q);
endmodule
`endcelldefine

`celldefine
module U_FD_N_RB_SB_QN (QN, D, CP, RB, SB);
input D, CP, RB, SB;
output QN;
   _DFF _dff0 (!RB, !SB, !CP, !D, QN);
endmodule
`endcelldefine

`celldefine
module U_FD_N_RB_SB_X (Q, D, CP, RB, SB);
input D, CP, RB, SB;
output Q;
   _DFF _dff0 (!SB, !RB, !CP, D, Q);
endmodule
`endcelldefine

`celldefine
module U_FD_N_R_NO (Q, D, CP, R, NOTIFIER_REG);
input D, CP, R, NOTIFIER_REG;
output Q;
   _DFF _dff0 (1'b0, R, !CP, D, Q);
endmodule
`endcelldefine

`celldefine
module U_FD_N_R_S (Q, D, CP, R, S);
input D, CP, R, S;
output Q;
   _DFF _dff0 (S, R, !CP, D, Q);
endmodule
`endcelldefine

`celldefine
module U_FD_N_R_S_NO (Q, D, CP, R, S, NOTIFIER_REG);
input D, CP, R, S, NOTIFIER_REG;
output Q;
   _DFF _dff0 (S, R, !CP, D, Q);
endmodule
`endcelldefine

`celldefine
module U_FD_N_R_S_QN (QN, D, CP, R, S);
input D, CP, R, S;
output QN;
   _DFF _dff0 (R, S, !CP, !D, QN);
endmodule
`endcelldefine

`celldefine
module U_FD_N_R_S_X (Q, D, CP, R, S);
input D, CP, R, S;
output Q;
   _DFF _dff0 (S, R, !CP, D, Q);
endmodule
`endcelldefine

`celldefine
module U_FD_N_R_S_X_NO (Q, D, CP, R, S, NOTIFIER_REG);
input D, CP, R, S, NOTIFIER_REG;
output Q;
   _DFF _dff0 (S, R, !CP, D, Q);
endmodule
`endcelldefine

`celldefine
module U_FD_N_SB_RB (Q, D, CP, RB, SB);
input D, CP, RB, SB;
output Q;
   _DFF _dff0 (!SB, !RB, !CP, D, Q);
endmodule
`endcelldefine

`celldefine
module U_FD_N_SB_RB_NO (Q, D, CP, RB, SB, NOTIFIER_REG);
input D, CP, RB, SB, NOTIFIER_REG;
output Q;
   _DFF _dff0 (!SB, !RB, !CP, D, Q);
endmodule
`endcelldefine

`celldefine
module U_FD_N_SB_RB_QN (QN, D, CP, RB, SB);
input D, CP, RB, SB;
output QN;
   _DFF _dff0 (!RB, !SB, !CP, !D, QN);
endmodule
`endcelldefine

`celldefine
module U_FD_N_SD (Q, D, CP, TI, TE);
input D, CP, TI, TE;
output Q;
wire _mux1;
   _DFF _dff0 (1'b0, 1'b0, !CP, _mux1, Q);
   _MUX _mux1 (TE, D, TI, _mux1);
endmodule
`endcelldefine

`celldefine
module U_FD_N_SD_NO (Q, D, CP, TI, TE, NOTIFIER_REG);
input D, CP, TI, TE, NOTIFIER_REG;
output Q;
wire _mux1;
   _DFF _dff0 (1'b0, 1'b0, !CP, _mux1, Q);
   _MUX _mux1 (TE, D, TI, _mux1);
endmodule
`endcelldefine

`celldefine
module U_FD_N_SD_RB_NO (Q, D, CP, TI, TE, RB, NOTIFIER_REG);
input D, CP, TI, TE, RB, NOTIFIER_REG;
output Q;
wire _mux1;
   _DFF _dff0 (1'b0, !RB, !CP, _mux1, Q);
   _MUX _mux1 (TE, D, TI, _mux1);
endmodule
`endcelldefine

`celldefine
module U_FD_N_SD_RB_SB (Q, D, CP, TI, TE, RB, SB);
input D, CP, TI, TE, RB, SB;
output Q;
wire _mux1;
   _DFF _dff0 (!SB, !RB, !CP, _mux1, Q);
   _MUX _mux1 (TE, D, TI, _mux1);
endmodule
`endcelldefine

`celldefine
module U_FD_N_SD_R_NO (Q, D, CP, TI, TE, R, NOTIFIER_REG);
input D, CP, TI, TE, R, NOTIFIER_REG;
output Q;
wire _mux1;
   _DFF _dff0 (1'b0, R, !CP, _mux1, Q);
   _MUX _mux1 (TE, D, TI, _mux1);
endmodule
`endcelldefine

`celldefine
module U_FD_N_SD_SB_NO (Q, D, CP, TI, TE, SB, NOTIFIER_REG);
input D, CP, TI, TE, SB, NOTIFIER_REG;
output Q;
wire _mux1;
   _DFF _dff0 (!SB, 1'b0, !CP, _mux1, Q);
   _MUX _mux1 (TE, D, TI, _mux1);
endmodule
`endcelldefine

`celldefine
module U_FD_N_SD_S_NO (Q, D, CP, TI, TE, SB, NOTIFIER_REG);
input D, CP, TI, TE, SB, NOTIFIER_REG;
output Q;
wire _mux1;
   _DFF _dff0 (SB, 1'b0, !CP, _mux1, Q);
   _MUX _mux1 (TE, D, TI, _mux1);
endmodule
`endcelldefine

`celldefine
module U_FD_N_S_NO (Q, D, CP, S, NOTIFIER_REG);
input D, CP, S, NOTIFIER_REG;
output Q;
   _DFF _dff0 (S, 1'b0, !CP, D, Q);
endmodule
`endcelldefine

`celldefine
module U_FD_N_S_R (Q, D, CP, R, S);
input D, CP, R, S;
output Q;
   _DFF _dff0 (S, R, !CP, D, Q);
endmodule
`endcelldefine

`celldefine
module U_FD_N_S_R_NO (Q, D, CP, R, S, NOTIFIER_REG);
input D, CP, R, S, NOTIFIER_REG;
output Q;
   _DFF _dff0 (S, R, !CP, D, Q);
endmodule
`endcelldefine

`celldefine
module U_FD_N_S_R_NO_QN (QN, D, CP, R, S, NOTIFIER_REG);
input D, CP, R, S, NOTIFIER_REG;
output QN;
   _DFF _dff0 (R, S, !CP, !D, QN);
endmodule
`endcelldefine

`celldefine
module U_FD_N_S_R_QN (QN, D, CP, R, S);
input D, CP, R, S;
output QN;
   _DFF _dff0 (R, S, !CP, !D, QN);
endmodule
`endcelldefine

`celldefine
module U_FD_P (Q, D, CP);
input D, CP;
output Q;
   _DFF _dff0 (1'b0, 1'b0, CP, D, Q);
endmodule
`endcelldefine

`celldefine
module U_FD_P_CEB_NO (Q, D, CP, CEB, NOTIFIER_REG);
input D, CP, CEB, NOTIFIER_REG;
output Q;
wire _mux1;
   _DFF _dff0 (1'b0, 1'b0, CP, _mux1, Q);
   _MUX _mux1 (CEB, D, Q, _mux1);
endmodule
`endcelldefine

`celldefine
module U_FD_P_CEB_S_NO (Q, D, CP, S, CEB, NOTIFIER_REG);
input D, CP, S, CEB, NOTIFIER_REG;
output Q;
wire _mux1;
   _DFF _dff0 (S, 1'b0, CP, _mux1, Q);
   _MUX _mux1 (CEB, D, Q, _mux1);
endmodule
`endcelldefine

`celldefine
module U_FD_P_CE_NO (Q, D, CP, CE, NOTIFIER_REG);
input D, CP, CE, NOTIFIER_REG;
output Q;
wire _mux1;
   _DFF _dff0 (1'b0, 1'b0, CP, _mux1, Q);
   _MUX _mux1 (CE, Q, D, _mux1);
endmodule
`endcelldefine

`celldefine
module U_FD_P_CE_RB_NO (Q, D, CP, RB, CE, NOTIFIER_REG);
input D, CP, RB, CE, NOTIFIER_REG;
output Q;
wire _mux1;
   _DFF _dff0 (1'b0, !RB, CP, _mux1, Q);
   _MUX _mux1 (CE, Q, D, _mux1);
endmodule
`endcelldefine

`celldefine
module U_FD_P_CE_S_NO (Q, D, CP, S, CE, NOTIFIER_REG);
input D, CP, S, CE, NOTIFIER_REG;
output Q;
wire _mux1;
   _DFF _dff0 (S, 1'b0, CP, _mux1, Q);
   _MUX _mux1 (CE, Q, D, _mux1);
endmodule
`endcelldefine

`celldefine
module U_FD_P_PLD (Q, D, CP, PD, PLD);
input D, CP, PD, PLD;
output Q;
wire _dlat1;
   _DLAT _dff0 (1'b0, 1'b0, !PLD, PD, CP, _dlat1, Q);
   _DLAT _dlat1 (1'b0, 1'b0, !PLD, PD, !CP, D, _dlat1);
endmodule
`endcelldefine

`celldefine
module U_FD_P_PLD_NO (Q, D, CP, PD, PLD, NOTIFIER_REG);
input D, CP, PD, PLD, NOTIFIER_REG;
output Q;
wire _dlat1;
   _DLAT _dff0 (1'b0, 1'b0, !PLD, PD, CP, _dlat1, Q);
   _DLAT _dlat1 (1'b0, 1'b0, !PLD, PD, !CP, D, _dlat1);
endmodule
`endcelldefine

`celldefine
module U_FD_P_R (Q, D, CP, R);
input D, CP, R;
output Q;
   _DFF _dff0 (1'b0, R, CP, D, Q);
endmodule
`endcelldefine

`celldefine
module U_FD_P_RB (Q, D, CP, RB);
input D, CP, RB;
output Q;
   _DFF _dff0 (1'b0, !RB, CP, D, Q);
endmodule
`endcelldefine

`celldefine
module U_FD_P_RBC (Q, D, CP, RB);
input D, CP, RB;
output Q;
wire _nand1;
   _DFF _dff0 (1'b0, 1'b0, CP, _nand1, Q);
   _AND _nand1 (D, RB, _nand1);
endmodule
`endcelldefine

`celldefine
module U_FD_P_RBC_LD (Q, D, CP, RB, LD);
input D, CP, RB, LD;
output Q;
wire _and2, _and4, _or3, _and1, _or5, _and6, _or7, _and8;
   _DFF _dff0 (1'b0, 1'b0, CP, _or5, Q);
   _AND _and1 (1'bX, _or3, _and1);
   _AND _and2 (LD, !D, _and2);
   _NOR _or3 (_and2, !RB, _and4, _or3);
   _AND _and4 (RB, !Q, _and4);
   _OR _or5 (_and1, _and8, _or5);
   _AND _and6 (D, LD, _and6);
   _OR _or7 (Q, _and6, _or7);
   _AND _and8 (_or7, RB, _and8);
endmodule
`endcelldefine

`celldefine
module U_FD_P_RBC_LD_NO (Q, D, CP, RB, LD, NOTIFIER_REG);
input D, CP, RB, LD, NOTIFIER_REG;
output Q;
wire _and2, _and4, _or3, _and1, _or5, _and6, _or7, _and8;
   _DFF _dff0 (1'b0, 1'b0, CP, _or5, Q);
   _AND _and1 (1'bX, _or3, _and1);
   _AND _and2 (LD, !D, _and2);
   _NOR _or3 (_and2, !RB, _and4, _or3);
   _AND _and4 (RB, !Q, _and4);
   _OR _or5 (_and1, _and8, _or5);
   _AND _and6 (D, LD, _and6);
   _OR _or7 (Q, _and6, _or7);
   _AND _and8 (_or7, RB, _and8);
endmodule
`endcelldefine

`celldefine
module U_FD_P_RBC_NO (Q, D, CP, RB, NOTIFIER_REG);
input D, CP, RB, NOTIFIER_REG;
output Q;
wire _nand1;
   _DFF _dff0 (1'b0, 1'b0, CP, _nand1, Q);
   _AND _nand1 (D, RB, _nand1);
endmodule
`endcelldefine

`celldefine
module U_FD_P_RB_PLD (Q, D, CP, PD, PLD, RB);
input D, CP, PD, PLD, RB;
output Q;
wire _dlat1;
   _DLAT _dff0 (1'b0, !RB, !PLD, PD, CP, _dlat1, Q);
   _DLAT _dlat1 (1'b0, !RB, !PLD, PD, !CP, D, _dlat1);
endmodule
`endcelldefine

`celldefine
module U_FD_P_RB_PLD_NO (Q, D, CP, PD, PLD, RB, NOTIFIER_REG);
input D, CP, PD, PLD, RB, NOTIFIER_REG;
output Q;
wire _dlat1;
   _DLAT _dff0 (1'b0, !RB, !PLD, PD, CP, _dlat1, Q);
   _DLAT _dlat1 (1'b0, !RB, !PLD, PD, !CP, D, _dlat1);
endmodule
`endcelldefine

`celldefine
module U_FD_P_RB_SB (Q, D, CP, RB, SB);
input D, CP, RB, SB;
output Q;
   _DFF _dff0 (!SB, !RB, CP, D, Q);
endmodule
`endcelldefine

`celldefine
module U_FD_P_RB_SB_QN (QN, D, CP, RB, SB);
input D, CP, RB, SB;
output QN;
   _DFF _dff0 (!RB, !SB, CP, !D, QN);
endmodule
`endcelldefine

`celldefine
module U_FD_P_RB_SB_X (Q, D, CP, RB, SB);
input D, CP, RB, SB;
output Q;
   _DFF _dff0 (!SB, !RB, CP, D, Q);
endmodule
`endcelldefine

`celldefine
module U_FD_P_R_NO (Q, D, CP, R, NOTIFIER_REG);
input D, CP, R, NOTIFIER_REG;
output Q;
   _DFF _dff0 (1'b0, R, CP, D, Q);
endmodule
`endcelldefine

`celldefine
module U_FD_P_R_PLD (Q, D, CP, PD, PLD, R);
input D, CP, PD, PLD, R;
output Q;
wire _dlat1;
   _DLAT _dff0 (1'b0, R, !PLD, PD, CP, _dlat1, Q);
   _DLAT _dlat1 (1'b0, R, !PLD, PD, !CP, D, _dlat1);
endmodule
`endcelldefine

`celldefine
module U_FD_P_R_PLD_NO (Q, D, CP, PD, PLD, R, NOTIFIER_REG);
input D, CP, PD, PLD, R, NOTIFIER_REG;
output Q;
wire _dlat1;
   _DLAT _dff0 (1'b0, R, !PLD, PD, CP, _dlat1, Q);
   _DLAT _dlat1 (1'b0, R, !PLD, PD, !CP, D, _dlat1);
endmodule
`endcelldefine

`celldefine
module U_FD_P_R_S (Q, D, CP, R, S);
input D, CP, R, S;
output Q;
   _DFF _dff0 (S, R, CP, D, Q);
endmodule
`endcelldefine

`celldefine
module U_FD_P_R_S_NO (Q, D, CP, R, S, NOTIFIER_REG);
input D, CP, R, S, NOTIFIER_REG;
output Q;
   _DFF _dff0 (S, R, CP, D, Q);
endmodule
`endcelldefine

`celldefine
module U_FD_P_R_S_NO_QN (QN, D, CP, R, S, NOTIFIER_REG);
input D, CP, R, S, NOTIFIER_REG;
output QN;
   _DFF _dff0 (R, S, CP, !D, QN);
endmodule
`endcelldefine

`celldefine
module U_FD_P_R_S_QN (QN, D, CP, R, S);
input D, CP, R, S;
output QN;
   _DFF _dff0 (R, S, CP, !D, QN);
endmodule
`endcelldefine

`celldefine
module U_FD_P_R_S_X (Q, D, CP, R, S);
input D, CP, R, S;
output Q;
   _DFF _dff0 (S, R, CP, D, Q);
endmodule
`endcelldefine

`celldefine
module U_FD_P_R_S_X_NO (Q, D, CP, R, S, NOTIFIER_REG);
input D, CP, R, S, NOTIFIER_REG;
output Q;
   _DFF _dff0 (S, R, CP, D, Q);
endmodule
`endcelldefine

`celldefine
module U_FD_P_SB (Q, D, CP, SB);
input D, CP, SB;
output Q;
   _DFF _dff0 (!SB, 1'b0, CP, D, Q);
endmodule
`endcelldefine

`celldefine
module U_FD_P_SB_PLD (Q, D, CP, PD, PLD, SB);
input D, CP, PD, PLD, SB;
output Q;
wire _dlat1;
   _DLAT _dff0 (!SB, 1'b0, !PLD, PD, CP, _dlat1, Q);
   _DLAT _dlat1 (!SB, 1'b0, !PLD, PD, !CP, D, _dlat1);
endmodule
`endcelldefine

`celldefine
module U_FD_P_SB_PLD_NO (Q, D, CP, PD, PLD, SB, NOTIFIER_REG);
input D, CP, PD, PLD, SB, NOTIFIER_REG;
output Q;
wire _dlat1;
   _DLAT _dff0 (!SB, 1'b0, !PLD, PD, CP, _dlat1, Q);
   _DLAT _dlat1 (!SB, 1'b0, !PLD, PD, !CP, D, _dlat1);
endmodule
`endcelldefine

`celldefine
module U_FD_P_SB_RB (Q, D, CP, RB, SB);
input D, CP, RB, SB;
output Q;
   _DFF _dff0 (!SB, !RB, CP, D, Q);
endmodule
`endcelldefine

`celldefine
module U_FD_P_SB_RB_NO (Q, D, CP, RB, SB, NOTIFIER_REG);
input D, CP, RB, SB, NOTIFIER_REG;
output Q;
   _DFF _dff0 (!SB, !RB, CP, D, Q);
endmodule
`endcelldefine

`celldefine
module U_FD_P_SB_RB_QN (QN, D, CP, RB, SB);
input D, CP, RB, SB;
output QN;
   _DFF _dff0 (!RB, !SB, CP, !D, QN);
endmodule
`endcelldefine

`celldefine
module U_FD_P_SD (Q, D, CP, TI, TE);
input D, CP, TI, TE;
output Q;
wire _mux1;
   _DFF _dff0 (1'b0, 1'b0, CP, _mux1, Q);
   _MUX _mux1 (TE, D, TI, _mux1);
endmodule
`endcelldefine

`celldefine
module U_FD_P_SD_NO (Q, D, CP, TI, TE, NOTIFIER_REG);
input D, CP, TI, TE, NOTIFIER_REG;
output Q;
wire _mux1;
   _DFF _dff0 (1'b0, 1'b0, CP, _mux1, Q);
   _MUX _mux1 (TE, D, TI, _mux1);
endmodule
`endcelldefine

`celldefine
module U_FD_P_SD_RB (Q, D, CP, TI, TE, RB);
input D, CP, TI, TE, RB;
output Q;
wire _mux1;
   _DFF _dff0 (1'b0, !RB, CP, _mux1, Q);
   _MUX _mux1 (TE, D, TI, _mux1);
endmodule
`endcelldefine

`celldefine
module U_FD_P_SD_RB_NO (Q, D, CP, TI, TE, RB, NOTIFIER_REG);
input D, CP, TI, TE, RB, NOTIFIER_REG;
output Q;
wire _mux1;
   _DFF _dff0 (1'b0, !RB, CP, _mux1, Q);
   _MUX _mux1 (TE, D, TI, _mux1);
endmodule
`endcelldefine

`celldefine
module U_FD_P_SD_RB_SB (Q, D, CP, TI, TE, RB, SB);
input D, CP, TI, TE, RB, SB;
output Q;
wire _mux1;
   _DFF _dff0 (!SB, !RB, CP, _mux1, Q);
   _MUX _mux1 (TE, D, TI, _mux1);
endmodule
`endcelldefine

`celldefine
module U_FD_P_SD_R_NO (Q, D, CP, TI, TE, R, NOTIFIER_REG);
input D, CP, TI, TE, R, NOTIFIER_REG;
output Q;
wire _mux1;
   _DFF _dff0 (1'b0, R, CP, _mux1, Q);
   _MUX _mux1 (TE, D, TI, _mux1);
endmodule
`endcelldefine

`celldefine
module U_FD_P_SD_SB (Q, D, CP, TI, TE, SB);
input D, CP, TI, TE, SB;
output Q;
wire _mux1;
   _DFF _dff0 (!SB, 1'b0, CP, _mux1, Q);
   _MUX _mux1 (TE, D, TI, _mux1);
endmodule
`endcelldefine

`celldefine
module U_FD_P_SD_SB_NO (Q, D, CP, TI, TE, SB, NOTIFIER_REG);
input D, CP, TI, TE, SB, NOTIFIER_REG;
output Q;
wire _mux1;
   _DFF _dff0 (!SB, 1'b0, CP, _mux1, Q);
   _MUX _mux1 (TE, D, TI, _mux1);
endmodule
`endcelldefine

`celldefine
module U_FD_P_SD_S_NO (Q, D, CP, TI, TE, SB, NOTIFIER_REG);
input D, CP, TI, TE, SB, NOTIFIER_REG;
output Q;
wire _mux1;
   _DFF _dff0 (SB, 1'b0, CP, _mux1, Q);
   _MUX _mux1 (TE, D, TI, _mux1);
endmodule
`endcelldefine

`celldefine
module U_FD_P_S_NO (Q, D, CP, S, NOTIFIER_REG);
input D, CP, S, NOTIFIER_REG;
output Q;
   _DFF _dff0 (S, 1'b0, CP, D, Q);
endmodule
`endcelldefine

`celldefine
module U_FD_P_S_PLD (Q, D, CP, PD, PLD, S);
input D, CP, PD, PLD, S;
output Q;
wire _dlat1;
   _DLAT _dff0 (S, 1'b0, !PLD, PD, CP, _dlat1, Q);
   _DLAT _dlat1 (S, 1'b0, !PLD, PD, !CP, D, _dlat1);
endmodule
`endcelldefine

`celldefine
module U_FD_P_S_PLD_NO (Q, D, CP, PD, PLD, S, NOTIFIER_REG);
input D, CP, PD, PLD, S, NOTIFIER_REG;
output Q;
wire _dlat1;
   _DLAT _dff0 (S, 1'b0, !PLD, PD, CP, _dlat1, Q);
   _DLAT _dlat1 (S, 1'b0, !PLD, PD, !CP, D, _dlat1);
endmodule
`endcelldefine

`celldefine
module U_FD_P_S_R (Q, D, CP, R, S);
input D, CP, R, S;
output Q;
   _DFF _dff0 (S, R, CP, D, Q);
endmodule
`endcelldefine

`celldefine
module U_FD_P_S_R_NO (Q, D, CP, R, S, NOTIFIER_REG);
input D, CP, R, S, NOTIFIER_REG;
output Q;
   _DFF _dff0 (S, R, CP, D, Q);
endmodule
`endcelldefine

`celldefine
module U_FD_P_S_R_NO_QN (QN, D, CP, R, S, NOTIFIER_REG);
input D, CP, R, S, NOTIFIER_REG;
output QN;
   _DFF _dff0 (R, S, CP, !D, QN);
endmodule
`endcelldefine

`celldefine
module U_FD_P_S_R_QN (QN, D, CP, R, S);
input D, CP, R, S;
output QN;
   _DFF _dff0 (R, S, CP, !D, QN);
endmodule
`endcelldefine

`celldefine
module U_FJKB_N_NO (Q, J, K, CP, NOTIFIER_REG);
input J, K, CP, NOTIFIER_REG;
output Q;
wire _mux1;
   _DFF _dff0 (1'b0, 1'b0, !CP, _mux1, Q);
   _MUX _mux1 (Q, J, K, _mux1);
endmodule
`endcelldefine

`celldefine
module U_FJKB_N_RB_NO (Q, J, K, CP, RB, NOTIFIER_REG);
input J, K, CP, RB, NOTIFIER_REG;
output Q;
wire _mux1;
   _DFF _dff0 (1'b0, !RB, !CP, _mux1, Q);
   _MUX _mux1 (Q, J, K, _mux1);
endmodule
`endcelldefine

`celldefine
module U_FJKB_N_R_NO (Q, J, K, CP, R, NOTIFIER_REG);
input J, K, CP, R, NOTIFIER_REG;
output Q;
wire _mux1;
   _DFF _dff0 (1'b0, R, !CP, _mux1, Q);
   _MUX _mux1 (Q, J, K, _mux1);
endmodule
`endcelldefine

`celldefine
module U_FJKB_N_SB_NO (Q, J, K, CP, SB, NOTIFIER_REG);
input J, K, CP, SB, NOTIFIER_REG;
output Q;
wire _mux1;
   _DFF _dff0 (!SB, 1'b0, !CP, _mux1, Q);
   _MUX _mux1 (Q, J, K, _mux1);
endmodule
`endcelldefine

`celldefine
module U_FJKB_N_S_NO (Q, J, K, CP, S, NOTIFIER_REG);
input J, K, CP, S, NOTIFIER_REG;
output Q;
wire _mux1;
   _DFF _dff0 (S, 1'b0, !CP, _mux1, Q);
   _MUX _mux1 (Q, J, K, _mux1);
endmodule
`endcelldefine

`celldefine
module U_FJKB_P_NO (Q, J, K, CP, NOTIFIER_REG);
input J, K, CP, NOTIFIER_REG;
output Q;
wire _mux1;
   _DFF _dff0 (1'b0, 1'b0, CP, _mux1, Q);
   _MUX _mux1 (Q, J, K, _mux1);
endmodule
`endcelldefine

`celldefine
module U_FJKB_P_RB_NO (Q, J, K, CP, RB, NOTIFIER_REG);
input J, K, CP, RB, NOTIFIER_REG;
output Q;
wire _mux1;
   _DFF _dff0 (1'b0, !RB, CP, _mux1, Q);
   _MUX _mux1 (Q, J, K, _mux1);
endmodule
`endcelldefine

`celldefine
module U_FJKB_P_R_NO (Q, J, K, CP, R, NOTIFIER_REG);
input J, K, CP, R, NOTIFIER_REG;
output Q;
wire _mux1;
   _DFF _dff0 (1'b0, R, CP, _mux1, Q);
   _MUX _mux1 (Q, J, K, _mux1);
endmodule
`endcelldefine

`celldefine
module U_FJKB_P_SB_NO (Q, J, K, CP, SB, NOTIFIER_REG);
input J, K, CP, SB, NOTIFIER_REG;
output Q;
wire _mux1;
   _DFF _dff0 (!SB, 1'b0, CP, _mux1, Q);
   _MUX _mux1 (Q, J, K, _mux1);
endmodule
`endcelldefine

`celldefine
module U_FJKB_P_S_NO (Q, J, K, CP, S, NOTIFIER_REG);
input J, K, CP, S, NOTIFIER_REG;
output Q;
wire _mux1;
   _DFF _dff0 (S, 1'b0, CP, _mux1, Q);
   _MUX _mux1 (Q, J, K, _mux1);
endmodule
`endcelldefine

`celldefine
module U_FJK_N (Q, J, K, CP);
input J, K, CP;
output Q;
wire _mux1;
   _DFF _dff0 (1'b0, 1'b0, !CP, _mux1, Q);
   _MUX _mux1 (Q, J, !K, _mux1);
endmodule
`endcelldefine

`celldefine
module U_FJK_N_NO (Q, J, K, CP, NOTIFIER_REG);
input J, K, CP, NOTIFIER_REG;
output Q;
wire _mux1;
   _DFF _dff0 (1'b0, 1'b0, !CP, _mux1, Q);
   _MUX _mux1 (Q, J, !K, _mux1);
endmodule
`endcelldefine

`celldefine
module U_FJK_N_RB_SB (Q, J, K, CP, RB, SB);
input J, K, CP, RB, SB;
output Q;
wire _mux1;
   _DFF _dff0 (!SB, !RB, !CP, _mux1, Q);
   _MUX _mux1 (Q, J, !K, _mux1);
endmodule
`endcelldefine

`celldefine
module U_FJK_N_RB_SB_NO (Q, J, K, CP, RB, SB, NOTIFIER_REG);
input J, K, CP, RB, SB, NOTIFIER_REG;
output Q;
wire _mux1;
   _DFF _dff0 (!SB, !RB, !CP, _mux1, Q);
   _MUX _mux1 (Q, J, !K, _mux1);
endmodule
`endcelldefine

`celldefine
module U_FJK_N_RB_SB_QN (QN, J, K, CP, RB, SB);
input J, K, CP, RB, SB;
output QN;
wire _mux1;
   _DFF _dff0 (!RB, !SB, !CP, _mux1, QN);
   _MUX _mux1 (QN, K, !J, _mux1);
endmodule
`endcelldefine

`celldefine
module U_FJK_N_RB_SB_X (Q, J, K, CP, RB, SB);
input J, K, CP, RB, SB;
output Q;
wire _mux1;
   _DFF _dff0 (!SB, !RB, !CP, _mux1, Q);
   _MUX _mux1 (Q, J, !K, _mux1);
endmodule
`endcelldefine

`celldefine
module U_FJK_N_SB_RB (Q, J, K, CP, RB, SB);
input J, K, CP, RB, SB;
output Q;
wire _mux1;
   _DFF _dff0 (!SB, !RB, !CP, _mux1, Q);
   _MUX _mux1 (Q, J, !K, _mux1);
endmodule
`endcelldefine

`celldefine
module U_FJK_N_SB_RB_NO (Q, J, K, CP, RB, SB, NOTIFIER_REG);
input J, K, CP, RB, SB, NOTIFIER_REG;
output Q;
wire _mux1;
   _DFF _dff0 (!SB, !RB, !CP, _mux1, Q);
   _MUX _mux1 (Q, J, !K, _mux1);
endmodule
`endcelldefine

`celldefine
module U_FJK_N_SB_RB_QN (QN, J, K, CP, RB, SB);
input J, K, CP, RB, SB;
output QN;
wire _mux1;
   _DFF _dff0 (!RB, !SB, !CP, _mux1, QN);
   _MUX _mux1 (QN, K, !J, _mux1);
endmodule
`endcelldefine

`celldefine
module U_FJK_N_S_R (Q, J, K, CP, R, S);
input J, K, CP, R, S;
output Q;
wire _mux1;
   _DFF _dff0 (S, R, !CP, _mux1, Q);
   _MUX _mux1 (Q, J, !K, _mux1);
endmodule
`endcelldefine

`celldefine
module U_FJK_N_S_R_NO (Q, J, K, CP, R, S, NOTIFIER_REG);
input J, K, CP, R, S, NOTIFIER_REG;
output Q;
wire _mux1;
   _DFF _dff0 (S, R, !CP, _mux1, Q);
   _MUX _mux1 (Q, J, !K, _mux1);
endmodule
`endcelldefine

`celldefine
module U_FJK_N_S_R_NO_QN (QN, J, K, CP, R, S, NOTIFIER_REG);
input J, K, CP, R, S, NOTIFIER_REG;
output QN;
wire _mux1;
   _DFF _dff0 (R, S, !CP, _mux1, QN);
   _MUX _mux1 (QN, K, !J, _mux1);
endmodule
`endcelldefine

`celldefine
module U_FJK_N_S_R_QN (QN, J, K, CP, R, S);
input J, K, CP, R, S;
output QN;
wire _mux1;
   _DFF _dff0 (R, S, !CP, _mux1, QN);
   _MUX _mux1 (QN, K, !J, _mux1);
endmodule
`endcelldefine

`celldefine
module U_FJK_P (Q, J, K, CP);
input J, K, CP;
output Q;
wire _mux1;
   _DFF _dff0 (1'b0, 1'b0, CP, _mux1, Q);
   _MUX _mux1 (Q, J, !K, _mux1);
endmodule
`endcelldefine

`celldefine
module U_FJK_P_NO (Q, J, K, CP, NOTIFIER_REG);
input J, K, CP, NOTIFIER_REG;
output Q;
wire _mux1;
   _DFF _dff0 (1'b0, 1'b0, CP, _mux1, Q);
   _MUX _mux1 (Q, J, !K, _mux1);
endmodule
`endcelldefine

`celldefine
module U_FJK_P_R (Q, J, K, CP, R);
input J, K, CP, R;
output Q;
wire _mux1;
   _DFF _dff0 (1'b0, R, CP, _mux1, Q);
   _MUX _mux1 (Q, J, !K, _mux1);
endmodule
`endcelldefine

`celldefine
module U_FJK_P_RB (Q, J, K, CP, RB);
input J, K, CP, RB;
output Q;
wire _mux1;
   _DFF _dff0 (1'b0, !RB, CP, _mux1, Q);
   _MUX _mux1 (Q, J, !K, _mux1);
endmodule
`endcelldefine

`celldefine
module U_FJK_P_RB_NO (Q, J, K, CP, RB, NOTIFIER_REG);
input J, K, CP, RB, NOTIFIER_REG;
output Q;
wire _mux1;
   _DFF _dff0 (1'b0, !RB, CP, _mux1, Q);
   _MUX _mux1 (Q, J, !K, _mux1);
endmodule
`endcelldefine

`celldefine
module U_FJK_P_RB_SB (Q, J, K, CP, RB, SB);
input J, K, CP, RB, SB;
output Q;
wire _mux1;
   _DFF _dff0 (!SB, !RB, CP, _mux1, Q);
   _MUX _mux1 (Q, J, !K, _mux1);
endmodule
`endcelldefine

`celldefine
module U_FJK_P_RB_SB_NO (Q, J, K, CP, RB, SB, NOTIFIER_REG);
input J, K, CP, RB, SB, NOTIFIER_REG;
output Q;
wire _mux1;
   _DFF _dff0 (!SB, !RB, CP, _mux1, Q);
   _MUX _mux1 (Q, J, !K, _mux1);
endmodule
`endcelldefine

`celldefine
module U_FJK_P_RB_SB_QN (QN, J, K, CP, RB, SB);
input J, K, CP, RB, SB;
output QN;
wire _mux1;
   _DFF _dff0 (!RB, !SB, CP, _mux1, QN);
   _MUX _mux1 (QN, K, !J, _mux1);
endmodule
`endcelldefine

`celldefine
module U_FJK_P_RB_SB_X (Q, J, K, CP, RB, SB);
input J, K, CP, RB, SB;
output Q;
wire _mux1;
   _DFF _dff0 (!SB, !RB, CP, _mux1, Q);
   _MUX _mux1 (Q, J, !K, _mux1);
endmodule
`endcelldefine

`celldefine
module U_FJK_P_R_NO (Q, J, K, CP, R, NOTIFIER_REG);
input J, K, CP, R, NOTIFIER_REG;
output Q;
wire _mux1;
   _DFF _dff0 (1'b0, R, CP, _mux1, Q);
   _MUX _mux1 (Q, J, !K, _mux1);
endmodule
`endcelldefine

`celldefine
module U_FJK_P_S (Q, J, K, CP, S);
input J, K, CP, S;
output Q;
wire _mux1;
   _DFF _dff0 (S, 1'b0, CP, _mux1, Q);
   _MUX _mux1 (Q, J, !K, _mux1);
endmodule
`endcelldefine

`celldefine
module U_FJK_P_SB (Q, J, K, CP, SB);
input J, K, CP, SB;
output Q;
wire _mux1;
   _DFF _dff0 (!SB, 1'b0, CP, _mux1, Q);
   _MUX _mux1 (Q, J, !K, _mux1);
endmodule
`endcelldefine

`celldefine
module U_FJK_P_SB_NO (Q, J, K, CP, SB, NOTIFIER_REG);
input J, K, CP, SB, NOTIFIER_REG;
output Q;
wire _mux1;
   _DFF _dff0 (!SB, 1'b0, CP, _mux1, Q);
   _MUX _mux1 (Q, J, !K, _mux1);
endmodule
`endcelldefine

`celldefine
module U_FJK_P_SB_RB (Q, J, K, CP, RB, SB);
input J, K, CP, RB, SB;
output Q;
wire _mux1;
   _DFF _dff0 (!SB, !RB, CP, _mux1, Q);
   _MUX _mux1 (Q, J, !K, _mux1);
endmodule
`endcelldefine

`celldefine
module U_FJK_P_SB_RB_NO (Q, J, K, CP, RB, SB, NOTIFIER_REG);
input J, K, CP, RB, SB, NOTIFIER_REG;
output Q;
wire _mux1;
   _DFF _dff0 (!SB, !RB, CP, _mux1, Q);
   _MUX _mux1 (Q, J, !K, _mux1);
endmodule
`endcelldefine

`celldefine
module U_FJK_P_SB_RB_QN (QN, J, K, CP, RB, SB);
input J, K, CP, RB, SB;
output QN;
wire _mux1;
   _DFF _dff0 (!RB, !SB, CP, _mux1, QN);
   _MUX _mux1 (QN, K, !J, _mux1);
endmodule
`endcelldefine

`celldefine
module U_FJK_P_S_NO (Q, J, K, CP, S, NOTIFIER_REG);
input J, K, CP, S, NOTIFIER_REG;
output Q;
wire _mux1;
   _DFF _dff0 (S, 1'b0, CP, _mux1, Q);
   _MUX _mux1 (Q, J, !K, _mux1);
endmodule
`endcelldefine

`celldefine
module U_FJK_P_S_R (Q, J, K, CP, R, S);
input J, K, CP, R, S;
output Q;
wire _mux1;
   _DFF _dff0 (S, R, CP, _mux1, Q);
   _MUX _mux1 (Q, J, !K, _mux1);
endmodule
`endcelldefine

`celldefine
module U_FJK_P_S_R_NO (Q, J, K, CP, R, S, NOTIFIER_REG);
input J, K, CP, R, S, NOTIFIER_REG;
output Q;
wire _mux1;
   _DFF _dff0 (S, R, CP, _mux1, Q);
   _MUX _mux1 (Q, J, !K, _mux1);
endmodule
`endcelldefine

`celldefine
module U_FJK_P_S_R_NO_QN (QN, J, K, CP, R, S, NOTIFIER_REG);
input J, K, CP, R, S, NOTIFIER_REG;
output QN;
wire _mux1;
   _DFF _dff0 (R, S, CP, _mux1, QN);
   _MUX _mux1 (QN, K, !J, _mux1);
endmodule
`endcelldefine

`celldefine
module U_FJK_P_S_R_QN (QN, J, K, CP, R, S);
input J, K, CP, R, S;
output QN;
wire _mux1;
   _DFF _dff0 (R, S, CP, _mux1, QN);
   _MUX _mux1 (QN, K, !J, _mux1);
endmodule
`endcelldefine

`celldefine
module U_FRS_N (Q, S, R, CP);
input S, R, CP;
output Q;
wire _nor1, _or2;
   _DFF _dff0 (1'b0, 1'b0, !CP, _or2, Q);
   _NOR _nor1 (S, Q, _nor1);
   _NOR _or2 (_nor1, R, _or2);
endmodule
`endcelldefine

`celldefine
module U_FRS_N_NO (Q, S, R, CP, NOTIFIER_REG);
input S, R, CP, NOTIFIER_REG;
output Q;
wire _nor1, _or2;
   _DFF _dff0 (1'b0, 1'b0, !CP, _or2, Q);
   _NOR _nor1 (S, Q, _nor1);
   _NOR _or2 (_nor1, R, _or2);
endmodule
`endcelldefine

`celldefine
module U_FRS_N_NO_QN (QN, S, R, CP, NOTIFIER_REG);
input S, R, CP, NOTIFIER_REG;
output QN;
wire _nor1, _or2;
   _DFF _dff0 (1'b0, 1'b0, !CP, _or2, QN);
   _NOR _nor1 (R, QN, _nor1);
   _NOR _or2 (_nor1, S, _or2);
endmodule
`endcelldefine

`celldefine
module U_FRS_N_QN (QN, S, R, CP);
input S, R, CP;
output QN;
wire _nor1, _or2;
   _DFF _dff0 (1'b0, 1'b0, !CP, _or2, QN);
   _NOR _nor1 (R, QN, _nor1);
   _NOR _or2 (_nor1, S, _or2);
endmodule
`endcelldefine

`celldefine
module U_FRS_N_RB_SB (Q, S, R, CP, RB, SB);
input S, R, CP, RB, SB;
output Q;
wire _nor1, _or2;
   _DFF _dff0 (!SB, !RB, !CP, _or2, Q);
   _NOR _nor1 (S, Q, _nor1);
   _NOR _or2 (_nor1, R, _or2);
endmodule
`endcelldefine

`celldefine
module U_FRS_N_RB_SB_NO (Q, S, R, CP, RB, SB, NOTIFIER_REG);
input S, R, CP, RB, SB, NOTIFIER_REG;
output Q;
wire _nor1, _or2;
   _DFF _dff0 (!SB, !RB, !CP, _or2, Q);
   _NOR _nor1 (S, Q, _nor1);
   _NOR _or2 (_nor1, R, _or2);
endmodule
`endcelldefine

`celldefine
module U_FRS_N_RB_SB_QN (QN, S, R, CP, RB, SB);
input S, R, CP, RB, SB;
output QN;
wire _nor1, _or2;
   _DFF _dff0 (!RB, !SB, !CP, _or2, QN);
   _NOR _nor1 (R, QN, _nor1);
   _NOR _or2 (_nor1, S, _or2);
endmodule
`endcelldefine

`celldefine
module U_FRS_N_SB_RB_X (Q, S, R, CP, RB, SB);
input S, R, CP, RB, SB;
output Q;
wire _nor1, _or2;
   _DFF _dff0 (!SB, !RB, !CP, _or2, Q);
   _NOR _nor1 (S, Q, _nor1);
   _NOR _or2 (_nor1, R, _or2);
endmodule
`endcelldefine

`celldefine
module U_FRS_N_S_R_X (Q, S, R, CP, RST, SET);
input S, R, CP, RST, SET;
output Q;
wire _nor1, _or2;
   _DFF _dff0 (SET, RST, !CP, _or2, Q);
   _NOR _nor1 (S, Q, _nor1);
   _NOR _or2 (_nor1, R, _or2);
endmodule
`endcelldefine

`celldefine
module U_FRS_N_S_R_X_NO (Q, S, R, CP, RST, SET, NOTIFIER_REG);
input S, R, CP, RST, SET, NOTIFIER_REG;
output Q;
wire _nor1, _or2;
   _DFF _dff0 (SET, RST, !CP, _or2, Q);
   _NOR _nor1 (S, Q, _nor1);
   _NOR _or2 (_nor1, R, _or2);
endmodule
`endcelldefine

`celldefine
module U_FRS_N_S_R_X_QN (QN, S, R, CP, RST, SET);
input S, R, CP, RST, SET;
output QN;
wire _nor1, _or2;
   _DFF _dff0 (RST, SET, !CP, _or2, QN);
   _NOR _nor1 (R, QN, _nor1);
   _NOR _or2 (_nor1, S, _or2);
endmodule
`endcelldefine

`celldefine
module U_FRS_P (Q, S, R, CP);
input S, R, CP;
output Q;
wire _nor1, _or2;
   _DFF _dff0 (1'b0, 1'b0, CP, _or2, Q);
   _NOR _nor1 (S, Q, _nor1);
   _NOR _or2 (_nor1, R, _or2);
endmodule
`endcelldefine

`celldefine
module U_FRS_P_NO (Q, S, R, CP, NOTIFIER_REG);
input S, R, CP, NOTIFIER_REG;
output Q;
wire _nor1, _or2;
   _DFF _dff0 (1'b0, 1'b0, CP, _or2, Q);
   _NOR _nor1 (S, Q, _nor1);
   _NOR _or2 (_nor1, R, _or2);
endmodule
`endcelldefine

`celldefine
module U_FRS_P_NO_QN (QN, S, R, CP, NOTIFIER_REG);
input S, R, CP, NOTIFIER_REG;
output QN;
wire _nor1, _or2;
   _DFF _dff0 (1'b0, 1'b0, CP, _or2, QN);
   _NOR _nor1 (R, QN, _nor1);
   _NOR _or2 (_nor1, S, _or2);
endmodule
`endcelldefine

`celldefine
module U_FRS_P_QN (QN, S, R, CP);
input S, R, CP;
output QN;
wire _nor1, _or2;
   _DFF _dff0 (1'b0, 1'b0, CP, _or2, QN);
   _NOR _nor1 (R, QN, _nor1);
   _NOR _or2 (_nor1, S, _or2);
endmodule
`endcelldefine

`celldefine
module U_FRS_P_RB_SB (Q, S, R, CP, RB, SB);
input S, R, CP, RB, SB;
output Q;
wire _nor1, _or2;
   _DFF _dff0 (!SB, !RB, CP, _or2, Q);
   _NOR _nor1 (S, Q, _nor1);
   _NOR _or2 (_nor1, R, _or2);
endmodule
`endcelldefine

`celldefine
module U_FRS_P_RB_SB_NO (Q, S, R, CP, RB, SB, NOTIFIER_REG);
input S, R, CP, RB, SB, NOTIFIER_REG;
output Q;
wire _nor1, _or2;
   _DFF _dff0 (!SB, !RB, CP, _or2, Q);
   _NOR _nor1 (S, Q, _nor1);
   _NOR _or2 (_nor1, R, _or2);
endmodule
`endcelldefine

`celldefine
module U_FRS_P_RB_SB_QN (QN, S, R, CP, RB, SB);
input S, R, CP, RB, SB;
output QN;
wire _nor1, _or2;
   _DFF _dff0 (!RB, !SB, CP, _or2, QN);
   _NOR _nor1 (R, QN, _nor1);
   _NOR _or2 (_nor1, S, _or2);
endmodule
`endcelldefine

`celldefine
module U_FRS_P_SB_RB_X (Q, S, R, CP, RB, SB);
input S, R, CP, RB, SB;
output Q;
wire _nor1, _or2;
   _DFF _dff0 (!SB, !RB, CP, _or2, Q);
   _NOR _nor1 (S, Q, _nor1);
   _NOR _or2 (_nor1, R, _or2);
endmodule
`endcelldefine

`celldefine
module U_FRS_P_S_R_X (Q, S, R, CP, RST, SET);
input S, R, CP, RST, SET;
output Q;
wire _nor1, _or2;
   _DFF _dff0 (SET, RST, CP, _or2, Q);
   _NOR _nor1 (S, Q, _nor1);
   _NOR _or2 (_nor1, R, _or2);
endmodule
`endcelldefine

`celldefine
module U_FRS_P_S_R_X_NO (Q, S, R, CP, RST, SET, NOTIFIER_REG);
input S, R, CP, RST, SET, NOTIFIER_REG;
output Q;
wire _nor1, _or2;
   _DFF _dff0 (SET, RST, CP, _or2, Q);
   _NOR _nor1 (S, Q, _nor1);
   _NOR _or2 (_nor1, R, _or2);
endmodule
`endcelldefine

`celldefine
module U_FRS_P_S_R_X_QN (QN, S, R, CP, RST, SET);
input S, R, CP, RST, SET;
output QN;
wire _nor1, _or2;
   _DFF _dff0 (RST, SET, CP, _or2, QN);
   _NOR _nor1 (R, QN, _nor1);
   _NOR _or2 (_nor1, S, _or2);
endmodule
`endcelldefine

`celldefine
module U_FSR_N (Q, S, R, CP);
input S, R, CP;
output Q;
wire _and1, _or2;
   _DFF _dff0 (1'b0, 1'b0, !CP, _or2, Q);
   _AND _and1 (Q, R, _and1);
   _OR _or2 (_and1, !S, _or2);
endmodule
`endcelldefine

`celldefine
module U_FSR_N_NO (Q, S, R, CP, NOTIFIER_REG);
input S, R, CP, NOTIFIER_REG;
output Q;
wire _and1, _or2;
   _DFF _dff0 (1'b0, 1'b0, !CP, _or2, Q);
   _AND _and1 (Q, R, _and1);
   _OR _or2 (_and1, !S, _or2);
endmodule
`endcelldefine

`celldefine
module U_FSR_N_NO_QN (QN, S, R, CP, NOTIFIER_REG);
input S, R, CP, NOTIFIER_REG;
output QN;
wire _and1, _and2, _or3;
   _DFF _dff0 (1'b0, 1'b0, !CP, _or3, QN);
   _AND _and1 (R, !QN, _and1);
   _AND _and2 (R, !S, _and2);
   _NOR _or3 (_and1, _and2, _or3);
endmodule
`endcelldefine

`celldefine
module U_FSR_N_QN (QN, S, R, CP);
input S, R, CP;
output QN;
wire _and1, _and2, _or3;
   _DFF _dff0 (1'b0, 1'b0, !CP, _or3, QN);
   _AND _and1 (R, !QN, _and1);
   _AND _and2 (R, !S, _and2);
   _NOR _or3 (_and1, _and2, _or3);
endmodule
`endcelldefine

`celldefine
module U_FSR_P (Q, S, R, CP);
input S, R, CP;
output Q;
wire _and1, _or2;
   _DFF _dff0 (1'b0, 1'b0, CP, _or2, Q);
   _AND _and1 (Q, R, _and1);
   _OR _or2 (_and1, !S, _or2);
endmodule
`endcelldefine

`celldefine
module U_FSR_P_NO (Q, S, R, CP, NOTIFIER_REG);
input S, R, CP, NOTIFIER_REG;
output Q;
wire _and1, _or2;
   _DFF _dff0 (1'b0, 1'b0, CP, _or2, Q);
   _AND _and1 (Q, R, _and1);
   _OR _or2 (_and1, !S, _or2);
endmodule
`endcelldefine

`celldefine
module U_FSR_P_NO_QN (QN, S, R, CP, NOTIFIER_REG);
input S, R, CP, NOTIFIER_REG;
output QN;
wire _and1, _and2, _or3;
   _DFF _dff0 (1'b0, 1'b0, CP, _or3, QN);
   _AND _and1 (R, !QN, _and1);
   _AND _and2 (R, !S, _and2);
   _NOR _or3 (_and1, _and2, _or3);
endmodule
`endcelldefine

`celldefine
module U_FSR_P_QN (QN, S, R, CP);
input S, R, CP;
output QN;
wire _and1, _and2, _or3;
   _DFF _dff0 (1'b0, 1'b0, CP, _or3, QN);
   _AND _and1 (R, !QN, _and1);
   _AND _and2 (R, !S, _and2);
   _NOR _or3 (_and1, _and2, _or3);
endmodule
`endcelldefine

`celldefine
module U_FT_N_RB_SB (Q, CP, RB, SB);
input CP, RB, SB;
output Q;
   _DFF _dff0 (!SB, !RB, !CP, !Q, Q);
endmodule
`endcelldefine

`celldefine
module U_FT_N_RB_SB_NO (Q, CP, RB, SB, NOTIFIER_REG);
input CP, RB, SB, NOTIFIER_REG;
output Q;
   _DFF _dff0 (!SB, !RB, !CP, !Q, Q);
endmodule
`endcelldefine

`celldefine
module U_FT_N_RB_SB_QN (QN, CP, RB, SB);
input CP, RB, SB;
output QN;
   _DFF _dff0 (!RB, !SB, !CP, !QN, QN);
endmodule
`endcelldefine

`celldefine
module U_FT_N_RB_SB_X (Q, CP, RB, SB);
input CP, RB, SB;
output Q;
   _DFF _dff0 (!SB, !RB, !CP, !Q, Q);
endmodule
`endcelldefine

`celldefine
module U_FT_N_SB_RB (Q, CP, RB, SB);
input CP, RB, SB;
output Q;
   _DFF _dff0 (!SB, !RB, !CP, !Q, Q);
endmodule
`endcelldefine

`celldefine
module U_FT_N_SB_RB_NO (Q, CP, RB, SB, NOTIFIER_REG);
input CP, RB, SB, NOTIFIER_REG;
output Q;
   _DFF _dff0 (!SB, !RB, !CP, !Q, Q);
endmodule
`endcelldefine

`celldefine
module U_FT_N_SB_RB_QN (QN, CP, RB, SB);
input CP, RB, SB;
output QN;
   _DFF _dff0 (!RB, !SB, !CP, !QN, QN);
endmodule
`endcelldefine

`celldefine
module U_FT_N_TE_RB_SB (Q, TE, CP, RB, SB);
input TE, CP, RB, SB;
output Q;
wire _and2, _and1, _or3, _and4;
   _DFF _dff0 (!SB, !RB, !CP, _or3, Q);
   _AND _and1 (1'bX, _and2, _and1);
   _NAND _and2 (Q, TE, _and2);
   _OR _or3 (_and1, _and4, _or3);
   _AND _and4 (TE, !Q, _and4);
endmodule
`endcelldefine

`celldefine
module U_FT_P_PLD (Q, CP, PD, PLD);
input CP, PD, PLD;
output Q;
wire _dlat1;
   _DLAT _dff0 (1'b0, 1'b0, !PLD, PD, CP, _dlat1, Q);
   _DLAT _dlat1 (1'b0, 1'b0, !PLD, PD, !CP, !Q, _dlat1);
endmodule
`endcelldefine

`celldefine
module U_FT_P_PLD_NO (Q, CP, PD, PLD, NOTIFIER_REG);
input CP, PD, PLD, NOTIFIER_REG;
output Q;
wire _dlat1;
   _DLAT _dff0 (1'b0, 1'b0, !PLD, PD, CP, _dlat1, Q);
   _DLAT _dlat1 (1'b0, 1'b0, !PLD, PD, !CP, !Q, _dlat1);
endmodule
`endcelldefine

`celldefine
module U_FT_P_RB (Q, CP, RB);
input CP, RB;
output Q;
   _DFF _dff0 (1'b0, !RB, CP, !Q, Q);
endmodule
`endcelldefine

`celldefine
module U_FT_P_RB_NO (Q, CP, RB, NOTIFIER_REG);
input CP, RB, NOTIFIER_REG;
output Q;
   _DFF _dff0 (1'b0, !RB, CP, !Q, Q);
endmodule
`endcelldefine

`celldefine
module U_FT_P_RB_PLD (Q, CP, PD, PLD, RB);
input CP, PD, PLD, RB;
output Q;
wire _and1, _nand2, _dlat3;
   _DLAT _dff0 (1'b0, !RB, _and1, _nand2, CP, _dlat3, Q);
   _AND _and1 (RB, !PLD, _and1);
   _AND _nand2 (PD, Q, _nand2);
   _DLAT _dlat3 (1'b0, !RB, _and1, _nand2, !CP, !Q, _dlat3);
endmodule
`endcelldefine

`celldefine
module U_FT_P_RB_PLD_NO (Q, CP, PD, PLD, RB, NOTIFIER_REG);
input CP, PD, PLD, RB, NOTIFIER_REG;
output Q;
wire _dlat1;
   _DLAT _dff0 (1'b0, !RB, !PLD, PD, CP, _dlat1, Q);
   _DLAT _dlat1 (1'b0, !RB, !PLD, PD, !CP, !Q, _dlat1);
endmodule
`endcelldefine

`celldefine
module U_FT_P_RB_SB (Q, CP, RB, SB);
input CP, RB, SB;
output Q;
   _DFF _dff0 (!SB, !RB, CP, !Q, Q);
endmodule
`endcelldefine

`celldefine
module U_FT_P_RB_SB_NO (Q, CP, RB, SB, NOTIFIER_REG);
input CP, RB, SB, NOTIFIER_REG;
output Q;
   _DFF _dff0 (!SB, !RB, CP, !Q, Q);
endmodule
`endcelldefine

`celldefine
module U_FT_P_RB_SB_QN (QN, CP, RB, SB);
input CP, RB, SB;
output QN;
   _DFF _dff0 (!RB, !SB, CP, !QN, QN);
endmodule
`endcelldefine

`celldefine
module U_FT_P_RB_SB_X (Q, CP, RB, SB);
input CP, RB, SB;
output Q;
   _DFF _dff0 (!SB, !RB, CP, !Q, Q);
endmodule
`endcelldefine

`celldefine
module U_FT_P_SB (Q, CP, SB);
input CP, SB;
output Q;
   _DFF _dff0 (!SB, 1'b0, CP, !Q, Q);
endmodule
`endcelldefine

`celldefine
module U_FT_P_SB_NO (Q, CP, SB, NOTIFIER_REG);
input CP, SB, NOTIFIER_REG;
output Q;
   _DFF _dff0 (!SB, 1'b0, CP, !Q, Q);
endmodule
`endcelldefine

`celldefine
module U_FT_P_SB_RB (Q, CP, RB, SB);
input CP, RB, SB;
output Q;
   _DFF _dff0 (!SB, !RB, CP, !Q, Q);
endmodule
`endcelldefine

`celldefine
module U_FT_P_SB_RB_NO (Q, CP, RB, SB, NOTIFIER_REG);
input CP, RB, SB, NOTIFIER_REG;
output Q;
   _DFF _dff0 (!SB, !RB, CP, !Q, Q);
endmodule
`endcelldefine

`celldefine
module U_FT_P_SB_RB_QN (QN, CP, RB, SB);
input CP, RB, SB;
output QN;
   _DFF _dff0 (!RB, !SB, CP, !QN, QN);
endmodule
`endcelldefine

`celldefine
module U_FT_P_TE_PLD (Q, TE, CP, PD, PLD);
input TE, CP, PD, PLD;
output Q;
wire _nand1, _and4, _and3, _or5, _and6, _dlat2;
   _DLAT _dff0 (1'b0, 1'b0, PLD, _nand1, CP, _dlat2, Q);
   _AND _nand1 (PD, Q, _nand1);
   _DLAT _dlat2 (1'b0, 1'b0, PLD, _nand1, !CP, _or5, _dlat2);
   _AND _and3 (1'bX, _and4, _and3);
   _NAND _and4 (Q, TE, _and4);
   _OR _or5 (_and3, _and6, _or5);
   _AND _and6 (TE, !Q, _and6);
endmodule
`endcelldefine

`celldefine
module U_FT_P_TE_PLD_NO (Q, TE, CP, PD, PLD, NOTIFIER_REG);
input TE, CP, PD, PLD, NOTIFIER_REG;
output Q;
wire _and3, _and2, _or4, _and5, _dlat1;
   _DLAT _dff0 (1'b0, 1'b0, PLD, PD, CP, _dlat1, Q);
   _DLAT _dlat1 (1'b0, 1'b0, PLD, PD, !CP, _or4, _dlat1);
   _AND _and2 (1'bX, _and3, _and2);
   _NAND _and3 (Q, TE, _and3);
   _OR _or4 (_and2, _and5, _or4);
   _AND _and5 (TE, !Q, _and5);
endmodule
`endcelldefine

`celldefine
module U_FT_P_TE_RB (Q, TE, CP, RB);
input TE, CP, RB;
output Q;
wire _and2, _and1, _or3, _and4;
   _DFF _dff0 (1'b0, !RB, CP, _or3, Q);
   _AND _and1 (1'bX, _and2, _and1);
   _NAND _and2 (Q, TE, _and2);
   _OR _or3 (_and1, _and4, _or3);
   _AND _and4 (TE, !Q, _and4);
endmodule
`endcelldefine

`celldefine
module U_FT_P_TE_RB_NO (Q, TE, CP, RB, NOTIFIER_REG);
input TE, CP, RB, NOTIFIER_REG;
output Q;
wire _and2, _and1, _or3, _and4;
   _DFF _dff0 (1'b0, !RB, CP, _or3, Q);
   _AND _and1 (1'bX, _and2, _and1);
   _NAND _and2 (Q, TE, _and2);
   _OR _or3 (_and1, _and4, _or3);
   _AND _and4 (TE, !Q, _and4);
endmodule
`endcelldefine

`celldefine
module U_FT_P_TE_RB_SB (Q, TE, CP, RB, SB);
input TE, CP, RB, SB;
output Q;
wire _and2, _and1, _or3, _and4;
   _DFF _dff0 (!SB, !RB, CP, _or3, Q);
   _AND _and1 (1'bX, _and2, _and1);
   _NAND _and2 (Q, TE, _and2);
   _OR _or3 (_and1, _and4, _or3);
   _AND _and4 (TE, !Q, _and4);
endmodule
`endcelldefine

`celldefine
module U_IAI_2_3 (YN, A, B, C);
input A, B, C;
output YN;
   _NAND _and0 (C, !B, !A, YN);
endmodule
`endcelldefine

`celldefine
module U_IAOI_2_2 (Z, A1, B1, A2, B2);
input A1, B1, A2, B2;
output Z;
wire _and0, _and1;
   _AND _and0 (B2, A2, _and0);
   _AND _and1 (A1, !B1, _and1);
   _NOR _or2 (_and0, _and1, Z);
endmodule
`endcelldefine

`celldefine
module U_IAO_2_2 (Z, A1, B1, A2, B2);
input A1, B1, A2, B2;
output Z;
wire _and0, _and1;
   _AND _and0 (B2, A2, _and0);
   _AND _and1 (A1, !B1, _and1);
   _OR _or2 (_and0, _and1, Z);
endmodule
`endcelldefine

`celldefine
module U_IA_2_3 (Y, A, B, C);
input A, B, C;
output Y;
   _AND _and0 (C, !B, !A, Y);
endmodule
`endcelldefine

`celldefine
module U_LD_N (Q, D, GN);
input D, GN;
output Q;
   _DLAT _dlat0 (1'b0, 1'b0, !GN, D, Q);
endmodule
`endcelldefine

`celldefine
module U_LD_N_CEB_NO (Q, D, ACLK, BCLK, NOTIFIER_REG);
input D, ACLK, BCLK, NOTIFIER_REG;
output Q;
wire _nor1;
   _DLAT _dlat0 (1'b0, 1'b0, _nor1, D, Q);
   _NOR _nor1 (ACLK, BCLK, _nor1);
endmodule
`endcelldefine

`celldefine
module U_LD_N_CEB_RB_NO (Q, D, G, E, R, NOTIFIER_REG);
input D, G, E, R, NOTIFIER_REG;
output Q;
wire _nor1;
   _DLAT _dlat0 (1'b0, !R, _nor1, D, Q);
   _NOR _nor1 (G, E, _nor1);
endmodule
`endcelldefine

`celldefine
module U_LD_N_CEB_R_NO (Q, D, G, E, R, NOTIFIER_REG);
input D, G, E, R, NOTIFIER_REG;
output Q;
wire _nor1;
   _DLAT _dlat0 (1'b0, R, _nor1, D, Q);
   _NOR _nor1 (G, E, _nor1);
endmodule
`endcelldefine

`celldefine
module U_LD_N_CEB_SB_NO (Q, D, G, E, S, NOTIFIER_REG);
input D, G, E, S, NOTIFIER_REG;
output Q;
wire _nor1;
   _DLAT _dlat0 (!S, 1'b0, _nor1, D, Q);
   _NOR _nor1 (G, E, _nor1);
endmodule
`endcelldefine

`celldefine
module U_LD_N_CEB_S_NO (Q, D, G, E, S, NOTIFIER_REG);
input D, G, E, S, NOTIFIER_REG;
output Q;
wire _nor1;
   _DLAT _dlat0 (S, 1'b0, _nor1, D, Q);
   _NOR _nor1 (G, E, _nor1);
endmodule
`endcelldefine

`celldefine
module U_LD_N_CE_R_NO (Q, D, G, E, R, NOTIFIER_REG);
input D, G, E, R, NOTIFIER_REG;
output Q;
wire _and1;
   _DLAT _dlat0 (1'b0, R, _and1, D, Q);
   _AND _and1 (E, !G, _and1);
endmodule
`endcelldefine

`celldefine
module U_LD_N_CE_S_NO (Q, D, G, E, S, NOTIFIER_REG);
input D, G, E, S, NOTIFIER_REG;
output Q;
wire _and1;
   _DLAT _dlat0 (S, 1'b0, _and1, D, Q);
   _AND _and1 (E, !G, _and1);
endmodule
`endcelldefine

`celldefine
module U_LD_N_RB (Q, D, GN, RB);
input D, GN, RB;
output Q;
   _DLAT _dlat0 (1'b0, !RB, !GN, D, Q);
endmodule
`endcelldefine

`celldefine
module U_LD_N_RB_NO (Q, D, GN, RB, NOTI_REG);
input D, GN, RB, NOTI_REG;
output Q;
wire _and1;
   _DLAT _dlat0 (1'b0, !RB, _and1, D, Q);
   _AND _and1 (RB, !GN, _and1);
endmodule
`endcelldefine

`celldefine
module U_LD_N_RB_SB_X (Q, D, CK, RB, SB);
input D, CK, RB, SB;
output Q;
   _DLAT _dlat0 (!SB, !RB, !CK, D, Q);
endmodule
`endcelldefine

`celldefine
module U_LD_N_R_S_X (Q, D, CK, R, S);
input D, CK, R, S;
output Q;
   _DLAT _dlat0 (S, R, !CK, D, Q);
endmodule
`endcelldefine

`celldefine
module U_LD_N_R_S_X_NO (Q, D, GN, R, S, NOTI_REG);
input D, GN, R, S, NOTI_REG;
output Q;
wire _xor1, _nor2, _and3, _or4;
   _DLAT _dlat0 (S, R, _or4, D, Q);
   _XOR _xor1 (R, S, _xor1);
   _NOR _nor2 (GN, _xor1, _nor2);
   _AND _and3 (S, R, GN, _and3);
   _OR _or4 (_nor2, _and3, _or4);
endmodule
`endcelldefine

`celldefine
module U_LD_N_SB (Q, D, GN, SB);
input D, GN, SB;
output Q;
   _DLAT _dlat0 (!SB, 1'b0, !GN, D, Q);
endmodule
`endcelldefine

`celldefine
module U_LD_N_SB_NO (Q, D, GN, SB, NOTI_REG);
input D, GN, SB, NOTI_REG;
output Q;
wire _and1;
   _DLAT _dlat0 (!SB, 1'b0, _and1, D, Q);
   _AND _and1 (SB, !GN, _and1);
endmodule
`endcelldefine

`celldefine
module U_LD_N_SB_RB (Q, D, CK, RB, SB);
input D, CK, RB, SB;
output Q;
   _DLAT _dlat0 (!SB, !RB, !CK, D, Q);
endmodule
`endcelldefine

`celldefine
module U_LD_N_SB_RB_NO (Q, D, GN, RB, SB, NOTI_REG);
input D, GN, RB, SB, NOTI_REG;
output Q;
   _DLAT _dlat0 (!SB, !RB, !GN, D, Q);
endmodule
`endcelldefine

`celldefine
module U_LD_N_SB_RB_QN (QN, D, CK, RB, SB);
input D, CK, RB, SB;
output QN;
   _DLAT _dlat0 (!RB, !SB, !CK, !D, QN);
endmodule
`endcelldefine

`celldefine
module U_LD_N_S_R (Q, D, CK, R, S);
input D, CK, R, S;
output Q;
   _DLAT _dlat0 (S, R, !CK, D, Q);
endmodule
`endcelldefine

`celldefine
module U_LD_N_S_R_NO (Q, D, GN, R, S, NOTI_REG);
input D, GN, R, S, NOTI_REG;
output Q;
   _DLAT _dlat0 (S, R, !GN, D, Q);
endmodule
`endcelldefine

`celldefine
module U_LD_N_S_R_NO_QN (QN, D, GN, R, S, NOTI_REG);
input D, GN, R, S, NOTI_REG;
output QN;
   _DLAT _dlat0 (R, S, !GN, !D, QN);
endmodule
`endcelldefine

`celldefine
module U_LD_N_S_R_QN (QN, D, CK, R, S);
input D, CK, R, S;
output QN;
wire _or1;
   _DLAT _dlat0 (_or1, 1'b0, !CK, !D, QN);
   _OR _or1 (R, S, _or1);
endmodule
`endcelldefine

`celldefine
module U_LD_P (Q, D, G);
input D, G;
output Q;
   _DLAT _dlat0 (1'b0, 1'b0, G, D, Q);
endmodule
`endcelldefine

`celldefine
module U_LD_P_CEB_NO (Q, D, ACLK, BCLK, NOTIFIER_REG);
input D, ACLK, BCLK, NOTIFIER_REG;
output Q;
wire _and1;
   _DLAT _dlat0 (1'b0, 1'b0, _and1, D, Q);
   _AND _and1 (ACLK, !BCLK, _and1);
endmodule
`endcelldefine

`celldefine
module U_LD_P_CE_NO (Q, D, G, E, NOTIFIER_REG);
input D, G, E, NOTIFIER_REG;
output Q;
wire _and1;
   _DLAT _dlat0 (1'b0, 1'b0, _and1, D, Q);
   _AND _and1 (E, G, _and1);
endmodule
`endcelldefine

`celldefine
module U_LD_P_RB (Q, D, G, RB);
input D, G, RB;
output Q;
   _DLAT _dlat0 (1'b0, !RB, G, D, Q);
endmodule
`endcelldefine

`celldefine
module U_LD_P_RB_SB_X (Q, D, CK, RB, SB);
input D, CK, RB, SB;
output Q;
   _DLAT _dlat0 (!SB, !RB, CK, D, Q);
endmodule
`endcelldefine

`celldefine
module U_LD_P_R_S_X (Q, D, CK, R, S);
input D, CK, R, S;
output Q;
   _DLAT _dlat0 (S, R, CK, D, Q);
endmodule
`endcelldefine

`celldefine
module U_LD_P_R_S_X_NO (Q, D, G, R, S, NOTI_REG);
input D, G, R, S, NOTI_REG;
output Q;
wire _nor2, _and3, _or4, _and1, _and5, _or6;
   _DLAT _dlat0 (S, R, _or6, D, Q);
   _AND _and1 (S, R, !G, _and1);
   _NOR _nor2 (R, S, _nor2);
   _AND _and3 (S, R, _and3);
   _OR _or4 (_nor2, _and3, _or4);
   _AND _and5 (_or4, G, _and5);
   _OR _or6 (_and1, _and5, _or6);
endmodule
`endcelldefine

`celldefine
module U_LD_P_SB (Q, D, G, SB);
input D, G, SB;
output Q;
   _DLAT _dlat0 (!SB, 1'b0, G, D, Q);
endmodule
`endcelldefine

`celldefine
module U_LD_P_SB_NO (Q, D, G, SB, NOTI_REG);
input D, G, SB, NOTI_REG;
output Q;
wire _and1;
   _DLAT _dlat0 (!SB, 1'b0, _and1, D, Q);
   _AND _and1 (SB, G, _and1);
endmodule
`endcelldefine

`celldefine
module U_LD_P_SB_RB (Q, D, CK, RB, SB);
input D, CK, RB, SB;
output Q;
   _DLAT _dlat0 (!SB, !RB, CK, D, Q);
endmodule
`endcelldefine

`celldefine
module U_LD_P_SB_RB_QN (QN, D, CK, RB, SB);
input D, CK, RB, SB;
output QN;
   _DLAT _dlat0 (!RB, !SB, CK, !D, QN);
endmodule
`endcelldefine

`celldefine
module U_LD_P_S_R (Q, D, CK, R, S);
input D, CK, R, S;
output Q;
   _DLAT _dlat0 (S, R, CK, D, Q);
endmodule
`endcelldefine

`celldefine
module U_LD_P_S_R_NO (Q, D, G, R, S, NOTI_REG);
input D, G, R, S, NOTI_REG;
output Q;
   _DLAT _dlat0 (S, R, G, D, Q);
endmodule
`endcelldefine

`celldefine
module U_LD_P_S_R_NO_QN (QN, D, G, R, S, NOTI_REG);
input D, G, R, S, NOTI_REG;
output QN;
   _DLAT _dlat0 (R, S, G, !D, QN);
endmodule
`endcelldefine

`celldefine
module U_LD_P_S_R_QN (QN, D, CK, R, S);
input D, CK, R, S;
output QN;
wire _or1;
   _DLAT _dlat0 (_or1, 1'b0, CK, !D, QN);
   _OR _or1 (R, S, _or1);
endmodule
`endcelldefine

`celldefine
module U_LD_SD (Q, D, SI, CLK, ACLK);
input D, SI, CLK, ACLK;
output Q;
   _DLAT _dlat0 (1'b0, 1'b0, CLK, D, ACLK, SI, Q);
endmodule
`endcelldefine

`celldefine
module U_LD_SDA (Q, D, SI, CLK, ACLK);
input D, SI, CLK, ACLK;
output Q;
   _DLAT _dlat0 (1'b0, 1'b0, CLK, D, ACLK, SI, Q);
endmodule
`endcelldefine

`celldefine
module U_LD_SDA_NO (Q, D, SI, CLK, ACLK, NOTIFIER_REG);
input D, SI, CLK, ACLK, NOTIFIER_REG;
output Q;
   _DLAT _dlat0 (1'b0, 1'b0, CLK, D, ACLK, SI, Q);
endmodule
`endcelldefine

`celldefine
module U_LD_SDO (Q, D, SI, CLK, ACLK);
input D, SI, CLK, ACLK;
output Q;
   _DLAT _dlat0 (1'b0, 1'b0, CLK, D, ACLK, SI, Q);
endmodule
`endcelldefine

`celldefine
module U_LD_SDO_NO (Q, D, SI, CLK, ACLK, NOTIFIER_REG);
input D, SI, CLK, ACLK, NOTIFIER_REG;
output Q;
   _DLAT _dlat0 (1'b0, 1'b0, CLK, D, ACLK, SI, Q);
endmodule
`endcelldefine

`celldefine
module U_LD_SD_NO (Q, D, SI, CLK, ACLK, NOTIFIER_REG);
input D, SI, CLK, ACLK, NOTIFIER_REG;
output Q;
   _DLAT _dlat0 (1'b0, 1'b0, CLK, D, ACLK, SI, Q);
endmodule
`endcelldefine

`celldefine
module U_LD_SD_O (Q, D, CLK, BCLK);
input D, CLK, BCLK;
output Q;
wire _and1;
   _DLAT _dlat0 (1'b0, 1'b0, _and1, D, Q);
   _AND _and1 (CLK, !BCLK, _and1);
endmodule
`endcelldefine

`celldefine
module U_LD_SD_O_NO (Q, D, CLK, BCLK, NOTIFIER_REG);
input D, CLK, BCLK, NOTIFIER_REG;
output Q;
wire _and1;
   _DLAT _dlat0 (1'b0, 1'b0, _and1, D, Q);
   _AND _and1 (CLK, !BCLK, _and1);
endmodule
`endcelldefine

`celldefine
module U_L_N_SR_SB_RB (Q, S, R, SB, RB, G);
input S, R, SB, RB, G;
output Q;
wire _nor1, _or2, _and3, _and4, _and6, _or5, _and7;
   _DLAT _dlat0 (_or2, _and7, 1'b0, 1'b0, Q);
   _NOR _nor1 (S, G, _nor1);
   _OR _or2 (_nor1, !SB, _or2);
   _AND _and3 (S, !RB, _and3);
   _AND _and4 (S, !R, !G, _and4);
   _OR _or5 (_and3, _and4, _and6, _or5);
   _AND _and6 (G, !RB, _and6);
   _AND _and7 (_or5, SB, _and7);
endmodule
`endcelldefine

`celldefine
module U_L_N_SR_SB_RB_QN (QN, S, R, SB, RB, G);
input S, R, SB, RB, G;
output QN;
wire _nor1, _or2, _and3, _and4, _and6, _or5, _and7;
   _DLAT _dlat0 (_or2, _and7, 1'b0, 1'b0, QN);
   _NOR _nor1 (R, G, _nor1);
   _OR _or2 (_nor1, !RB, _or2);
   _AND _and3 (R, !SB, _and3);
   _AND _and4 (R, !S, !G, _and4);
   _OR _or5 (_and3, _and4, _and6, _or5);
   _AND _and6 (G, !SB, _and6);
   _AND _and7 (_or5, RB, _and7);
endmodule
`endcelldefine

`celldefine
module U_L_P_S_R (Q, S, R, G);
input S, R, G;
output Q;
wire _and1, _and2;
   _DLAT _dlat0 (_and1, _and2, 1'b0, 1'b0, Q);
   _AND _and1 (G, S, _and1);
   _AND _and2 (G, R, !S, _and2);
endmodule
`endcelldefine

`celldefine
module U_L_P_S_R_QN (QN, S, R, G);
input S, R, G;
output QN;
wire _and1, _and2;
   _DLAT _dlat0 (_and1, _and2, 1'b0, 1'b0, QN);
   _AND _and1 (G, R, _and1);
   _AND _and2 (G, !R, S, _and2);
endmodule
`endcelldefine

`celldefine
module U_L_RB_SB (Q, S, R);
input S, R;
output Q;
   _DLAT _dlat0 (!S, !R, 1'b0, 1'b0, Q);
endmodule
`endcelldefine

`celldefine
module U_L_RB_SB_QN (QN, S, R);
input S, R;
output QN;
   _DLAT _dlat0 (!R, !S, 1'b0, 1'b0, QN);
endmodule
`endcelldefine

`celldefine
module U_L_R_S (Q, S, R);
input S, R;
output Q;
   _DLAT _dlat0 (S, R, 1'b0, 1'b0, Q);
endmodule
`endcelldefine

`celldefine
module U_L_R_S_QN (QN, S, R);
input S, R;
output QN;
   _DLAT _dlat0 (R, S, 1'b0, 1'b0, QN);
endmodule
`endcelldefine

`celldefine
module U_L_SB_RB (Q, SB, RB);
input SB, RB;
output Q;
   _DLAT _dlat0 (!SB, !RB, 1'b0, 1'b0, Q);
endmodule
`endcelldefine

`celldefine
module U_L_SB_RB_QN (QN, SB, RB);
input SB, RB;
output QN;
   _DLAT _dlat0 (!RB, !SB, 1'b0, 1'b0, QN);
endmodule
`endcelldefine

`celldefine
module U_L_SR_SB_RB (Q, S1, S2, R1, R2, SB, RB);
input S1, S2, R1, R2, SB, RB;
output Q;
wire _nor2, _or1, _nor4, _or3;
   _DLAT _dlat0 (_or1, _or3, 1'b0, 1'b0, Q);
   _OR _or1 (_nor2, !SB, _or1);
   _NOR _nor2 (S1, S2, _nor2);
   _OR _or3 (_nor4, !RB, _or3);
   _NOR _nor4 (R1, R2, _nor4);
endmodule
`endcelldefine

`celldefine
module U_L_SR_SB_RB_QN (QN, S1, S2, R1, R2, SB, RB);
input S1, S2, R1, R2, SB, RB;
output QN;
wire _nor2, _or1, _nor4, _or3;
   _DLAT _dlat0 (_or1, _or3, 1'b0, 1'b0, QN);
   _OR _or1 (_nor2, !RB, _or1);
   _NOR _nor2 (R1, R2, _nor2);
   _OR _or3 (_nor4, !SB, _or3);
   _NOR _nor4 (S1, S2, _nor4);
endmodule
`endcelldefine

`celldefine
module U_L_S_R (Q, S, R);
input S, R;
output Q;
   _DLAT _dlat0 (S, R, 1'b0, 1'b0, Q);
endmodule
`endcelldefine

`celldefine
module U_L_S_R_QN (QN, S, R);
input S, R;
output QN;
   _DLAT _dlat0 (R, S, 1'b0, 1'b0, QN);
endmodule
`endcelldefine

`celldefine
module U_MUX_1 (Q, A, SL);
input A, SL;
output Q;
   _DLAT _dlat0 (1'b0, 1'b0, !SL, A, Q);
endmodule
`endcelldefine

`celldefine
module U_MUX_1_INV (Q, A, SL);
input A, SL;
output Q;
   _DLAT _dlat0 (1'b0, 1'b0, !SL, !A, Q);
endmodule
`endcelldefine

`celldefine
module U_MUX_2_2 (Q, A, B, S1, S2);
input A, B, S1, S2;
output Q;
wire _and2, _or3, _and1, _and4, _or5, _and0, _and8, _or9, _and7, _and10,
       _or11;
   _AND _and0 (1'bX, _or5, _and0);
   _AND _and1 (S1, !S2, !B, _and1);
   _AND _and2 (S2, !S1, _and2);
   _OR _or3 (_and2, !B, _or3);
   _AND _and4 (_or3, !A, _and4);
   _NOR _or5 (_and1, _and4, _or5);
   _OR _or6 (_and0, _or11, Q);
   _AND _and7 (S1, !S2, B, _and7);
   _AND _and8 (S2, !S1, _and8);
   _OR _or9 (_and8, B, _or9);
   _AND _and10 (_or9, A, _and10);
   _OR _or11 (_and7, _and10, _or11);
endmodule
`endcelldefine

`celldefine
module U_MUX_2_2_INV (Q, A, B, S1, S2);
input A, B, S1, S2;
output Q;
wire _and2, _or3, _and1, _and4, _or5, _and0, _and8, _or9, _and7, _and10,
       _or11;
   _AND _and0 (1'bX, _or5, _and0);
   _AND _and1 (S1, !S2, B, _and1);
   _AND _and2 (S2, !S1, _and2);
   _OR _or3 (_and2, B, _or3);
   _AND _and4 (_or3, A, _and4);
   _NOR _or5 (_and1, _and4, _or5);
   _OR _or6 (_and0, _or11, Q);
   _AND _and7 (S1, !S2, !B, _and7);
   _AND _and8 (S2, !S1, _and8);
   _OR _or9 (_and8, !B, _or9);
   _AND _and10 (_or9, !A, _and10);
   _OR _or11 (_and7, _and10, _or11);
endmodule
`endcelldefine

`celldefine
module U_MUX_3_2 (Y, D0, D1, D2, S0, S1);
input D0, D1, D2, S0, S1;
output Y;
wire _mux0;
   _MUX _mux0 (S0, D0, D1, _mux0);
   _MUX _mux1 (S1, _mux0, D2, Y);
endmodule
`endcelldefine

`celldefine
module U_MUX_3_2_INV (Y, D0, D1, D2, S0, S1);
input D0, D1, D2, S0, S1;
output Y;
wire _mux0;
   _MUX _mux0 (S0, !D0, !D1, _mux0);
   _MUX _mux1 (S1, _mux0, !D2, Y);
endmodule
`endcelldefine

`celldefine
module U_MUX_4_2_INV (Y, D0, D1, D2, D3, S0, S1);
input D0, D1, D2, D3, S0, S1;
output Y;
wire _mux0, _mux1;
   _MUX _mux0 (S1, !D0, !D2, _mux0);
   _MUX _mux1 (S1, !D1, !D3, _mux1);
   _MUX _mux2 (S0, _mux0, _mux1, Y);
endmodule
`endcelldefine

`celldefine
module U_O2_AI2_AI (Z, A, B, C, D);
input A, B, C, D;
output Z;
wire _and0, _nor1;
   _AND _and0 (D, C, _and0);
   _NOR _nor1 (A, B, _nor1);
   _OR _or2 (_and0, _nor1, Z);
endmodule
`endcelldefine

`celldefine
module U_OAI_2_2 (Z, A, B, C, D);
input A, B, C, D;
output Z;
wire _nor0, _nor1;
   _NOR _nor0 (C, D, _nor0);
   _NOR _nor1 (A, B, _nor1);
   _OR _or2 (_nor0, _nor1, Z);
endmodule
`endcelldefine

`celldefine
module U_OAI_2_3 (Y, A, B, C, D, E);
input A, B, C, D, E;
output Y;
wire _nor0, _nor1;
   _NOR _nor0 (B, C, A, _nor0);
   _NOR _nor1 (D, E, _nor1);
   _OR _or2 (_nor0, _nor1, Y);
endmodule
`endcelldefine

`celldefine
module U_OAI_3_3 (Y, A, B, C, D, E, F);
input A, B, C, D, E, F;
output Y;
wire _nor0, _nor1;
   _NOR _nor0 (E, F, D, _nor0);
   _NOR _nor1 (B, C, A, _nor1);
   _OR _or2 (_nor0, _nor1, Y);
endmodule
`endcelldefine

`celldefine
module U_OA_2_2 (Z, A, B, C, D);
input A, B, C, D;
output Z;
wire _nor0, _nor1;
   _NOR _nor0 (C, D, _nor0);
   _NOR _nor1 (A, B, _nor1);
   _NOR _or2 (_nor0, _nor1, Z);
endmodule
`endcelldefine

`celldefine
module U_OA_2_3 (Q1, D0, D1, D2, D3, D4);
input D0, D1, D2, D3, D4;
output Q1;
wire _nor0, _nor1;
   _NOR _nor0 (D3, D4, D2, _nor0);
   _NOR _nor1 (D0, D1, _nor1);
   _NOR _or2 (_nor0, _nor1, Q1);
endmodule
`endcelldefine

`celldefine
module U_OA_3_3 (Q0, D0, D1, D2, D3, D4, D5);
input D0, D1, D2, D3, D4, D5;
output Q0;
wire _nor0, _nor1;
   _NOR _nor0 (D4, D5, D3, _nor0);
   _NOR _nor1 (D1, D2, D0, _nor1);
   _NOR _or2 (_nor0, _nor1, Q0);
endmodule
`endcelldefine

`celldefine
module U_RAM1 (Q, D, WR, WRN);
input D, WR, WRN;
output Q;
wire _and2, _and1, _or3, _and4;
   _DLAT _dlat0 (1'b0, 1'b0, _or3, D, Q);
   _AND _and1 (1'bX, _and2, _and1);
   _NAND _and2 (WRN, !WR, _and2);
   _OR _or3 (_and1, _and4, _or3);
   _AND _and4 (WR, !WRN, _and4);
endmodule
`endcelldefine

`celldefine
module U_RAM1_QN (QN, D, WR, WRN);
input D, WR, WRN;
output QN;
wire _and2, _and1, _or3, _and4;
   _DLAT _dlat0 (1'b0, 1'b0, _or3, !D, QN);
   _AND _and1 (1'bX, _and2, _and1);
   _NAND _and2 (WRN, !WR, _and2);
   _OR _or3 (_and1, _and4, _or3);
   _AND _and4 (WR, !WRN, _and4);
endmodule
`endcelldefine

`celldefine
module s_senrq2 (Q, CP, ENN, SC, D, SD, notifier);
input CP, ENN, SC, D, SD, notifier;
output Q;
wire _mux1, _mux2;
   _DFF _dff0 (1'b0, 1'b0, CP, _mux2, Q);
   _MUX _mux1 (ENN, !D, !Q, _mux1);
   _MUX _mux2 (SC, !_mux1, SD, _mux2);
endmodule
`endcelldefine

`celldefine
module senrq2 (CP, ENN, D, SC, SD, Q);
input CP, ENN, D, SC, SD;
output Q;
wire notifier, SC_buf, ENN_buf, vcond1;
reg notifier;
   s_senrq2 s_senrq20 (Q, CP, ENN, SC, D, SD, notifier);
   buf buf1 (SC_buf, SC);
   buf buf2 (ENN_buf, ENN);
   and _and3 (vcond1, SC_buf, ENN_buf);
endmodule
`endcelldefine

`celldefine
module s_senrq1 (Q, CP, ENN, SC, D, SD, notifier);
input CP, ENN, SC, D, SD, notifier;
output Q;
wire _mux1, _mux2;
   _DFF _dff0 (1'b0, 1'b0, CP, _mux2, Q);
   _MUX _mux1 (ENN, !D, !Q, _mux1);
   _MUX _mux2 (SC, !_mux1, SD, _mux2);
endmodule
`endcelldefine

`celldefine
module senrq1 (CP, ENN, D, SC, SD, Q);
input CP, ENN, D, SC, SD;
output Q;
wire notifier, SC_buf, ENN_buf, vcond1;
reg notifier;
   s_senrq1 s_senrq10 (Q, CP, ENN, SC, D, SD, notifier);
   buf buf1 (SC_buf, SC);
   buf buf2 (ENN_buf, ENN);
   and _and3 (vcond1, SC_buf, ENN_buf);
endmodule
`endcelldefine

`celldefine
module U_FD_P_NO (Q, D, CP, NOTIFIER_REG);
input D, CP, NOTIFIER_REG;
output Q;
   _DFF _dff0 (1'b0, 1'b0, CP, D, Q);
endmodule
`endcelldefine

`celldefine
module sdnrq2 (CP, D, SC, SD, Q);
input CP, D, SC, SD;
output Q;
wire notifier, mux_out;
reg notifier;
   U_FD_P_NO U_FD_P_NO0 (Q, mux_out, CP, notifier);
   U_MUX_2_1 U_MUX_2_11 (mux_out, D, SD, SC);
endmodule
`endcelldefine

`celldefine
module sdnrq1 (CP, D, SC, SD, Q);
input CP, D, SC, SD;
output Q;
wire notifier, mux_out;
reg notifier;
   U_FD_P_NO U_FD_P_NO0 (Q, mux_out, CP, notifier);
   U_MUX_2_1 U_MUX_2_11 (mux_out, D, SD, SC);
endmodule
`endcelldefine

`celldefine
module s_sdnrn2 (QN, CP, SC, D, SD, notifier);
input CP, SC, D, SD, notifier;
output QN;
wire _mux1;
   _DFF _dff0 (1'b0, 1'b0, CP, _mux1, QN);
   _MUX _mux1 (SC, !D, !SD, _mux1);
endmodule
`endcelldefine

`celldefine
module sdnrn2 (CP, D, SC, SD, QN);
input CP, D, SC, SD;
output QN;
wire notifier;
reg notifier;
   s_sdnrn2 s_sdnrn20 (QN, CP, SC, D, SD, notifier);
endmodule
`endcelldefine

`celldefine
module s_sdnrn1 (QN, CP, SC, D, SD, notifier);
input CP, SC, D, SD, notifier;
output QN;
wire _mux1;
   _DFF _dff0 (1'b0, 1'b0, CP, _mux1, QN);
   _MUX _mux1 (SC, !D, !SD, _mux1);
endmodule
`endcelldefine

`celldefine
module sdnrn1 (CP, D, SC, SD, QN);
input CP, D, SC, SD;
output QN;
wire notifier;
reg notifier;
   s_sdnrn1 s_sdnrn10 (QN, CP, SC, D, SD, notifier);
endmodule
`endcelldefine

`celldefine
module sdnrb2 (D, SD, SC, CP, Q, QN);
input D, SD, SC, CP;
output Q, QN;
wire notifier, buf_Q, mux_out;
reg notifier;
   U_FD_P_NO U_FD_P_NO0 (buf_Q, mux_out, CP, notifier);
   U_MUX_2_1 U_MUX_2_11 (mux_out, D, SD, SC);
   buf buf2 (Q, buf_Q);
   not not3 (QN, buf_Q);
endmodule
`endcelldefine

`celldefine
module sdnrb1 (D, SD, SC, CP, Q, QN);
input D, SD, SC, CP;
output Q, QN;
wire notifier, buf_Q, mux_out;
reg notifier;
   U_FD_P_NO U_FD_P_NO0 (buf_Q, mux_out, CP, notifier);
   U_MUX_2_1 U_MUX_2_11 (mux_out, D, SD, SC);
   buf buf2 (Q, buf_Q);
   not not3 (QN, buf_Q);
endmodule
`endcelldefine

`celldefine
module U_LD_N_NO (Q, D, GN, NOTI_REG);
input D, GN, NOTI_REG;
output Q;
   _DLAT _dlat0 (1'b0, 1'b0, !GN, D, Q);
endmodule
`endcelldefine

`celldefine
module lanlq2 (EN, D, Q);
input EN, D;
output Q;
wire notifier;
reg notifier;
   U_LD_N_NO U_LD_N_NO0 (Q, D, EN, notifier);
endmodule
`endcelldefine

`celldefine
module lanlq1 (EN, D, Q);
input EN, D;
output Q;
wire notifier;
reg notifier;
   U_LD_N_NO U_LD_N_NO0 (Q, D, EN, notifier);
endmodule
`endcelldefine

`celldefine
module s_lanln (QN, EN, D, notifier);
input EN, D, notifier;
output QN;
   _DLAT _dlat0 (1'b0, 1'b0, !EN, !D, QN);
endmodule
`endcelldefine

`celldefine
module lanln2 (EN, D, QN);
input EN, D;
output QN;
wire notifier, EN_buf, D_buf;
reg notifier;
   buf b_EN (EN_buf, EN);
   buf b_D (D_buf, D);
   s_lanln s_lanln2 (QN, EN_buf, D_buf, notifier);
endmodule
`endcelldefine

`celldefine
module lanln1 (EN, D, QN);
input EN, D;
output QN;
wire notifier, EN_buf, D_buf;
reg notifier;
   buf b_EN (EN_buf, EN);
   buf b_D (D_buf, D);
   s_lanln s_lanln2 (QN, EN_buf, D_buf, notifier);
endmodule
`endcelldefine

`celldefine
module lanlb2 (EN, D, Q, QN);
input EN, D;
output Q, QN;
wire notifier, buf_Q;
reg notifier;
   U_LD_N_NO U_LD_N_NO0 (buf_Q, D, EN, notifier);
   buf buf1 (Q, buf_Q);
   not not2 (QN, buf_Q);
endmodule
`endcelldefine

`celldefine
module lanlb1 (EN, D, Q, QN);
input EN, D;
output Q, QN;
wire notifier, buf_Q;
reg notifier;
   U_LD_N_NO U_LD_N_NO0 (buf_Q, D, EN, notifier);
   buf buf1 (Q, buf_Q);
   not not2 (QN, buf_Q);
endmodule
`endcelldefine

`celldefine
module U_LD_P_NO (Q, D, G, NOTI_REG);
input D, G, NOTI_REG;
output Q;
   _DLAT _dlat0 (1'b0, 1'b0, G, D, Q);
endmodule
`endcelldefine

`celldefine
module lanht2 (D, E, OE, Z);
input D, E, OE;
output Z;
wire notifier, D_buf, E_buf, OE_buf, Q;
reg notifier;
   buf b_D (D_buf, D);
   buf b_E (E_buf, E);
   buf b_OE (OE_buf, OE);
   U_LD_P_NO U_LD_P_NO3 (Q, D_buf, E_buf, notifier);
   bufif1 b1 (Z, Q, OE_buf);
endmodule
`endcelldefine

`celldefine
module lanht1 (D, E, OE, Z);
input D, E, OE;
output Z;
wire notifier, D_buf, E_buf, OE_buf, Q;
reg notifier;
   buf b_D (D_buf, D);
   buf b_E (E_buf, E);
   buf b_OE (OE_buf, OE);
   U_LD_P_NO U_LD_P_NO3 (Q, D_buf, E_buf, notifier);
   bufif1 b1 (Z, Q, OE_buf);
endmodule
`endcelldefine

`celldefine
module lanhq2 (E, D, Q);
input E, D;
output Q;
wire notifier;
reg notifier;
   U_LD_P_NO U_LD_P_NO0 (Q, D, E, notifier);
endmodule
`endcelldefine

`celldefine
module lanhq1 (E, D, Q);
input E, D;
output Q;
wire notifier;
reg notifier;
   U_LD_P_NO U_LD_P_NO0 (Q, D, E, notifier);
endmodule
`endcelldefine

`celldefine
module s_lanhn (QN, E, D, notifier);
input E, D, notifier;
output QN;
   _DLAT _dlat0 (1'b0, 1'b0, E, !D, QN);
endmodule
`endcelldefine

`celldefine
module lanhn2 (E, D, QN);
input E, D;
output QN;
wire notifier, E_buf, D_buf;
reg notifier;
   buf b_E (E_buf, E);
   buf b_D (D_buf, D);
   s_lanhn s_lanhn2 (QN, E_buf, D_buf, notifier);
endmodule
`endcelldefine

`celldefine
module lanhn1 (E, D, QN);
input E, D;
output QN;
wire notifier, E_buf, D_buf;
reg notifier;
   buf b_E (E_buf, E);
   buf b_D (D_buf, D);
   s_lanhn s_lanhn2 (QN, E_buf, D_buf, notifier);
endmodule
`endcelldefine

`celldefine
module lanhb2 (D, E, Q, QN);
input D, E;
output Q, QN;
wire notifier, buf_Q;
reg notifier;
   U_LD_P_NO U_LD_P_NO0 (buf_Q, D, E, notifier);
   buf buf1 (Q, buf_Q);
   not not2 (QN, buf_Q);
endmodule
`endcelldefine

`celldefine
module lanhb1 (D, E, Q, QN);
input D, E;
output Q, QN;
wire notifier, buf_Q;
reg notifier;
   U_LD_P_NO U_LD_P_NO0 (buf_Q, D, E, notifier);
   buf buf1 (Q, buf_Q);
   not not2 (QN, buf_Q);
endmodule
`endcelldefine

`celldefine
module dfnrq2 (CP, D, Q);
input CP, D;
output Q;
wire notifier;
reg notifier;
   U_FD_P_NO U_FD_P_NO0 (Q, D, CP, notifier);
endmodule
`endcelldefine

`celldefine
module dfnrq1 (CP, D, Q);
input CP, D;
output Q;
wire notifier;
reg notifier;
   U_FD_P_NO U_FD_P_NO0 (Q, D, CP, notifier);
endmodule
`endcelldefine

`celldefine
module s_dfnrn2 (QN, CP, D, notifier);
input CP, D, notifier;
output QN;
   _DFF _dff0 (1'b0, 1'b0, CP, !D, QN);
endmodule
`endcelldefine

`celldefine
module dfnrn2 (CP, D, QN);
input CP, D;
output QN;
wire notifier;
reg notifier;
   s_dfnrn2 s_dfnrn20 (QN, CP, D, notifier);
endmodule
`endcelldefine

`celldefine
module s_dfnrn1 (QN, CP, D, notifier);
input CP, D, notifier;
output QN;
   _DFF _dff0 (1'b0, 1'b0, CP, !D, QN);
endmodule
`endcelldefine

`celldefine
module dfnrn1 (CP, D, QN);
input CP, D;
output QN;
wire notifier;
reg notifier;
   s_dfnrn1 s_dfnrn10 (QN, CP, D, notifier);
endmodule
`endcelldefine

`celldefine
module dfnrb2 (D, CP, Q, QN);
input D, CP;
output Q, QN;
wire notifier, buf_Q;
reg notifier;
   U_FD_P_NO U_FD_P_NO0 (buf_Q, D, CP, notifier);
   buf buf1 (Q, buf_Q);
   not not2 (QN, buf_Q);
endmodule
`endcelldefine

`celldefine
module dfnrb1 (D, CP, Q, QN);
input D, CP;
output Q, QN;
wire notifier, buf_Q;
reg notifier;
   U_FD_P_NO U_FD_P_NO0 (buf_Q, D, CP, notifier);
   buf buf1 (Q, buf_Q);
   not not2 (QN, buf_Q);
endmodule
`endcelldefine

`celldefine
module U_FD_N_NO (Q, D, CP, NOTIFIER_REG);
input D, CP, NOTIFIER_REG;
output Q;
   _DFF _dff0 (1'b0, 1'b0, !CP, D, Q);
endmodule
`endcelldefine

`celldefine
module dfnfb2 (D, CPN, Q, QN);
input D, CPN;
output Q, QN;
wire notifier, buf_Q;
reg notifier;
   U_FD_N_NO U_FD_N_NO0 (buf_Q, D, CPN, notifier);
   buf buf1 (Q, buf_Q);
   not not2 (QN, buf_Q);
endmodule
`endcelldefine

`celldefine
module dfnfb1 (D, CPN, Q, QN);
input D, CPN;
output Q, QN;
wire notifier, buf_Q;
reg notifier;
   U_FD_N_NO U_FD_N_NO0 (buf_Q, D, CPN, notifier);
   buf buf1 (Q, buf_Q);
   not not2 (QN, buf_Q);
endmodule
`endcelldefine

`celldefine
module s_denrq2 (Q, CP, ENN, D, notifier);
input CP, ENN, D, notifier;
output Q;
wire _mux1;
   _DFF _dff0 (1'b0, 1'b0, CP, _mux1, Q);
   _MUX _mux1 (ENN, D, Q, _mux1);
endmodule
`endcelldefine

`celldefine
module denrq2 (CP, D, ENN, Q);
input CP, D, ENN;
output Q;
wire CP_buf, D_buf, ENN_buf, BOOL_OUT, _or4, _and3, notifier;
reg notifier;
   buf buf0 (CP_buf, CP);
   buf buf1 (D_buf, D);
   buf buf2 (ENN_buf, ENN);
   and _and3 (_and3, !ENN_buf, D_buf, !ENN_buf);
   or _or4 (_or4, !Q, !ENN_buf);
   or _or5 (BOOL_OUT, _and3, !_or4);
   s_denrq2 s_denrq26 (Q, CP, ENN, D, notifier);
endmodule
`endcelldefine

`celldefine
module s_denrq1 (Q, CP, ENN, D, notifier);
input CP, ENN, D, notifier;
output Q;
wire _mux1;
   _DFF _dff0 (1'b0, 1'b0, CP, _mux1, Q);
   _MUX _mux1 (ENN, D, Q, _mux1);
endmodule
`endcelldefine

`celldefine
module denrq1 (CP, D, ENN, Q);
input CP, D, ENN;
output Q;
wire CP_buf, D_buf, ENN_buf, BOOL_OUT, _or4, _and3, notifier;
reg notifier;
   buf buf0 (CP_buf, CP);
   buf buf1 (D_buf, D);
   buf buf2 (ENN_buf, ENN);
   and _and3 (_and3, !ENN_buf, D_buf, !ENN_buf);
   or _or4 (_or4, !Q, !ENN_buf);
   or _or5 (BOOL_OUT, _and3, !_or4);
   s_denrq1 s_denrq16 (Q, CP, ENN, D, notifier);
endmodule
`endcelldefine

`celldefine
module s_senrq4 (Q, CP, ENN, SC, D, SD, notifier);
input CP, ENN, SC, D, SD, notifier;
output Q;
wire _mux1, _mux2;
   _DFF _dff0 (1'b0, 1'b0, CP, _mux2, Q);
   _MUX _mux1 (ENN, !D, !Q, _mux1);
   _MUX _mux2 (SC, !_mux1, SD, _mux2);
endmodule
`endcelldefine

`celldefine
module senrq4 (CP, ENN, D, SC, SD, Q);
input CP, ENN, D, SC, SD;
output Q;
wire notifier, SC_buf, ENN_buf, vcond1;
reg notifier;
   s_senrq4 s_senrq40 (Q, CP, ENN, SC, D, SD, notifier);
   buf buf1 (SC_buf, SC);
   buf buf2 (ENN_buf, ENN);
   and _and3 (vcond1, SC_buf, ENN_buf);
endmodule
`endcelldefine

`celldefine
module s_senrb4 (Q, CP, ENN, SC, D, SD, notifier);
input CP, ENN, SC, D, SD, notifier;
output Q;
wire _mux1, _mux2;
   _DFF _dff0 (1'b0, 1'b0, CP, _mux2, Q);
   _MUX _mux1 (ENN, !D, !Q, _mux1);
   _MUX _mux2 (SC, !_mux1, SD, _mux2);
endmodule
`endcelldefine

`celldefine
module senrb4 (CP, ENN, D, SC, SD, Q, QN);
input CP, ENN, D, SC, SD;
output Q, QN;
wire notifier, buf_Q, SC_buf, ENN_buf, vcond1;
reg notifier;
   s_senrb4 s_senrb40 (buf_Q, CP, ENN, SC, D, SD, notifier);
   buf buf1 (Q, buf_Q);
   not not2 (QN, buf_Q);
   buf buf3 (SC_buf, SC);
   buf buf4 (ENN_buf, ENN);
   and _and5 (vcond1, SC_buf, ENN_buf);
endmodule
`endcelldefine

`celldefine
module s_senrb2 (Q, CP, ENN, SC, D, SD, notifier);
input CP, ENN, SC, D, SD, notifier;
output Q;
wire _mux1, _mux2;
   _DFF _dff0 (1'b0, 1'b0, CP, _mux2, Q);
   _MUX _mux1 (ENN, !D, !Q, _mux1);
   _MUX _mux2 (SC, !_mux1, SD, _mux2);
endmodule
`endcelldefine

`celldefine
module senrb2 (CP, ENN, D, SC, SD, Q, QN);
input CP, ENN, D, SC, SD;
output Q, QN;
wire notifier, buf_Q, SC_buf, ENN_buf, vcond1;
reg notifier;
   s_senrb2 s_senrb20 (buf_Q, CP, ENN, SC, D, SD, notifier);
   buf buf1 (Q, buf_Q);
   not not2 (QN, buf_Q);
   buf buf3 (SC_buf, SC);
   buf buf4 (ENN_buf, ENN);
   and _and5 (vcond1, SC_buf, ENN_buf);
endmodule
`endcelldefine

`celldefine
module s_senrb1 (Q, CP, ENN, SC, D, SD, notifier);
input CP, ENN, SC, D, SD, notifier;
output Q;
wire _mux1, _mux2;
   _DFF _dff0 (1'b0, 1'b0, CP, _mux2, Q);
   _MUX _mux1 (ENN, !D, !Q, _mux1);
   _MUX _mux2 (SC, !_mux1, SD, _mux2);
endmodule
`endcelldefine

`celldefine
module senrb1 (CP, ENN, D, SC, SD, Q, QN);
input CP, ENN, D, SC, SD;
output Q, QN;
wire notifier, buf_Q, SC_buf, ENN_buf, vcond1;
reg notifier;
   s_senrb1 s_senrb10 (buf_Q, CP, ENN, SC, D, SD, notifier);
   buf buf1 (Q, buf_Q);
   not not2 (QN, buf_Q);
   buf buf3 (SC_buf, SC);
   buf buf4 (ENN_buf, ENN);
   and _and5 (vcond1, SC_buf, ENN_buf);
endmodule
`endcelldefine

`celldefine
module sdnrq4 (CP, D, SC, SD, Q);
input CP, D, SC, SD;
output Q;
wire notifier, mux_out;
reg notifier;
   U_FD_P_NO U_FD_P_NO0 (Q, mux_out, CP, notifier);
   U_MUX_2_1 U_MUX_2_11 (mux_out, D, SD, SC);
endmodule
`endcelldefine

`celldefine
module s_sdnrn4 (QN, CP, SC, D, SD, notifier);
input CP, SC, D, SD, notifier;
output QN;
wire _mux1;
   _DFF _dff0 (1'b0, 1'b0, CP, _mux1, QN);
   _MUX _mux1 (SC, !D, !SD, _mux1);
endmodule
`endcelldefine

`celldefine
module sdnrn4 (CP, D, SC, SD, QN);
input CP, D, SC, SD;
output QN;
wire notifier;
reg notifier;
   s_sdnrn4 s_sdnrn40 (QN, CP, SC, D, SD, notifier);
endmodule
`endcelldefine

`celldefine
module sdnrb4 (D, SD, SC, CP, Q, QN);
input D, SD, SC, CP;
output Q, QN;
wire notifier, buf_Q, mux_out;
reg notifier;
   U_FD_P_NO U_FD_P_NO0 (buf_Q, mux_out, CP, notifier);
   U_MUX_2_1 U_MUX_2_11 (mux_out, D, SD, SC);
   buf buf2 (Q, buf_Q);
   not not3 (QN, buf_Q);
endmodule
`endcelldefine

`celldefine
module sdnfb4 (D, SD, SC, CPN, Q, QN);
input D, SD, SC, CPN;
output Q, QN;
wire notifier, buf_Q, mux_out;
reg notifier;
   U_FD_N_NO U_FD_N_NO0 (buf_Q, mux_out, CPN, notifier);
   U_MUX_2_1 U_MUX_2_11 (mux_out, D, SD, SC);
   buf buf2 (Q, buf_Q);
   not not3 (QN, buf_Q);
endmodule
`endcelldefine

`celldefine
module sdnfb2 (D, SD, SC, CPN, Q, QN);
input D, SD, SC, CPN;
output Q, QN;
wire notifier, buf_Q, mux_out;
reg notifier;
   U_FD_N_NO U_FD_N_NO0 (buf_Q, mux_out, CPN, notifier);
   U_MUX_2_1 U_MUX_2_11 (mux_out, D, SD, SC);
   buf buf2 (Q, buf_Q);
   not not3 (QN, buf_Q);
endmodule
`endcelldefine

`celldefine
module sdnfb1 (D, SD, SC, CPN, Q, QN);
input D, SD, SC, CPN;
output Q, QN;
wire notifier, buf_Q, mux_out;
reg notifier;
   U_FD_N_NO U_FD_N_NO0 (buf_Q, mux_out, CPN, notifier);
   U_MUX_2_1 U_MUX_2_11 (mux_out, D, SD, SC);
   buf buf2 (Q, buf_Q);
   not not3 (QN, buf_Q);
endmodule
`endcelldefine

`celldefine
module lanlq4 (EN, D, Q);
input EN, D;
output Q;
wire notifier;
reg notifier;
   U_LD_N_NO U_LD_N_NO0 (Q, D, EN, notifier);
endmodule
`endcelldefine

`celldefine
module lanln4 (EN, D, QN);
input EN, D;
output QN;
wire notifier, EN_buf, D_buf;
reg notifier;
   buf b_EN (EN_buf, EN);
   buf b_D (D_buf, D);
   s_lanln s_lanln2 (QN, EN_buf, D_buf, notifier);
endmodule
`endcelldefine

`celldefine
module lanlb4 (EN, D, Q, QN);
input EN, D;
output Q, QN;
wire notifier, buf_Q;
reg notifier;
   U_LD_N_NO U_LD_N_NO0 (buf_Q, D, EN, notifier);
   buf buf1 (Q, buf_Q);
   not not2 (QN, buf_Q);
endmodule
`endcelldefine

`celldefine
module lanht4 (D, E, OE, Z);
input D, E, OE;
output Z;
wire notifier, D_buf, E_buf, OE_buf, Q;
reg notifier;
   buf b_D (D_buf, D);
   buf b_E (E_buf, E);
   buf b_OE (OE_buf, OE);
   U_LD_P_NO U_LD_P_NO3 (Q, D_buf, E_buf, notifier);
   bufif1 b1 (Z, Q, OE_buf);
endmodule
`endcelldefine

`celldefine
module lanhq4 (E, D, Q);
input E, D;
output Q;
wire notifier;
reg notifier;
   U_LD_P_NO U_LD_P_NO0 (Q, D, E, notifier);
endmodule
`endcelldefine

`celldefine
module lanhn4 (E, D, QN);
input E, D;
output QN;
wire notifier, E_buf, D_buf;
reg notifier;
   buf b_E (E_buf, E);
   buf b_D (D_buf, D);
   s_lanhn s_lanhn2 (QN, E_buf, D_buf, notifier);
endmodule
`endcelldefine

`celldefine
module lanhb4 (D, E, Q, QN);
input D, E;
output Q, QN;
wire notifier, buf_Q;
reg notifier;
   U_LD_P_NO U_LD_P_NO0 (buf_Q, D, E, notifier);
   buf buf1 (Q, buf_Q);
   not not2 (QN, buf_Q);
endmodule
`endcelldefine

`celldefine
module s_denrq4 (Q, CP, ENN, D, notifier);
input CP, ENN, D, notifier;
output Q;
wire _mux1;
   _DFF _dff0 (1'b0, 1'b0, CP, _mux1, Q);
   _MUX _mux1 (ENN, D, Q, _mux1);
endmodule
`endcelldefine

`celldefine
module denrq4 (CP, D, ENN, Q);
input CP, D, ENN;
output Q;
wire CP_buf, D_buf, ENN_buf, BOOL_OUT, _or4, _and3, notifier;
reg notifier;
   buf buf0 (CP_buf, CP);
   buf buf1 (D_buf, D);
   buf buf2 (ENN_buf, ENN);
   and _and3 (_and3, !ENN_buf, D_buf, !ENN_buf);
   or _or4 (_or4, !Q, !ENN_buf);
   or _or5 (BOOL_OUT, _and3, !_or4);
   s_denrq4 s_denrq46 (Q, CP, ENN, D, notifier);
endmodule
`endcelldefine

`celldefine
module dfnfb4 (D, CPN, Q, QN);
input D, CPN;
output Q, QN;
wire notifier, buf_Q;
reg notifier;
   U_FD_N_NO U_FD_N_NO0 (buf_Q, D, CPN, notifier);
   buf buf1 (Q, buf_Q);
   not not2 (QN, buf_Q);
endmodule
`endcelldefine

`celldefine
module dfnrb4 (D, CP, Q, QN);
input D, CP;
output Q, QN;
wire notifier, buf_Q;
reg notifier;
   U_FD_P_NO U_FD_P_NO0 (buf_Q, D, CP, notifier);
   buf buf1 (Q, buf_Q);
   not not2 (QN, buf_Q);
endmodule
`endcelldefine

`celldefine
module s_dfnrn4 (QN, CP, D, notifier);
input CP, D, notifier;
output QN;
   _DFF _dff0 (1'b0, 1'b0, CP, !D, QN);
endmodule
`endcelldefine

`celldefine
module dfnrn4 (CP, D, QN);
input CP, D;
output QN;
wire notifier;
reg notifier;
   s_dfnrn4 s_dfnrn40 (QN, CP, D, notifier);
endmodule
`endcelldefine

`celldefine
module dfnrq4 (CP, D, Q);
input CP, D;
output Q;
wire notifier;
reg notifier;
   U_FD_P_NO U_FD_P_NO0 (Q, D, CP, notifier);
endmodule
`endcelldefine

`celldefine
module slnhb1 (D, SD, SC, E, Q, QN, SO);
input D, SD, SC, E;
output Q, QN, SO;
wire notifier, mux_out, buf_Q;
reg notifier;
   U_MUX_2_1 U_MUX_2_10 (mux_out, D, SD, SC);
   U_LD_P_NO U_LD_P_NO1 (buf_Q, mux_out, E, notifier);
   U_FD_N_NO U_FD_N_NO2 (SO, mux_out, E, notifier);
   buf buf3 (Q, buf_Q);
   not not4 (QN, buf_Q);
endmodule
`endcelldefine

`celldefine
module slnhb2 (D, SD, SC, E, Q, QN, SO);
input D, SD, SC, E;
output Q, QN, SO;
wire notifier, mux_out, buf_Q;
reg notifier;
   U_MUX_2_1 U_MUX_2_10 (mux_out, D, SD, SC);
   U_LD_P_NO U_LD_P_NO1 (buf_Q, mux_out, E, notifier);
   U_FD_N_NO U_FD_N_NO2 (SO, mux_out, E, notifier);
   buf buf3 (Q, buf_Q);
   not not4 (QN, buf_Q);
endmodule
`endcelldefine

`celldefine
module slnhb4 (D, SD, SC, E, Q, QN, SO);
input D, SD, SC, E;
output Q, QN, SO;
wire notifier, mux_out, buf_Q;
reg notifier;
   U_MUX_2_1 U_MUX_2_10 (mux_out, D, SD, SC);
   U_LD_P_NO U_LD_P_NO1 (buf_Q, mux_out, E, notifier);
   U_FD_N_NO U_FD_N_NO2 (SO, mux_out, E, notifier);
   buf buf3 (Q, buf_Q);
   not not4 (QN, buf_Q);
endmodule
`endcelldefine

`celldefine
module slnhn1 (D, SD, SC, E, QN, SO);
input D, SD, SC, E;
output QN, SO;
wire notifier, mux_out, buf_Q;
reg notifier;
   U_MUX_2_1 U_MUX_2_10 (mux_out, D, SD, SC);
   U_LD_P_NO U_LD_P_NO1 (buf_Q, mux_out, E, notifier);
   U_FD_N_NO U_FD_N_NO2 (SO, mux_out, E, notifier);
   not not3 (QN, buf_Q);
endmodule
`endcelldefine

`celldefine
module slnhn2 (D, SD, SC, E, QN, SO);
input D, SD, SC, E;
output QN, SO;
wire notifier, mux_out, buf_Q;
reg notifier;
   U_MUX_2_1 U_MUX_2_10 (mux_out, D, SD, SC);
   U_LD_P_NO U_LD_P_NO1 (buf_Q, mux_out, E, notifier);
   U_FD_N_NO U_FD_N_NO2 (SO, mux_out, E, notifier);
   not not3 (QN, buf_Q);
endmodule
`endcelldefine

`celldefine
module slnhn4 (D, SD, SC, E, QN, SO);
input D, SD, SC, E;
output QN, SO;
wire notifier, mux_out, buf_Q;
reg notifier;
   U_MUX_2_1 U_MUX_2_10 (mux_out, D, SD, SC);
   U_LD_P_NO U_LD_P_NO1 (buf_Q, mux_out, E, notifier);
   U_FD_N_NO U_FD_N_NO2 (SO, mux_out, E, notifier);
   not not3 (QN, buf_Q);
endmodule
`endcelldefine

`celldefine
module slnhq1 (D, SD, SC, E, Q, SO);
input D, SD, SC, E;
output Q, SO;
wire notifier, mux_out;
reg notifier;
   U_MUX_2_1 U_MUX_2_10 (mux_out, D, SD, SC);
   U_LD_P_NO U_LD_P_NO1 (Q, mux_out, E, notifier);
   U_FD_N_NO U_FD_N_NO2 (SO, mux_out, E, notifier);
endmodule
`endcelldefine

`celldefine
module slnhq2 (D, SD, SC, E, Q, SO);
input D, SD, SC, E;
output Q, SO;
wire notifier, mux_out;
reg notifier;
   U_MUX_2_1 U_MUX_2_10 (mux_out, D, SD, SC);
   U_LD_P_NO U_LD_P_NO1 (Q, mux_out, E, notifier);
   U_FD_N_NO U_FD_N_NO2 (SO, mux_out, E, notifier);
endmodule
`endcelldefine

`celldefine
module slnhq4 (D, SD, SC, E, Q, SO);
input D, SD, SC, E;
output Q, SO;
wire notifier, mux_out;
reg notifier;
   U_MUX_2_1 U_MUX_2_10 (mux_out, D, SD, SC);
   U_LD_P_NO U_LD_P_NO1 (Q, mux_out, E, notifier);
   U_FD_N_NO U_FD_N_NO2 (SO, mux_out, E, notifier);
endmodule
`endcelldefine

`celldefine
module slnht1 (D, SD, SC, E, OE, Z, SO);
input D, SD, SC, E, OE;
output Z, SO;
wire notifier, OE_buf, mux_out, Q;
reg notifier;
   buf b_OE (OE_buf, OE);
   U_MUX_2_1 U_MUX_2_11 (mux_out, D, SD, SC);
   U_LD_P_NO U_LD_P_NO2 (Q, mux_out, E, notifier);
   U_FD_N_NO U_FD_N_NO3 (SO, mux_out, E, notifier);
   bufif1 b1 (Z, Q, OE_buf);
endmodule
`endcelldefine

`celldefine
module slnht2 (D, SD, SC, E, OE, Z, SO);
input D, SD, SC, E, OE;
output Z, SO;
wire notifier, OE_buf, mux_out, Q;
reg notifier;
   buf b_OE (OE_buf, OE);
   U_MUX_2_1 U_MUX_2_11 (mux_out, D, SD, SC);
   U_LD_P_NO U_LD_P_NO2 (Q, mux_out, E, notifier);
   U_FD_N_NO U_FD_N_NO3 (SO, mux_out, E, notifier);
   bufif1 b1 (Z, Q, OE_buf);
endmodule
`endcelldefine

`celldefine
module slnht4 (D, SD, SC, E, OE, Z, SO);
input D, SD, SC, E, OE;
output Z, SO;
wire notifier, OE_buf, mux_out, Q;
reg notifier;
   buf b_OE (OE_buf, OE);
   U_MUX_2_1 U_MUX_2_11 (mux_out, D, SD, SC);
   U_LD_P_NO U_LD_P_NO2 (Q, mux_out, E, notifier);
   U_FD_N_NO U_FD_N_NO3 (SO, mux_out, E, notifier);
   bufif1 b1 (Z, Q, OE_buf);
endmodule
`endcelldefine

`celldefine
module slnlb1 (D, SD, SC, EN, Q, QN, SO);
input D, SD, SC, EN;
output Q, QN, SO;
wire notifier, mux_out, buf_Q;
reg notifier;
   U_MUX_2_1 U_MUX_2_10 (mux_out, D, SD, SC);
   U_LD_N_NO U_LD_N_NO1 (buf_Q, mux_out, EN, notifier);
   U_FD_P_NO U_FD_P_NO2 (SO, mux_out, EN, notifier);
   buf buf3 (Q, buf_Q);
   not not4 (QN, buf_Q);
endmodule
`endcelldefine

`celldefine
module slnlb2 (D, SD, SC, EN, Q, QN, SO);
input D, SD, SC, EN;
output Q, QN, SO;
wire notifier, mux_out, buf_Q;
reg notifier;
   U_MUX_2_1 U_MUX_2_10 (mux_out, D, SD, SC);
   U_LD_N_NO U_LD_N_NO1 (buf_Q, mux_out, EN, notifier);
   U_FD_P_NO U_FD_P_NO2 (SO, mux_out, EN, notifier);
   buf buf3 (Q, buf_Q);
   not not4 (QN, buf_Q);
endmodule
`endcelldefine

`celldefine
module slnlb4 (D, SD, SC, EN, Q, QN, SO);
input D, SD, SC, EN;
output Q, QN, SO;
wire notifier, mux_out, buf_Q;
reg notifier;
   U_MUX_2_1 U_MUX_2_10 (mux_out, D, SD, SC);
   U_LD_N_NO U_LD_N_NO1 (buf_Q, mux_out, EN, notifier);
   U_FD_P_NO U_FD_P_NO2 (SO, mux_out, EN, notifier);
   buf buf3 (Q, buf_Q);
   not not4 (QN, buf_Q);
endmodule
`endcelldefine

`celldefine
module slnln1 (D, SD, SC, EN, QN, SO);
input D, SD, SC, EN;
output QN, SO;
wire notifier, mux_out, buf_Q;
reg notifier;
   U_MUX_2_1 U_MUX_2_10 (mux_out, D, SD, SC);
   U_LD_N_NO U_LD_N_NO1 (buf_Q, mux_out, EN, notifier);
   U_FD_P_NO U_FD_P_NO2 (SO, mux_out, EN, notifier);
   not not3 (QN, buf_Q);
endmodule
`endcelldefine

`celldefine
module slnln2 (D, SD, SC, EN, QN, SO);
input D, SD, SC, EN;
output QN, SO;
wire notifier, mux_out, buf_Q;
reg notifier;
   U_MUX_2_1 U_MUX_2_10 (mux_out, D, SD, SC);
   U_LD_N_NO U_LD_N_NO1 (buf_Q, mux_out, EN, notifier);
   U_FD_P_NO U_FD_P_NO2 (SO, mux_out, EN, notifier);
   not not3 (QN, buf_Q);
endmodule
`endcelldefine

`celldefine
module slnln4 (D, SD, SC, EN, QN, SO);
input D, SD, SC, EN;
output QN, SO;
wire notifier, mux_out, buf_Q;
reg notifier;
   U_MUX_2_1 U_MUX_2_10 (mux_out, D, SD, SC);
   U_LD_N_NO U_LD_N_NO1 (buf_Q, mux_out, EN, notifier);
   U_FD_P_NO U_FD_P_NO2 (SO, mux_out, EN, notifier);
   not not3 (QN, buf_Q);
endmodule
`endcelldefine

`celldefine
module slnlq1 (D, SD, SC, EN, Q, SO);
input D, SD, SC, EN;
output Q, SO;
wire notifier, mux_out;
reg notifier;
   U_MUX_2_1 U_MUX_2_10 (mux_out, D, SD, SC);
   U_LD_N_NO U_LD_N_NO1 (Q, mux_out, EN, notifier);
   U_FD_P_NO U_FD_P_NO2 (SO, mux_out, EN, notifier);
endmodule
`endcelldefine

`celldefine
module slnlq2 (D, SD, SC, EN, Q, SO);
input D, SD, SC, EN;
output Q, SO;
wire notifier, mux_out;
reg notifier;
   U_MUX_2_1 U_MUX_2_10 (mux_out, D, SD, SC);
   U_LD_N_NO U_LD_N_NO1 (Q, mux_out, EN, notifier);
   U_FD_P_NO U_FD_P_NO2 (SO, mux_out, EN, notifier);
endmodule
`endcelldefine

`celldefine
module slnlq4 (D, SD, SC, EN, Q, SO);
input D, SD, SC, EN;
output Q, SO;
wire notifier, mux_out;
reg notifier;
   U_MUX_2_1 U_MUX_2_10 (mux_out, D, SD, SC);
   U_LD_N_NO U_LD_N_NO1 (Q, mux_out, EN, notifier);
   U_FD_P_NO U_FD_P_NO2 (SO, mux_out, EN, notifier);
endmodule
`endcelldefine

`celldefine
module oan211d4 (C2, C1, B, A, ZN);
input C2, C1, B, A;
output ZN;
wire g_1_out, g_2_out;
   or or0 (g_1_out, B, A);
   or or1 (g_2_out, A, C2, C1);
   nand nand2 (ZN, g_1_out, g_2_out);
endmodule
`endcelldefine

`celldefine
module aon211d4 (C2, C1, B, A, ZN);
input C2, C1, B, A;
output ZN;
wire g_1_out, g_2_out;
   and and0 (g_1_out, B, A);
   and and1 (g_2_out, A, C2, C1);
   nor nor2 (ZN, g_1_out, g_2_out);
endmodule
`endcelldefine

`celldefine
module oan211d2 (C2, C1, B, A, ZN);
input C2, C1, B, A;
output ZN;
wire g_1_out, g_2_out;
   or or0 (g_1_out, B, A);
   or or1 (g_2_out, A, C2, C1);
   nand nand2 (ZN, g_1_out, g_2_out);
endmodule
`endcelldefine

`celldefine
module aon211d2 (C2, C1, B, A, ZN);
input C2, C1, B, A;
output ZN;
wire g_1_out, g_2_out;
   and and0 (g_1_out, B, A);
   and and1 (g_2_out, A, C2, C1);
   nor nor2 (ZN, g_1_out, g_2_out);
endmodule
`endcelldefine

`celldefine
module oan211d1 (C2, C1, B, A, ZN);
input C2, C1, B, A;
output ZN;
wire g_1_out, g_2_out;
   or or0 (g_1_out, B, A);
   or or1 (g_2_out, A, C2, C1);
   nand nand2 (ZN, g_1_out, g_2_out);
endmodule
`endcelldefine

`celldefine
module aon211d1 (C2, C1, B, A, ZN);
input C2, C1, B, A;
output ZN;
wire g_1_out, g_2_out;
   and and0 (g_1_out, B, A);
   and and1 (g_2_out, A, C2, C1);
   nor nor2 (ZN, g_1_out, g_2_out);
endmodule
`endcelldefine

`celldefine
module gcnfnn1 (CLK, EN, GCLK);
input CLK, EN;
output GCLK;
wire notifier, buf_gclk, mem_notifier;
reg notifier, buf_gclk, mem_notifier;
   buf buf0 (GCLK, buf_gclk);
endmodule
`endcelldefine

`celldefine
module gcnfnn2 (CLK, EN, GCLK);
input CLK, EN;
output GCLK;
wire notifier, buf_gclk, mem_notifier;
reg notifier, buf_gclk, mem_notifier;
   buf buf0 (GCLK, buf_gclk);
endmodule
`endcelldefine

`celldefine
module gcnfnn4 (CLK, EN, GCLK);
input CLK, EN;
output GCLK;
wire notifier, buf_gclk, mem_notifier;
reg notifier, buf_gclk, mem_notifier;
   buf buf0 (GCLK, buf_gclk);
endmodule
`endcelldefine

`celldefine
module gcnfnn7 (CLK, EN, GCLK);
input CLK, EN;
output GCLK;
wire notifier, buf_gclk, mem_notifier;
reg notifier, buf_gclk, mem_notifier;
   buf buf0 (GCLK, buf_gclk);
endmodule
`endcelldefine

`celldefine
module gcnfnna (CLK, EN, GCLK);
input CLK, EN;
output GCLK;
wire notifier, buf_gclk, mem_notifier;
reg notifier, buf_gclk, mem_notifier;
   buf buf0 (GCLK, buf_gclk);
endmodule
`endcelldefine

`celldefine
module gcnrnn1 (CLK, EN, GCLK);
input CLK, EN;
output GCLK;
wire notifier, buf_gclk, mem_notifier;
reg notifier, buf_gclk, mem_notifier;
   buf buf0 (GCLK, buf_gclk);
endmodule
`endcelldefine

`celldefine
module gcnrnn2 (CLK, EN, GCLK);
input CLK, EN;
output GCLK;
wire notifier, buf_gclk, mem_notifier;
reg notifier, buf_gclk, mem_notifier;
   buf buf0 (GCLK, buf_gclk);
endmodule
`endcelldefine

`celldefine
module gcnrnn4 (CLK, EN, GCLK);
input CLK, EN;
output GCLK;
wire notifier, buf_gclk, mem_notifier;
reg notifier, buf_gclk, mem_notifier;
   buf buf0 (GCLK, buf_gclk);
endmodule
`endcelldefine

`celldefine
module gcnrnn7 (CLK, EN, GCLK);
input CLK, EN;
output GCLK;
wire notifier, buf_gclk, mem_notifier;
reg notifier, buf_gclk, mem_notifier;
   buf buf0 (GCLK, buf_gclk);
endmodule
`endcelldefine

`celldefine
module gcnrnna (CLK, EN, GCLK);
input CLK, EN;
output GCLK;
wire notifier, buf_gclk, mem_notifier;
reg notifier, buf_gclk, mem_notifier;
   buf buf0 (GCLK, buf_gclk);
endmodule
`endcelldefine

module s_srlab2 (RN, SN, Q, QN, notifier);
input RN, SN, notifier;
output Q, QN;
wire mem_notifier, reg_Q, xreg_Q, reg_QN, xreg_QN;
reg mem_notifier, reg_Q, xreg_Q, reg_QN, xreg_QN;
   buf buf0 (Q, reg_Q);
   buf buf1 (QN, reg_QN);
endmodule

`celldefine
module srlab2 (RN, SN, Q, QN);
input RN, SN;
output Q, QN;
wire notifier, RN_buf, SN_buf;
reg notifier;
   buf b_RN (RN_buf, RN);
   buf b_SN (SN_buf, SN);
   s_srlab2 g1_s_srlab2_1 (RN_buf, SN_buf, Q, QN, notifier);
endmodule
`endcelldefine

module s_srlab1 (RN, SN, Q, QN, notifier);
input RN, SN, notifier;
output Q, QN;
wire reg_Q, xreg_Q, reg_QN, xreg_QN, mem_notifier;
reg reg_Q, xreg_Q, reg_QN, xreg_QN, mem_notifier;
   buf buf0 (Q, reg_Q);
   buf buf1 (QN, reg_QN);
endmodule

`celldefine
module srlab1 (RN, SN, Q, QN);
input RN, SN;
output Q, QN;
wire notifier, RN_buf, SN_buf;
reg notifier;
   buf b_RN (RN_buf, RN);
   buf b_SN (SN_buf, SN);
   s_srlab1 g1_s_srlab1_1 (RN_buf, SN_buf, Q, QN, notifier);
endmodule
`endcelldefine

module s_srlab4 (RN, SN, Q, QN, notifier);
input RN, SN, notifier;
output Q, QN;
wire reg_Q, xreg_Q, reg_QN, xreg_QN, mem_notifier;
reg reg_Q, xreg_Q, reg_QN, xreg_QN, mem_notifier;
   buf buf0 (Q, reg_Q);
   buf buf1 (QN, reg_QN);
endmodule

`celldefine
module srlab4 (RN, SN, Q, QN);
input RN, SN;
output Q, QN;
wire notifier, RN_buf, SN_buf;
reg notifier;
   buf b_RN (RN_buf, RN);
   buf b_SN (SN_buf, SN);
   s_srlab4 g1_s_srlab4_1 (RN_buf, SN_buf, Q, QN, notifier);
endmodule
`endcelldefine

`celldefine
module clk2d2 (CLK, C, CN);
input CLK;
output C, CN;
   not inst_1 (CN, CLK);
   buf inst_2 (C, CLK);
endmodule
`endcelldefine

`celldefine
module gclfsn1 (EN, CLK, SE, GCLK);
input EN, CLK, SE;
output GCLK;
wire notifier, init, init_2;
reg notifier;
   U_LD_P_NO U_LD_P_NO0 (init, EN, CLK, notifier);
   nor nor1 (init_2, init, SE);
   or or2 (GCLK, init_2, CLK);
endmodule
`endcelldefine

`celldefine
module gclfsn2 (EN, CLK, SE, GCLK);
input EN, CLK, SE;
output GCLK;
wire notifier, init, init_2;
reg notifier;
   U_LD_P_NO U_LD_P_NO0 (init, EN, CLK, notifier);
   nor nor1 (init_2, init, SE);
   or or2 (GCLK, init_2, CLK);
endmodule
`endcelldefine

`celldefine
module gclfsn4 (EN, CLK, SE, GCLK);
input EN, CLK, SE;
output GCLK;
wire notifier, init, init_2;
reg notifier;
   U_LD_P_NO U_LD_P_NO0 (init, EN, CLK, notifier);
   nor nor1 (init_2, init, SE);
   or or2 (GCLK, init_2, CLK);
endmodule
`endcelldefine

`celldefine
module gclfsn7 (EN, CLK, SE, GCLK);
input EN, CLK, SE;
output GCLK;
wire notifier, init, init_2;
reg notifier;
   U_LD_P_NO U_LD_P_NO0 (init, EN, CLK, notifier);
   nor nor1 (init_2, init, SE);
   or or2 (GCLK, init_2, CLK);
endmodule
`endcelldefine

`celldefine
module gclfsna (EN, CLK, SE, GCLK);
input EN, CLK, SE;
output GCLK;
wire notifier, init, init_2;
reg notifier;
   U_LD_P_NO U_LD_P_NO0 (init, EN, CLK, notifier);
   nor nor1 (init_2, init, SE);
   or or2 (GCLK, init_2, CLK);
endmodule
`endcelldefine

`celldefine
module gclrsn1 (EN, CLK, SE, GCLK);
input EN, CLK, SE;
output GCLK;
wire notifier, init, init_2, NOT_CLK;
reg notifier;
   U_LD_N_NO U_LD_N_NO0 (init, EN, CLK, notifier);
   nor nor1 (init_2, SE, init);
   not not2 (NOT_CLK, CLK);
   nor nor3 (GCLK, NOT_CLK, init_2);
endmodule
`endcelldefine

`celldefine
module gclrsn2 (EN, CLK, SE, GCLK);
input EN, CLK, SE;
output GCLK;
wire notifier, init, init_2, NOT_CLK;
reg notifier;
   U_LD_N_NO U_LD_N_NO0 (init, EN, CLK, notifier);
   nor nor1 (init_2, SE, init);
   not not2 (NOT_CLK, CLK);
   nor nor3 (GCLK, NOT_CLK, init_2);
endmodule
`endcelldefine

`celldefine
module gclrsn4 (EN, CLK, SE, GCLK);
input EN, CLK, SE;
output GCLK;
wire notifier, init, init_2, NOT_CLK;
reg notifier;
   U_LD_N_NO U_LD_N_NO0 (init, EN, CLK, notifier);
   nor nor1 (init_2, SE, init);
   not not2 (NOT_CLK, CLK);
   nor nor3 (GCLK, NOT_CLK, init_2);
endmodule
`endcelldefine

`celldefine
module gclrsn7 (EN, CLK, SE, GCLK);
input EN, CLK, SE;
output GCLK;
wire notifier, init, init_2, NOT_CLK;
reg notifier;
   U_LD_N_NO U_LD_N_NO0 (init, EN, CLK, notifier);
   nor nor1 (init_2, SE, init);
   not not2 (NOT_CLK, CLK);
   nor nor3 (GCLK, NOT_CLK, init_2);
endmodule
`endcelldefine

`celldefine
module gclrsna (EN, CLK, SE, GCLK);
input EN, CLK, SE;
output GCLK;
wire notifier, init, init_2, NOT_CLK;
reg notifier;
   U_LD_N_NO U_LD_N_NO0 (init, EN, CLK, notifier);
   nor nor1 (init_2, SE, init);
   not not2 (NOT_CLK, CLK);
   nor nor3 (GCLK, NOT_CLK, init_2);
endmodule
`endcelldefine

`celldefine
module adiode (I);
input I;
wire DeadEnd;
   buf E0 (DeadEnd, I);
endmodule
`endcelldefine

`celldefine
module oaim311d4 (C3, C2, C1, B, A, ZN);
input C3, C2, C1, B, A;
output ZN;
wire C3_buf, C2_buf, C1_buf, B_buf, A_buf, ZN_OUT, _and6;
   buf buf0 (C3_buf, C3);
   buf buf1 (C2_buf, C2);
   buf buf2 (C1_buf, C1);
   buf buf3 (B_buf, B);
   buf buf4 (A_buf, A);
   or _or5 (ZN_OUT, !B_buf, !A_buf, _and6);
   and _and6 (_and6, C1_buf, C3_buf, C2_buf);
   buf buf7 (ZN, ZN_OUT);
endmodule
`endcelldefine

`celldefine
module oaim311d2 (C3, C2, C1, B, A, ZN);
input C3, C2, C1, B, A;
output ZN;
wire C3_buf, C2_buf, C1_buf, B_buf, A_buf, ZN_OUT, _and6;
   buf buf0 (C3_buf, C3);
   buf buf1 (C2_buf, C2);
   buf buf2 (C1_buf, C1);
   buf buf3 (B_buf, B);
   buf buf4 (A_buf, A);
   or _or5 (ZN_OUT, !B_buf, !A_buf, _and6);
   and _and6 (_and6, C1_buf, C3_buf, C2_buf);
   buf buf7 (ZN, ZN_OUT);
endmodule
`endcelldefine

`celldefine
module oaim311d1 (C3, C2, C1, B, A, ZN);
input C3, C2, C1, B, A;
output ZN;
wire C3_buf, C2_buf, C1_buf, B_buf, A_buf, ZN_OUT, _and6;
   buf buf0 (C3_buf, C3);
   buf buf1 (C2_buf, C2);
   buf buf2 (C1_buf, C1);
   buf buf3 (B_buf, B);
   buf buf4 (A_buf, A);
   or _or5 (ZN_OUT, !B_buf, !A_buf, _and6);
   and _and6 (_and6, C1_buf, C3_buf, C2_buf);
   buf buf7 (ZN, ZN_OUT);
endmodule
`endcelldefine

`celldefine
module oaim211d4 (C2, C1, B, A, ZN);
input C2, C1, B, A;
output ZN;
wire C2_buf, C1_buf, B_buf, A_buf, ZN_OUT, _and5, _and4;
   buf buf0 (C2_buf, C2);
   buf buf1 (C1_buf, C1);
   buf buf2 (B_buf, B);
   buf buf3 (A_buf, A);
   and _and4 (_and4, B_buf, A_buf, !C2_buf);
   and _and5 (_and5, B_buf, A_buf, !C1_buf);
   nor _or6 (ZN_OUT, _and4, _and5);
   buf buf7 (ZN, ZN_OUT);
endmodule
`endcelldefine

`celldefine
module oaim211d2 (C2, C1, B, A, ZN);
input C2, C1, B, A;
output ZN;
wire C2_buf, C1_buf, B_buf, A_buf, ZN_OUT, _and5, _and4;
   buf buf0 (C2_buf, C2);
   buf buf1 (C1_buf, C1);
   buf buf2 (B_buf, B);
   buf buf3 (A_buf, A);
   and _and4 (_and4, B_buf, A_buf, !C2_buf);
   and _and5 (_and5, B_buf, A_buf, !C1_buf);
   nor _or6 (ZN_OUT, _and4, _and5);
   buf buf7 (ZN, ZN_OUT);
endmodule
`endcelldefine

`celldefine
module oaim211d1 (C2, C1, B, A, ZN);
input C2, C1, B, A;
output ZN;
wire C2_buf, C1_buf, B_buf, A_buf, ZN_OUT, _and5, _and4;
   buf buf0 (C2_buf, C2);
   buf buf1 (C1_buf, C1);
   buf buf2 (B_buf, B);
   buf buf3 (A_buf, A);
   and _and4 (_and4, B_buf, A_buf, !C2_buf);
   and _and5 (_and5, B_buf, A_buf, !C1_buf);
   nor _or6 (ZN_OUT, _and4, _and5);
   buf buf7 (ZN, ZN_OUT);
endmodule
`endcelldefine

`celldefine
module oai2222d4 (A1, A2, B1, B2, C1, C2, D1, D2, ZN);
input A1, A2, B1, B2, C1, C2, D1, D2;
output ZN;
wire g_1_out, g_2_out, g_3_out, g_4_out;
   or or0 (g_1_out, D2, D1);
   or or1 (g_2_out, B2, B1);
   or or2 (g_3_out, A2, A1);
   or or3 (g_4_out, C2, C1);
   nand nand4 (ZN, g_1_out, g_2_out, g_3_out, g_4_out);
endmodule
`endcelldefine

`celldefine
module oai2222d2 (A1, A2, B1, B2, C1, C2, D1, D2, ZN);
input A1, A2, B1, B2, C1, C2, D1, D2;
output ZN;
wire g_1_out, g_2_out, g_3_out, g_4_out;
   or or0 (g_1_out, D2, D1);
   or or1 (g_2_out, B2, B1);
   or or2 (g_3_out, A2, A1);
   or or3 (g_4_out, C2, C1);
   nand nand4 (ZN, g_1_out, g_2_out, g_3_out, g_4_out);
endmodule
`endcelldefine

`celldefine
module oai2222d1 (A1, A2, B1, B2, C1, C2, D1, D2, ZN);
input A1, A2, B1, B2, C1, C2, D1, D2;
output ZN;
wire g_1_out, g_2_out, g_3_out, g_4_out;
   or or0 (g_1_out, D2, D1);
   or or1 (g_2_out, B2, B1);
   or or2 (g_3_out, A2, A1);
   or or3 (g_4_out, C2, C1);
   nand nand4 (ZN, g_1_out, g_2_out, g_3_out, g_4_out);
endmodule
`endcelldefine

`celldefine
module aoi2222d1 (A1, A2, B1, B2, C1, C2, D1, D2, ZN);
input A1, A2, B1, B2, C1, C2, D1, D2;
output ZN;
wire g_1_out, g_2_out, g_3_out, g_4_out;
   and and0 (g_1_out, A2, A1);
   and and1 (g_2_out, B2, B1);
   and and2 (g_3_out, C2, C1);
   and and3 (g_4_out, D2, D1);
   nor nor4 (ZN, g_1_out, g_2_out, g_3_out, g_4_out);
endmodule
`endcelldefine

`celldefine
module aoi2222d2 (A1, A2, B1, B2, C1, C2, D1, D2, ZN);
input A1, A2, B1, B2, C1, C2, D1, D2;
output ZN;
wire g_1_out, g_2_out, g_3_out, g_4_out;
   and and0 (g_1_out, A2, A1);
   and and1 (g_2_out, B2, B1);
   and and2 (g_3_out, C2, C1);
   and and3 (g_4_out, D2, D1);
   nor nor4 (ZN, g_1_out, g_2_out, g_3_out, g_4_out);
endmodule
`endcelldefine

`celldefine
module aoi2222d4 (A1, A2, B1, B2, C1, C2, D1, D2, ZN);
input A1, A2, B1, B2, C1, C2, D1, D2;
output ZN;
wire g_1_out, g_2_out, g_3_out, g_4_out;
   and and0 (g_1_out, A2, A1);
   and and1 (g_2_out, B2, B1);
   and and2 (g_3_out, C2, C1);
   and and3 (g_4_out, D2, D1);
   nor nor4 (ZN, g_1_out, g_2_out, g_3_out, g_4_out);
endmodule
`endcelldefine

`celldefine
module aoim211d1 (C2, C1, B, A, ZN);
input C2, C1, B, A;
output ZN;
wire C2_buf, C1_buf, B_buf, A_buf, ZN_OUT, _and5, _and4;
   buf buf0 (C2_buf, C2);
   buf buf1 (C1_buf, C1);
   buf buf2 (B_buf, B);
   buf buf3 (A_buf, A);
   and _and4 (_and4, !B_buf, !A_buf, C2_buf);
   and _and5 (_and5, !B_buf, !A_buf, C1_buf);
   or _or6 (ZN_OUT, _and4, _and5);
   buf buf7 (ZN, ZN_OUT);
endmodule
`endcelldefine

`celldefine
module aoim211d2 (C2, C1, B, A, ZN);
input C2, C1, B, A;
output ZN;
wire C2_buf, C1_buf, B_buf, A_buf, ZN_OUT, _and5, _and4;
   buf buf0 (C2_buf, C2);
   buf buf1 (C1_buf, C1);
   buf buf2 (B_buf, B);
   buf buf3 (A_buf, A);
   and _and4 (_and4, !B_buf, !A_buf, C2_buf);
   and _and5 (_and5, !B_buf, !A_buf, C1_buf);
   or _or6 (ZN_OUT, _and4, _and5);
   buf buf7 (ZN, ZN_OUT);
endmodule
`endcelldefine

`celldefine
module aoim211d4 (C2, C1, B, A, ZN);
input C2, C1, B, A;
output ZN;
wire C2_buf, C1_buf, B_buf, A_buf, ZN_OUT, _and5, _and4;
   buf buf0 (C2_buf, C2);
   buf buf1 (C1_buf, C1);
   buf buf2 (B_buf, B);
   buf buf3 (A_buf, A);
   and _and4 (_and4, !B_buf, !A_buf, C2_buf);
   and _and5 (_and5, !B_buf, !A_buf, C1_buf);
   or _or6 (ZN_OUT, _and4, _and5);
   buf buf7 (ZN, ZN_OUT);
endmodule
`endcelldefine

`celldefine
module aoim311d1 (C3, C2, C1, B, A, ZN);
input C3, C2, C1, B, A;
output ZN;
wire C3_buf, C2_buf, C1_buf, B_buf, A_buf, ZN_OUT, _and6;
   buf buf0 (C3_buf, C3);
   buf buf1 (C2_buf, C2);
   buf buf2 (C1_buf, C1);
   buf buf3 (B_buf, B);
   buf buf4 (A_buf, A);
   nor _or5 (ZN_OUT, B_buf, A_buf, _and6);
   and _and6 (_and6, !C1_buf, !C3_buf, !C2_buf);
   buf buf7 (ZN, ZN_OUT);
endmodule
`endcelldefine

`celldefine
module aoim311d2 (C3, C2, C1, B, A, ZN);
input C3, C2, C1, B, A;
output ZN;
wire C3_buf, C2_buf, C1_buf, B_buf, A_buf, ZN_OUT, _and6;
   buf buf0 (C3_buf, C3);
   buf buf1 (C2_buf, C2);
   buf buf2 (C1_buf, C1);
   buf buf3 (B_buf, B);
   buf buf4 (A_buf, A);
   nor _or5 (ZN_OUT, B_buf, A_buf, _and6);
   and _and6 (_and6, !C1_buf, !C3_buf, !C2_buf);
   buf buf7 (ZN, ZN_OUT);
endmodule
`endcelldefine

`celldefine
module aoim311d4 (C3, C2, C1, B, A, ZN);
input C3, C2, C1, B, A;
output ZN;
wire C3_buf, C2_buf, C1_buf, B_buf, A_buf, ZN_OUT, _and6;
   buf buf0 (C3_buf, C3);
   buf buf1 (C2_buf, C2);
   buf buf2 (C1_buf, C1);
   buf buf3 (B_buf, B);
   buf buf4 (A_buf, A);
   nor _or5 (ZN_OUT, B_buf, A_buf, _and6);
   and _and6 (_and6, !C1_buf, !C3_buf, !C2_buf);
   buf buf7 (ZN, ZN_OUT);
endmodule
`endcelldefine

`celldefine
module oaim31d4 (B3, B2, B1, A, ZN);
input B3, B2, B1, A;
output ZN;
wire B3_buf, B2_buf, B1_buf, A_buf, ZN_OUT, _and4;
   buf buf0 (B3_buf, B3);
   buf buf1 (B2_buf, B2);
   buf buf2 (B1_buf, B1);
   buf buf3 (A_buf, A);
   and _and4 (_and4, B2_buf, B1_buf, B3_buf);
   or _or5 (ZN_OUT, !A_buf, _and4);
   buf buf6 (ZN, ZN_OUT);
endmodule
`endcelldefine

`celldefine
module oaim22d4 (B2, B1, A2, A1, ZN);
input B2, B1, A2, A1;
output ZN;
wire B2_buf, B1_buf, A2_buf, A1_buf, ZN_OUT, _and5, _and4;
   buf buf0 (B2_buf, B2);
   buf buf1 (B1_buf, B1);
   buf buf2 (A2_buf, A2);
   buf buf3 (A1_buf, A1);
   and _and4 (_and4, !A2_buf, !A1_buf);
   and _and5 (_and5, B2_buf, B1_buf);
   or _or6 (ZN_OUT, _and4, _and5);
   buf buf7 (ZN, ZN_OUT);
endmodule
`endcelldefine

`celldefine
module oaim21d4 (B2, B1, A, ZN);
input B2, B1, A;
output ZN;
wire B2_buf, B1_buf, A_buf, ZN_OUT, _and3;
   buf buf0 (B2_buf, B2);
   buf buf1 (B1_buf, B1);
   buf buf2 (A_buf, A);
   and _and3 (_and3, B1_buf, B2_buf);
   or _or4 (ZN_OUT, !A_buf, _and3);
   buf buf5 (ZN, ZN_OUT);
endmodule
`endcelldefine

`celldefine
module oai322d4 (C3, C2, C1, B2, B1, A2, A1, ZN);
input C3, C2, C1, B2, B1, A2, A1;
output ZN;
wire g_1_out, g_2_out, g_3_out;
   or or0 (g_1_out, B2, B1);
   or or1 (g_2_out, A2, A1);
   or or2 (g_3_out, C2, C1, C3);
   nand nand3 (ZN, g_1_out, g_2_out, g_3_out);
endmodule
`endcelldefine

`celldefine
module oai321d4 (C3, C2, C1, B2, B1, A, ZN);
input C3, C2, C1, B2, B1, A;
output ZN;
wire g_2_out, g_3_out;
   or or0 (g_2_out, C3, C2, C1);
   or or1 (g_3_out, B1, B2);
   nand nand2 (ZN, A, g_2_out, g_3_out);
endmodule
`endcelldefine

`celldefine
module oai311d4 (C3, C2, C1, B, A, ZN);
input C3, C2, C1, B, A;
output ZN;
wire g_3_out;
   or or0 (g_3_out, C1, C3, C2);
   nand nand1 (ZN, B, A, g_3_out);
endmodule
`endcelldefine

`celldefine
module oai222d4 (A1, A2, B1, B2, C1, C2, ZN);
input A1, A2, B1, B2, C1, C2;
output ZN;
wire g_1_out, g_2_out, g_3_out;
   or or0 (g_1_out, C2, C1);
   or or1 (g_2_out, A2, A1);
   or or2 (g_3_out, B2, B1);
   nand nand3 (ZN, g_1_out, g_2_out, g_3_out);
endmodule
`endcelldefine

`celldefine
module oai221d4 (C1, C2, B1, B2, A, ZN);
input C1, C2, B1, B2, A;
output ZN;
wire g_2_out, g_3_out;
   or or0 (g_2_out, C1, C2);
   or or1 (g_3_out, B2, B1);
   nand nand2 (ZN, A, g_2_out, g_3_out);
endmodule
`endcelldefine

`celldefine
module oai211d4 (C1, C2, A, B, ZN);
input C1, C2, A, B;
output ZN;
wire g_1_out, g_2_out;
   and and0 (g_1_out, B, A, C1);
   and and1 (g_2_out, B, A, C2);
   nor nor2 (ZN, g_1_out, g_2_out);
endmodule
`endcelldefine

`celldefine
module aoi211d4 (C1, C2, B, A, ZN);
input C1, C2, B, A;
output ZN;
wire g_1_out, g_2_out;
   or or0 (g_1_out, B, A, C2);
   or or1 (g_2_out, B, A, C1);
   nand nand2 (ZN, g_1_out, g_2_out);
endmodule
`endcelldefine

`celldefine
module aoi221d4 (C1, C2, B1, B2, A, ZN);
input C1, C2, B1, B2, A;
output ZN;
wire g_1_out, g_2_out;
   and and0 (g_1_out, C1, C2);
   and and1 (g_2_out, B2, B1);
   nor nor2 (ZN, g_1_out, g_2_out, A);
endmodule
`endcelldefine

`celldefine
module aoi222d4 (A1, A2, B1, B2, C1, C2, ZN);
input A1, A2, B1, B2, C1, C2;
output ZN;
wire g_1_out, g_2_out, g_3_out;
   and and0 (g_1_out, A2, A1);
   and and1 (g_2_out, B2, B1);
   and and2 (g_3_out, C2, C1);
   nor nor3 (ZN, g_1_out, g_2_out, g_3_out);
endmodule
`endcelldefine

`celldefine
module aoi311d4 (C3, C2, C1, B, A, ZN);
input C3, C2, C1, B, A;
output ZN;
wire g_1_out;
   and and0 (g_1_out, C1, C3, C2);
   nor nor1 (ZN, g_1_out, B, A);
endmodule
`endcelldefine

`celldefine
module aoi321d4 (C3, C2, C1, B2, B1, A, ZN);
input C3, C2, C1, B2, B1, A;
output ZN;
wire g_1_out, g_2_out;
   and and0 (g_1_out, C3, C2, C1);
   and and1 (g_2_out, B1, B2);
   nor nor2 (ZN, g_1_out, g_2_out, A);
endmodule
`endcelldefine

`celldefine
module aoi322d4 (C3, C2, C1, B2, B1, A2, A1, ZN);
input C3, C2, C1, B2, B1, A2, A1;
output ZN;
wire g_1_out, g_2_out, g_3_out;
   and and0 (g_1_out, C2, C1, C3);
   and and1 (g_2_out, B2, B1);
   and and2 (g_3_out, A2, A1);
   nor nor3 (ZN, g_1_out, g_2_out, g_3_out);
endmodule
`endcelldefine

`celldefine
module aoim21d4 (B2, B1, A, ZN);
input B2, B1, A;
output ZN;
wire B2_buf, B1_buf, A_buf, ZN_OUT, _and3;
   buf buf0 (B2_buf, B2);
   buf buf1 (B1_buf, B1);
   buf buf2 (A_buf, A);
   and _and3 (_and3, !B1_buf, !B2_buf);
   nor _or4 (ZN_OUT, A_buf, _and3);
   buf buf5 (ZN, ZN_OUT);
endmodule
`endcelldefine

`celldefine
module aoim22d4 (B2, B1, A2, A1, Z);
input B2, B1, A2, A1;
output Z;
wire B2_buf, B1_buf, A2_buf, A1_buf, Z_OUT, _and5, _and4;
   buf buf0 (B2_buf, B2);
   buf buf1 (B1_buf, B1);
   buf buf2 (A2_buf, A2);
   buf buf3 (A1_buf, A1);
   and _and4 (_and4, !B2_buf, !B1_buf);
   and _and5 (_and5, A2_buf, A1_buf);
   nor _or6 (Z_OUT, _and4, _and5);
   buf buf7 (Z, Z_OUT);
endmodule
`endcelldefine

`celldefine
module aoim31d4 (B3, B2, B1, A, ZN);
input B3, B2, B1, A;
output ZN;
wire B3_buf, B2_buf, B1_buf, A_buf, ZN_OUT, _and4;
   buf buf0 (B3_buf, B3);
   buf buf1 (B2_buf, B2);
   buf buf2 (B1_buf, B1);
   buf buf3 (A_buf, A);
   and _and4 (_and4, !B2_buf, !B1_buf, !B3_buf);
   nor _or5 (ZN_OUT, A_buf, _and4);
   buf buf6 (ZN, ZN_OUT);
endmodule
`endcelldefine

`celldefine
module oaim31d2 (B3, B2, B1, A, ZN);
input B3, B2, B1, A;
output ZN;
wire B3_buf, B2_buf, B1_buf, A_buf, ZN_OUT, _and4;
   buf buf0 (B3_buf, B3);
   buf buf1 (B2_buf, B2);
   buf buf2 (B1_buf, B1);
   buf buf3 (A_buf, A);
   and _and4 (_and4, B2_buf, B1_buf, B3_buf);
   or _or5 (ZN_OUT, !A_buf, _and4);
   buf buf6 (ZN, ZN_OUT);
endmodule
`endcelldefine

`celldefine
module oaim22d2 (B2, B1, A2, A1, ZN);
input B2, B1, A2, A1;
output ZN;
wire B2_buf, B1_buf, A2_buf, A1_buf, ZN_OUT, _and5, _and4;
   buf buf0 (B2_buf, B2);
   buf buf1 (B1_buf, B1);
   buf buf2 (A2_buf, A2);
   buf buf3 (A1_buf, A1);
   and _and4 (_and4, !A2_buf, !A1_buf);
   and _and5 (_and5, B2_buf, B1_buf);
   or _or6 (ZN_OUT, _and4, _and5);
   buf buf7 (ZN, ZN_OUT);
endmodule
`endcelldefine

`celldefine
module oaim21d2 (B2, B1, A, ZN);
input B2, B1, A;
output ZN;
wire B2_buf, B1_buf, A_buf, ZN_OUT, _and3;
   buf buf0 (B2_buf, B2);
   buf buf1 (B1_buf, B1);
   buf buf2 (A_buf, A);
   and _and3 (_and3, B1_buf, B2_buf);
   or _or4 (ZN_OUT, !A_buf, _and3);
   buf buf5 (ZN, ZN_OUT);
endmodule
`endcelldefine

`celldefine
module oai322d2 (C3, C2, C1, B2, B1, A2, A1, ZN);
input C3, C2, C1, B2, B1, A2, A1;
output ZN;
wire g_1_out, g_2_out, g_3_out;
   or or0 (g_1_out, B2, B1);
   or or1 (g_2_out, A2, A1);
   or or2 (g_3_out, C2, C1, C3);
   nand nand3 (ZN, g_1_out, g_2_out, g_3_out);
endmodule
`endcelldefine

`celldefine
module oai321d2 (C3, C2, C1, B2, B1, A, ZN);
input C3, C2, C1, B2, B1, A;
output ZN;
wire g_2_out, g_3_out;
   or or0 (g_2_out, C3, C2, C1);
   or or1 (g_3_out, B1, B2);
   nand nand2 (ZN, A, g_2_out, g_3_out);
endmodule
`endcelldefine

`celldefine
module oai311d2 (C3, C2, C1, B, A, ZN);
input C3, C2, C1, B, A;
output ZN;
wire g_3_out;
   or or0 (g_3_out, C1, C3, C2);
   nand nand1 (ZN, B, A, g_3_out);
endmodule
`endcelldefine

`celldefine
module oai222d2 (A1, A2, B1, B2, C1, C2, ZN);
input A1, A2, B1, B2, C1, C2;
output ZN;
wire g_1_out, g_2_out, g_3_out;
   or or0 (g_1_out, C2, C1);
   or or1 (g_2_out, A2, A1);
   or or2 (g_3_out, B2, B1);
   nand nand3 (ZN, g_1_out, g_2_out, g_3_out);
endmodule
`endcelldefine

`celldefine
module oai221d2 (C1, C2, B1, B2, A, ZN);
input C1, C2, B1, B2, A;
output ZN;
wire g_2_out, g_3_out;
   or or0 (g_2_out, C1, C2);
   or or1 (g_3_out, B2, B1);
   nand nand2 (ZN, A, g_2_out, g_3_out);
endmodule
`endcelldefine

`celldefine
module oai211d2 (C1, C2, A, B, ZN);
input C1, C2, A, B;
output ZN;
wire g_1_out, g_2_out;
   and and0 (g_1_out, B, A, C1);
   and and1 (g_2_out, B, A, C2);
   nor nor2 (ZN, g_1_out, g_2_out);
endmodule
`endcelldefine

`celldefine
module aoi211d2 (C1, C2, B, A, ZN);
input C1, C2, B, A;
output ZN;
wire g_1_out, g_2_out;
   or or0 (g_1_out, B, A, C2);
   or or1 (g_2_out, B, A, C1);
   nand nand2 (ZN, g_1_out, g_2_out);
endmodule
`endcelldefine

`celldefine
module aoi221d2 (C1, C2, B1, B2, A, ZN);
input C1, C2, B1, B2, A;
output ZN;
wire g_1_out, g_2_out;
   and and0 (g_1_out, C1, C2);
   and and1 (g_2_out, B2, B1);
   nor nor2 (ZN, g_1_out, g_2_out, A);
endmodule
`endcelldefine

`celldefine
module aoi222d2 (A1, A2, B1, B2, C1, C2, ZN);
input A1, A2, B1, B2, C1, C2;
output ZN;
wire g_1_out, g_2_out, g_3_out;
   and and0 (g_1_out, A2, A1);
   and and1 (g_2_out, B2, B1);
   and and2 (g_3_out, C2, C1);
   nor nor3 (ZN, g_1_out, g_2_out, g_3_out);
endmodule
`endcelldefine

`celldefine
module aoi311d2 (C3, C2, C1, B, A, ZN);
input C3, C2, C1, B, A;
output ZN;
wire g_1_out;
   and and0 (g_1_out, C1, C3, C2);
   nor nor1 (ZN, g_1_out, B, A);
endmodule
`endcelldefine

`celldefine
module aoi321d2 (C3, C2, C1, B2, B1, A, ZN);
input C3, C2, C1, B2, B1, A;
output ZN;
wire g_1_out, g_2_out;
   and and0 (g_1_out, C3, C2, C1);
   and and1 (g_2_out, B1, B2);
   nor nor2 (ZN, g_1_out, g_2_out, A);
endmodule
`endcelldefine

`celldefine
module aoi322d2 (C3, C2, C1, B2, B1, A2, A1, ZN);
input C3, C2, C1, B2, B1, A2, A1;
output ZN;
wire g_1_out, g_2_out, g_3_out;
   and and0 (g_1_out, C2, C1, C3);
   and and1 (g_2_out, B2, B1);
   and and2 (g_3_out, A2, A1);
   nor nor3 (ZN, g_1_out, g_2_out, g_3_out);
endmodule
`endcelldefine

`celldefine
module aoim21d2 (B2, B1, A, ZN);
input B2, B1, A;
output ZN;
wire B2_buf, B1_buf, A_buf, ZN_OUT, _and3;
   buf buf0 (B2_buf, B2);
   buf buf1 (B1_buf, B1);
   buf buf2 (A_buf, A);
   and _and3 (_and3, !B1_buf, !B2_buf);
   nor _or4 (ZN_OUT, A_buf, _and3);
   buf buf5 (ZN, ZN_OUT);
endmodule
`endcelldefine

`celldefine
module aoim22d2 (B2, B1, A2, A1, Z);
input B2, B1, A2, A1;
output Z;
wire B2_buf, B1_buf, A2_buf, A1_buf, Z_OUT, _and5, _and4;
   buf buf0 (B2_buf, B2);
   buf buf1 (B1_buf, B1);
   buf buf2 (A2_buf, A2);
   buf buf3 (A1_buf, A1);
   and _and4 (_and4, !B2_buf, !B1_buf);
   and _and5 (_and5, A2_buf, A1_buf);
   nor _or6 (Z_OUT, _and4, _and5);
   buf buf7 (Z, Z_OUT);
endmodule
`endcelldefine

`celldefine
module aoim31d2 (B3, B2, B1, A, ZN);
input B3, B2, B1, A;
output ZN;
wire B3_buf, B2_buf, B1_buf, A_buf, ZN_OUT, _and4;
   buf buf0 (B3_buf, B3);
   buf buf1 (B2_buf, B2);
   buf buf2 (B1_buf, B1);
   buf buf3 (A_buf, A);
   and _and4 (_and4, !B2_buf, !B1_buf, !B3_buf);
   nor _or5 (ZN_OUT, A_buf, _and4);
   buf buf6 (ZN, ZN_OUT);
endmodule
`endcelldefine

`celldefine
module oaim3m11d4 (C3, C2, C1, B, A, ZN);
input C3, C2, C1, B, A;
output ZN;
wire C3_buf, C2_buf, C1_buf, B_buf, A_buf, ZN_OUT, _and6;
   buf buf0 (C3_buf, C3);
   buf buf1 (C2_buf, C2);
   buf buf2 (C1_buf, C1);
   buf buf3 (B_buf, B);
   buf buf4 (A_buf, A);
   or _or5 (ZN_OUT, !A_buf, B_buf, _and6);
   and _and6 (_and6, C1_buf, C3_buf, C2_buf);
   buf buf7 (ZN, ZN_OUT);
endmodule
`endcelldefine

`celldefine
module oaim3m11d2 (C3, C2, C1, B, A, ZN);
input C3, C2, C1, B, A;
output ZN;
wire C3_buf, C2_buf, C1_buf, B_buf, A_buf, ZN_OUT, _and6;
   buf buf0 (C3_buf, C3);
   buf buf1 (C2_buf, C2);
   buf buf2 (C1_buf, C1);
   buf buf3 (B_buf, B);
   buf buf4 (A_buf, A);
   or _or5 (ZN_OUT, !A_buf, B_buf, _and6);
   and _and6 (_and6, C1_buf, C3_buf, C2_buf);
   buf buf7 (ZN, ZN_OUT);
endmodule
`endcelldefine

`celldefine
module oaim3m11d1 (C3, C2, C1, B, A, ZN);
input C3, C2, C1, B, A;
output ZN;
wire C3_buf, C2_buf, C1_buf, B_buf, A_buf, ZN_OUT, _and6;
   buf buf0 (C3_buf, C3);
   buf buf1 (C2_buf, C2);
   buf buf2 (C1_buf, C1);
   buf buf3 (B_buf, B);
   buf buf4 (A_buf, A);
   or _or5 (ZN_OUT, !A_buf, B_buf, _and6);
   and _and6 (_and6, C1_buf, C3_buf, C2_buf);
   buf buf7 (ZN, ZN_OUT);
endmodule
`endcelldefine

`celldefine
module oaim31d1 (B3, B2, B1, A, ZN);
input B3, B2, B1, A;
output ZN;
wire B3_buf, B2_buf, B1_buf, A_buf, ZN_OUT, _and4;
   buf buf0 (B3_buf, B3);
   buf buf1 (B2_buf, B2);
   buf buf2 (B1_buf, B1);
   buf buf3 (A_buf, A);
   and _and4 (_and4, B2_buf, B1_buf, B3_buf);
   or _or5 (ZN_OUT, !A_buf, _and4);
   buf buf6 (ZN, ZN_OUT);
endmodule
`endcelldefine

`celldefine
module oaim2m11d4 (C2, C1, B, A, ZN);
input C2, C1, B, A;
output ZN;
wire C2_buf, C1_buf, B_buf, A_buf, ZN_OUT, _and5, _and4;
   buf buf0 (C2_buf, C2);
   buf buf1 (C1_buf, C1);
   buf buf2 (B_buf, B);
   buf buf3 (A_buf, A);
   and _and4 (_and4, !B_buf, A_buf, !C2_buf);
   and _and5 (_and5, !B_buf, A_buf, !C1_buf);
   nor _or6 (ZN_OUT, _and4, _and5);
   buf buf7 (ZN, ZN_OUT);
endmodule
`endcelldefine

`celldefine
module oaim2m11d2 (C2, C1, B, A, ZN);
input C2, C1, B, A;
output ZN;
wire C2_buf, C1_buf, B_buf, A_buf, ZN_OUT, _and5, _and4;
   buf buf0 (C2_buf, C2);
   buf buf1 (C1_buf, C1);
   buf buf2 (B_buf, B);
   buf buf3 (A_buf, A);
   and _and4 (_and4, !B_buf, A_buf, !C2_buf);
   and _and5 (_and5, !B_buf, A_buf, !C1_buf);
   nor _or6 (ZN_OUT, _and4, _and5);
   buf buf7 (ZN, ZN_OUT);
endmodule
`endcelldefine

`celldefine
module oaim2m11d1 (C2, C1, B, A, ZN);
input C2, C1, B, A;
output ZN;
wire C2_buf, C1_buf, B_buf, A_buf, ZN_OUT, _and5, _and4;
   buf buf0 (C2_buf, C2);
   buf buf1 (C1_buf, C1);
   buf buf2 (B_buf, B);
   buf buf3 (A_buf, A);
   and _and4 (_and4, !B_buf, A_buf, !C2_buf);
   and _and5 (_and5, !B_buf, A_buf, !C1_buf);
   nor _or6 (ZN_OUT, _and4, _and5);
   buf buf7 (ZN, ZN_OUT);
endmodule
`endcelldefine

`celldefine
module oaim22d1 (B2, B1, A2, A1, ZN);
input B2, B1, A2, A1;
output ZN;
wire B2_buf, B1_buf, A2_buf, A1_buf, ZN_OUT, _and5, _and4;
   buf buf0 (B2_buf, B2);
   buf buf1 (B1_buf, B1);
   buf buf2 (A2_buf, A2);
   buf buf3 (A1_buf, A1);
   and _and4 (_and4, !A2_buf, !A1_buf);
   and _and5 (_and5, B2_buf, B1_buf);
   or _or6 (ZN_OUT, _and4, _and5);
   buf buf7 (ZN, ZN_OUT);
endmodule
`endcelldefine

`celldefine
module oaim21d1 (B2, B1, A, ZN);
input B2, B1, A;
output ZN;
wire B2_buf, B1_buf, A_buf, ZN_OUT, _and3;
   buf buf0 (B2_buf, B2);
   buf buf1 (B1_buf, B1);
   buf buf2 (A_buf, A);
   and _and3 (_and3, B1_buf, B2_buf);
   or _or4 (ZN_OUT, !A_buf, _and3);
   buf buf5 (ZN, ZN_OUT);
endmodule
`endcelldefine

`celldefine
module oai322d1 (C3, C2, C1, B2, B1, A2, A1, ZN);
input C3, C2, C1, B2, B1, A2, A1;
output ZN;
wire g_1_out, g_2_out, g_3_out;
   or or0 (g_1_out, B2, B1);
   or or1 (g_2_out, A2, A1);
   or or2 (g_3_out, C2, C1, C3);
   nand nand3 (ZN, g_1_out, g_2_out, g_3_out);
endmodule
`endcelldefine

`celldefine
module oai321d1 (C3, C2, C1, B2, B1, A, ZN);
input C3, C2, C1, B2, B1, A;
output ZN;
wire g_2_out, g_3_out;
   or or0 (g_2_out, C3, C2, C1);
   or or1 (g_3_out, B1, B2);
   nand nand2 (ZN, A, g_2_out, g_3_out);
endmodule
`endcelldefine

`celldefine
module oai311d1 (C3, C2, C1, B, A, ZN);
input C3, C2, C1, B, A;
output ZN;
wire g_3_out;
   or or0 (g_3_out, C1, C3, C2);
   nand nand1 (ZN, B, A, g_3_out);
endmodule
`endcelldefine

`celldefine
module oai222d1 (A1, A2, B1, B2, C1, C2, ZN);
input A1, A2, B1, B2, C1, C2;
output ZN;
wire g_1_out, g_2_out, g_3_out;
   or or0 (g_1_out, C2, C1);
   or or1 (g_2_out, A2, A1);
   or or2 (g_3_out, B2, B1);
   nand nand3 (ZN, g_1_out, g_2_out, g_3_out);
endmodule
`endcelldefine

`celldefine
module oai221d1 (C1, C2, B1, B2, A, ZN);
input C1, C2, B1, B2, A;
output ZN;
wire g_2_out, g_3_out;
   or or0 (g_2_out, C1, C2);
   or or1 (g_3_out, B2, B1);
   nand nand2 (ZN, A, g_2_out, g_3_out);
endmodule
`endcelldefine

`celldefine
module oai211d1 (C1, C2, A, B, ZN);
input C1, C2, A, B;
output ZN;
wire g_1_out, g_2_out;
   and and0 (g_1_out, B, A, C1);
   and and1 (g_2_out, B, A, C2);
   nor nor2 (ZN, g_1_out, g_2_out);
endmodule
`endcelldefine

`celldefine
module aoi211d1 (C1, C2, B, A, ZN);
input C1, C2, B, A;
output ZN;
wire g_1_out, g_2_out;
   or or0 (g_1_out, B, A, C2);
   or or1 (g_2_out, B, A, C1);
   nand nand2 (ZN, g_1_out, g_2_out);
endmodule
`endcelldefine

`celldefine
module aoi221d1 (C1, C2, B1, B2, A, ZN);
input C1, C2, B1, B2, A;
output ZN;
wire g_1_out, g_2_out;
   and and0 (g_1_out, C1, C2);
   and and1 (g_2_out, B2, B1);
   nor nor2 (ZN, g_1_out, g_2_out, A);
endmodule
`endcelldefine

`celldefine
module aoi222d1 (A1, A2, B1, B2, C1, C2, ZN);
input A1, A2, B1, B2, C1, C2;
output ZN;
wire g_1_out, g_2_out, g_3_out;
   and and0 (g_1_out, A2, A1);
   and and1 (g_2_out, B2, B1);
   and and2 (g_3_out, C2, C1);
   nor nor3 (ZN, g_1_out, g_2_out, g_3_out);
endmodule
`endcelldefine

`celldefine
module aoi311d1 (C3, C2, C1, B, A, ZN);
input C3, C2, C1, B, A;
output ZN;
wire g_1_out;
   and and0 (g_1_out, C1, C3, C2);
   nor nor1 (ZN, g_1_out, B, A);
endmodule
`endcelldefine

`celldefine
module aoi321d1 (C3, C2, C1, B2, B1, A, ZN);
input C3, C2, C1, B2, B1, A;
output ZN;
wire g_1_out, g_2_out;
   and and0 (g_1_out, C3, C2, C1);
   and and1 (g_2_out, B1, B2);
   nor nor2 (ZN, g_1_out, g_2_out, A);
endmodule
`endcelldefine

`celldefine
module aoi322d1 (C3, C2, C1, B2, B1, A2, A1, ZN);
input C3, C2, C1, B2, B1, A2, A1;
output ZN;
wire g_1_out, g_2_out, g_3_out;
   and and0 (g_1_out, C2, C1, C3);
   and and1 (g_2_out, B2, B1);
   and and2 (g_3_out, A2, A1);
   nor nor3 (ZN, g_1_out, g_2_out, g_3_out);
endmodule
`endcelldefine

`celldefine
module aoim21d1 (B2, B1, A, ZN);
input B2, B1, A;
output ZN;
wire B2_buf, B1_buf, A_buf, ZN_OUT, _and3;
   buf buf0 (B2_buf, B2);
   buf buf1 (B1_buf, B1);
   buf buf2 (A_buf, A);
   and _and3 (_and3, !B1_buf, !B2_buf);
   nor _or4 (ZN_OUT, A_buf, _and3);
   buf buf5 (ZN, ZN_OUT);
endmodule
`endcelldefine

`celldefine
module aoim22d1 (B2, B1, A2, A1, Z);
input B2, B1, A2, A1;
output Z;
wire B2_buf, B1_buf, A2_buf, A1_buf, Z_OUT, _and5, _and4;
   buf buf0 (B2_buf, B2);
   buf buf1 (B1_buf, B1);
   buf buf2 (A2_buf, A2);
   buf buf3 (A1_buf, A1);
   and _and4 (_and4, !B2_buf, !B1_buf);
   and _and5 (_and5, A2_buf, A1_buf);
   nor _or6 (Z_OUT, _and4, _and5);
   buf buf7 (Z, Z_OUT);
endmodule
`endcelldefine

`celldefine
module aoim2m11d1 (C2, C1, B, A, ZN);
input C2, C1, B, A;
output ZN;
wire C2_buf, C1_buf, B_buf, A_buf, ZN_OUT, _and5, _and4;
   buf buf0 (C2_buf, C2);
   buf buf1 (C1_buf, C1);
   buf buf2 (B_buf, B);
   buf buf3 (A_buf, A);
   and _and4 (_and4, B_buf, !A_buf, C1_buf);
   and _and5 (_and5, B_buf, !A_buf, C2_buf);
   or _or6 (ZN_OUT, _and4, _and5);
   buf buf7 (ZN, ZN_OUT);
endmodule
`endcelldefine

`celldefine
module aoim2m11d2 (C2, C1, B, A, ZN);
input C2, C1, B, A;
output ZN;
wire C2_buf, C1_buf, B_buf, A_buf, ZN_OUT, _and5, _and4;
   buf buf0 (C2_buf, C2);
   buf buf1 (C1_buf, C1);
   buf buf2 (B_buf, B);
   buf buf3 (A_buf, A);
   and _and4 (_and4, B_buf, !A_buf, C1_buf);
   and _and5 (_and5, B_buf, !A_buf, C2_buf);
   or _or6 (ZN_OUT, _and4, _and5);
   buf buf7 (ZN, ZN_OUT);
endmodule
`endcelldefine

`celldefine
module aoim2m11d4 (C2, C1, B, A, ZN);
input C2, C1, B, A;
output ZN;
wire C2_buf, C1_buf, B_buf, A_buf, ZN_OUT, _and5, _and4;
   buf buf0 (C2_buf, C2);
   buf buf1 (C1_buf, C1);
   buf buf2 (B_buf, B);
   buf buf3 (A_buf, A);
   and _and4 (_and4, B_buf, !A_buf, C1_buf);
   and _and5 (_and5, B_buf, !A_buf, C2_buf);
   or _or6 (ZN_OUT, _and4, _and5);
   buf buf7 (ZN, ZN_OUT);
endmodule
`endcelldefine

`celldefine
module aoim31d1 (B3, B2, B1, A, ZN);
input B3, B2, B1, A;
output ZN;
wire B3_buf, B2_buf, B1_buf, A_buf, ZN_OUT, _and4;
   buf buf0 (B3_buf, B3);
   buf buf1 (B2_buf, B2);
   buf buf2 (B1_buf, B1);
   buf buf3 (A_buf, A);
   and _and4 (_and4, !B2_buf, !B1_buf, !B3_buf);
   nor _or5 (ZN_OUT, A_buf, _and4);
   buf buf6 (ZN, ZN_OUT);
endmodule
`endcelldefine

`celldefine
module aoim3m11d1 (C3, C2, C1, B, A, ZN);
input C3, C2, C1, B, A;
output ZN;
wire C3_buf, C2_buf, C1_buf, B_buf, A_buf, ZN_OUT, _and5;
   buf buf0 (C3_buf, C3);
   buf buf1 (C2_buf, C2);
   buf buf2 (C1_buf, C1);
   buf buf3 (B_buf, B);
   buf buf4 (A_buf, A);
   and _and5 (_and5, !C1_buf, !C3_buf, !C2_buf);
   nor _or6 (ZN_OUT, !B_buf, _and5, A_buf);
   buf buf7 (ZN, ZN_OUT);
endmodule
`endcelldefine

`celldefine
module aoim3m11d2 (C3, C2, C1, B, A, ZN);
input C3, C2, C1, B, A;
output ZN;
wire C3_buf, C2_buf, C1_buf, B_buf, A_buf, ZN_OUT, _and5;
   buf buf0 (C3_buf, C3);
   buf buf1 (C2_buf, C2);
   buf buf2 (C1_buf, C1);
   buf buf3 (B_buf, B);
   buf buf4 (A_buf, A);
   and _and5 (_and5, !C1_buf, !C3_buf, !C2_buf);
   nor _or6 (ZN_OUT, !B_buf, _and5, A_buf);
   buf buf7 (ZN, ZN_OUT);
endmodule
`endcelldefine

`celldefine
module aoim3m11d4 (C3, C2, C1, B, A, ZN);
input C3, C2, C1, B, A;
output ZN;
wire C3_buf, C2_buf, C1_buf, B_buf, A_buf, ZN_OUT, _and5;
   buf buf0 (C3_buf, C3);
   buf buf1 (C2_buf, C2);
   buf buf2 (C1_buf, C1);
   buf buf3 (B_buf, B);
   buf buf4 (A_buf, A);
   and _and5 (_and5, !C1_buf, !C3_buf, !C2_buf);
   nor _or6 (ZN_OUT, !B_buf, _and5, A_buf);
   buf buf7 (ZN, ZN_OUT);
endmodule
`endcelldefine

`celldefine
module oai31d4 (B3, B2, B1, A, ZN);
input B3, B2, B1, A;
output ZN;
wire g_2_out;
   or or0 (g_2_out, B2, B1, B3);
   nand nand1 (ZN, A, g_2_out);
endmodule
`endcelldefine

`celldefine
module oai31d2 (B3, B2, B1, A, ZN);
input B3, B2, B1, A;
output ZN;
wire g_2_out;
   or or0 (g_2_out, B2, B1, B3);
   nand nand1 (ZN, A, g_2_out);
endmodule
`endcelldefine

`celldefine
module oai31d1 (B3, B2, B1, A, ZN);
input B3, B2, B1, A;
output ZN;
wire g_2_out;
   or or0 (g_2_out, B2, B1, B3);
   nand nand1 (ZN, A, g_2_out);
endmodule
`endcelldefine

`celldefine
module oai22d4 (A1, A2, B1, B2, ZN);
input A1, A2, B1, B2;
output ZN;
wire g_1_out, g_2_out;
   or or0 (g_1_out, B2, B1);
   or or1 (g_2_out, A2, A1);
   nand nand2 (ZN, g_1_out, g_2_out);
endmodule
`endcelldefine

`celldefine
module oai22d2 (A1, A2, B1, B2, ZN);
input A1, A2, B1, B2;
output ZN;
wire g_1_out, g_2_out;
   or or0 (g_1_out, B2, B1);
   or or1 (g_2_out, A2, A1);
   nand nand2 (ZN, g_1_out, g_2_out);
endmodule
`endcelldefine

`celldefine
module oai22d1 (A1, A2, B1, B2, ZN);
input A1, A2, B1, B2;
output ZN;
wire g_1_out, g_2_out;
   or or0 (g_1_out, B2, B1);
   or or1 (g_2_out, A2, A1);
   nand nand2 (ZN, g_1_out, g_2_out);
endmodule
`endcelldefine

`celldefine
module oai21d4 (B1, B2, A, ZN);
input B1, B2, A;
output ZN;
wire g_2_out;
   or or0 (g_2_out, B1, B2);
   nand nand1 (ZN, A, g_2_out);
endmodule
`endcelldefine

`celldefine
module oai21d2 (B1, B2, A, ZN);
input B1, B2, A;
output ZN;
wire g_2_out;
   or or0 (g_2_out, B1, B2);
   nand nand1 (ZN, A, g_2_out);
endmodule
`endcelldefine

`celldefine
module oai21d1 (B1, B2, A, ZN);
input B1, B2, A;
output ZN;
wire g_2_out;
   or or0 (g_2_out, B1, B2);
   nand nand1 (ZN, A, g_2_out);
endmodule
`endcelldefine

`celldefine
module aoi21d1 (B1, B2, A, ZN);
input B1, B2, A;
output ZN;
wire g_1_out;
   and and0 (g_1_out, B1, B2);
   nor nor1 (ZN, g_1_out, A);
endmodule
`endcelldefine

`celldefine
module aoi21d2 (B1, B2, A, ZN);
input B1, B2, A;
output ZN;
wire g_1_out;
   and and0 (g_1_out, B1, B2);
   nor nor1 (ZN, g_1_out, A);
endmodule
`endcelldefine

`celldefine
module aoi21d4 (B1, B2, A, ZN);
input B1, B2, A;
output ZN;
wire g_1_out;
   and and0 (g_1_out, B1, B2);
   nor nor1 (ZN, g_1_out, A);
endmodule
`endcelldefine

`celldefine
module aoi22d1 (A1, A2, B1, B2, ZN);
input A1, A2, B1, B2;
output ZN;
wire g_1_out, g_2_out;
   and and0 (g_1_out, A2, A1);
   and and1 (g_2_out, B2, B1);
   nor nor2 (ZN, g_1_out, g_2_out);
endmodule
`endcelldefine

`celldefine
module aoi22d2 (A1, A2, B1, B2, ZN);
input A1, A2, B1, B2;
output ZN;
wire g_1_out, g_2_out;
   and and0 (g_1_out, A2, A1);
   and and1 (g_2_out, B2, B1);
   nor nor2 (ZN, g_1_out, g_2_out);
endmodule
`endcelldefine

`celldefine
module aoi22d4 (A1, A2, B1, B2, ZN);
input A1, A2, B1, B2;
output ZN;
wire g_1_out, g_2_out;
   and and0 (g_1_out, A2, A1);
   and and1 (g_2_out, B2, B1);
   nor nor2 (ZN, g_1_out, g_2_out);
endmodule
`endcelldefine

`celldefine
module aoi31d1 (B1, B2, B3, A, ZN);
input B1, B2, B3, A;
output ZN;
wire g_1_out;
   and and0 (g_1_out, B2, B1, B3);
   nor nor1 (ZN, g_1_out, A);
endmodule
`endcelldefine

`celldefine
module aoi31d2 (B1, B2, B3, A, ZN);
input B1, B2, B3, A;
output ZN;
wire g_1_out;
   and and0 (g_1_out, B2, B1, B3);
   nor nor1 (ZN, g_1_out, A);
endmodule
`endcelldefine

`celldefine
module aoi31d4 (B1, B2, B3, A, ZN);
input B1, B2, B3, A;
output ZN;
wire g_1_out;
   and and0 (g_1_out, B2, B1, B3);
   nor nor1 (ZN, g_1_out, A);
endmodule
`endcelldefine

`celldefine
module bufbd2 (I, Z);
input I;
output Z;
   buf buf0 (Z, I);
endmodule
`endcelldefine

`celldefine
module bufbd4 (I, Z);
input I;
output Z;
   buf buf0 (Z, I);
endmodule
`endcelldefine

`celldefine
module bufbdf (I, Z);
input I;
output Z;
   buf buf0 (Z, I);
endmodule
`endcelldefine

`celldefine
module bufbdk (I, Z);
input I;
output Z;
   buf buf0 (Z, I);
endmodule
`endcelldefine

`celldefine
module buffd2 (I, Z);
input I;
output Z;
   buf buf0 (Z, I);
endmodule
`endcelldefine

`celldefine
module buffd4 (I, Z);
input I;
output Z;
   buf buf0 (Z, I);
endmodule
`endcelldefine

`celldefine
module bufbd1 (I, Z);
input I;
output Z;
   buf buf0 (Z, I);
endmodule
`endcelldefine

`celldefine
module bufbd3 (I, Z);
input I;
output Z;
   buf buf0 (Z, I);
endmodule
`endcelldefine

`celldefine
module bufbd7 (I, Z);
input I;
output Z;
   buf buf0 (Z, I);
endmodule
`endcelldefine

`celldefine
module bufbda (I, Z);
input I;
output Z;
   buf buf0 (Z, I);
endmodule
`endcelldefine

`celldefine
module buffd1 (I, Z);
input I;
output Z;
   buf buf0 (Z, I);
endmodule
`endcelldefine

`celldefine
module buffd3 (I, Z);
input I;
output Z;
   buf buf0 (Z, I);
endmodule
`endcelldefine

`celldefine
module buffd7 (I, Z);
input I;
output Z;
   buf buf0 (Z, I);
endmodule
`endcelldefine

`celldefine
module buffda (I, Z);
input I;
output Z;
   buf buf0 (Z, I);
endmodule
`endcelldefine

`celldefine
module buftd1 (EN, I, Z);
input EN, I;
output Z;
   bufif0 bufif00 (Z, I, EN);
endmodule
`endcelldefine

`celldefine
module buftd2 (EN, I, Z);
input EN, I;
output Z;
   bufif0 bufif00 (Z, I, EN);
endmodule
`endcelldefine

`celldefine
module buftd4 (EN, I, Z);
input EN, I;
output Z;
   bufif0 bufif00 (Z, I, EN);
endmodule
`endcelldefine

`celldefine
module buftd7 (EN, I, Z);
input EN, I;
output Z;
   bufif0 bufif00 (Z, I, EN);
endmodule
`endcelldefine

`celldefine
module buftda (EN, I, Z);
input EN, I;
output Z;
   bufif0 bufif00 (Z, I, EN);
endmodule
`endcelldefine

`celldefine
module s_mffnrb2 (Q, CP, ENN, D, notifier);
input CP, ENN, D, notifier;
output Q;
wire _mux1;
   _DFF _dff0 (1'b0, 1'b0, CP, _mux1, Q);
   _MUX _mux1 (ENN, D, Q, _mux1);
endmodule
`endcelldefine

`celldefine
module mffnrb2 (CP, D, ENN, Q, QN);
input CP, D, ENN;
output Q, QN;
wire CP_buf, D_buf, ENN_buf, BOOL_OUT, _and4, _and6, _and5, _or7, _and9,
       _and8, _or10, _or11, _and3, notifier, buf_Q;
reg notifier;
   buf buf0 (CP_buf, CP);
   buf buf1 (D_buf, D);
   buf buf2 (ENN_buf, ENN);
   and _and3 (_and3, D_buf, !ENN_buf, !_and4, _or7);
   and _and4 (_and4, !D_buf, !ENN_buf);
   and _and5 (_and5, D_buf, !ENN_buf);
   and _and6 (_and6, !D_buf, !ENN_buf);
   or _or7 (_or7, _and5, _and6);
   and _and8 (_and8, D_buf, !ENN_buf);
   and _and9 (_and9, !D_buf, !ENN_buf);
   or _or10 (_or10, _and8, _and9);
   or _or11 (_or11, !Q, _or10);
   or _or12 (BOOL_OUT, _and3, !_or11);
   s_mffnrb2 s_mffnrb213 (buf_Q, CP, ENN, D, notifier);
   buf buf14 (Q, buf_Q);
   not not15 (QN, buf_Q);
endmodule
`endcelldefine

`celldefine
module s_mffnrb1 (Q, CP, ENN, D, notifier);
input CP, ENN, D, notifier;
output Q;
wire _mux1;
   _DFF _dff0 (1'b0, 1'b0, CP, _mux1, Q);
   _MUX _mux1 (ENN, D, Q, _mux1);
endmodule
`endcelldefine

`celldefine
module mffnrb1 (CP, D, ENN, Q, QN);
input CP, D, ENN;
output Q, QN;
wire CP_buf, D_buf, ENN_buf, BOOL_OUT, _and4, _and6, _and5, _or7, _and9,
       _and8, _or10, _or11, _and3, notifier, buf_Q;
reg notifier;
   buf buf0 (CP_buf, CP);
   buf buf1 (D_buf, D);
   buf buf2 (ENN_buf, ENN);
   and _and3 (_and3, D_buf, !ENN_buf, !_and4, _or7);
   and _and4 (_and4, !D_buf, !ENN_buf);
   and _and5 (_and5, D_buf, !ENN_buf);
   and _and6 (_and6, !D_buf, !ENN_buf);
   or _or7 (_or7, _and5, _and6);
   and _and8 (_and8, D_buf, !ENN_buf);
   and _and9 (_and9, !D_buf, !ENN_buf);
   or _or10 (_or10, _and8, _and9);
   or _or11 (_or11, !Q, _or10);
   or _or12 (BOOL_OUT, _and3, !_or11);
   s_mffnrb1 s_mffnrb113 (buf_Q, CP, ENN, D, notifier);
   buf buf14 (Q, buf_Q);
   not not15 (QN, buf_Q);
endmodule
`endcelldefine

`celldefine
module s_mffnrb4 (Q, CP, ENN, D, notifier);
input CP, ENN, D, notifier;
output Q;
wire _mux1;
   _DFF _dff0 (1'b0, 1'b0, CP, _mux1, Q);
   _MUX _mux1 (ENN, D, Q, _mux1);
endmodule
`endcelldefine

`celldefine
module mffnrb4 (CP, D, ENN, Q, QN);
input CP, D, ENN;
output Q, QN;
wire CP_buf, D_buf, ENN_buf, BOOL_OUT, _and4, _and6, _and5, _or7, _and9,
       _and8, _or10, _or11, _and3, notifier, buf_Q;
reg notifier;
   buf buf0 (CP_buf, CP);
   buf buf1 (D_buf, D);
   buf buf2 (ENN_buf, ENN);
   and _and3 (_and3, D_buf, !ENN_buf, !_and4, _or7);
   and _and4 (_and4, !D_buf, !ENN_buf);
   and _and5 (_and5, D_buf, !ENN_buf);
   and _and6 (_and6, !D_buf, !ENN_buf);
   or _or7 (_or7, _and5, _and6);
   and _and8 (_and8, D_buf, !ENN_buf);
   and _and9 (_and9, !D_buf, !ENN_buf);
   or _or10 (_or10, _and8, _and9);
   or _or11 (_or11, !Q, _or10);
   or _or12 (BOOL_OUT, _and3, !_or11);
   s_mffnrb4 s_mffnrb413 (buf_Q, CP, ENN, D, notifier);
   buf buf14 (Q, buf_Q);
   not not15 (QN, buf_Q);
endmodule
`endcelldefine

`celldefine
module s_secrq2 (Q, CP, ENN, SC, CDN, D, SD, notifier);
input CP, ENN, SC, CDN, D, SD, notifier;
output Q;
wire _mux1, _mux2;
   _DFF _dff0 (1'b0, !CDN, CP, _mux2, Q);
   _MUX _mux1 (ENN, !D, !Q, _mux1);
   _MUX _mux2 (SC, !_mux1, SD, _mux2);
endmodule
`endcelldefine

`celldefine
module secrq2 (CP, CDN, ENN, D, SC, SD, Q);
input CP, CDN, ENN, D, SC, SD;
output Q;
wire notifier, CDN_buf, SC_buf, ENN_buf, vcond1, vcond_CDN_vio, vcond_ENN_vio,
       vcond_D_vio, vcond2;
reg notifier;
   s_secrq2 s_secrq20 (Q, CP, ENN, SC, CDN, D, SD, notifier);
   buf buf1 (CDN_buf, CDN);
   buf buf2 (SC_buf, SC);
   buf buf3 (ENN_buf, ENN);
   and _and4 (vcond1, CDN_buf, SC_buf);
   or _or5 (vcond_CDN_vio, ENN_buf, SC_buf);
   and _and6 (vcond_ENN_vio, CDN_buf, SC_buf);
   and _and7 (vcond_D_vio, CDN_buf, SC_buf, ENN_buf);
   and _and8 (vcond2, CDN_buf, SC_buf);
endmodule
`endcelldefine

`celldefine
module s_secrq1 (Q, CP, ENN, SC, CDN, D, SD, notifier);
input CP, ENN, SC, CDN, D, SD, notifier;
output Q;
wire _mux1, _mux2;
   _DFF _dff0 (1'b0, !CDN, CP, _mux2, Q);
   _MUX _mux1 (ENN, !D, !Q, _mux1);
   _MUX _mux2 (SC, !_mux1, SD, _mux2);
endmodule
`endcelldefine

`celldefine
module secrq1 (CP, CDN, ENN, D, SC, SD, Q);
input CP, CDN, ENN, D, SC, SD;
output Q;
wire notifier, CDN_buf, SC_buf, ENN_buf, vcond1, vcond_CDN_vio, vcond_ENN_vio,
       vcond_D_vio, vcond2;
reg notifier;
   s_secrq1 s_secrq10 (Q, CP, ENN, SC, CDN, D, SD, notifier);
   buf buf1 (CDN_buf, CDN);
   buf buf2 (SC_buf, SC);
   buf buf3 (ENN_buf, ENN);
   and _and4 (vcond1, CDN_buf, SC_buf);
   or _or5 (vcond_CDN_vio, ENN_buf, SC_buf);
   and _and6 (vcond_ENN_vio, CDN_buf, SC_buf);
   and _and7 (vcond_D_vio, CDN_buf, SC_buf, ENN_buf);
   and _and8 (vcond2, CDN_buf, SC_buf);
endmodule
`endcelldefine

`celldefine
module U_FD_P_RB_NO (Q, D, CP, RB, NOTIFIER_REG);
input D, CP, RB, NOTIFIER_REG;
output Q;
   _DFF _dff0 (1'b0, !RB, CP, D, Q);
endmodule
`endcelldefine

`celldefine
module sdcrq2 (CP, CDN, D, SC, SD, Q);
input CP, CDN, D, SC, SD;
output Q;
wire notifier, mux_out, CDN_buf, SC_buf, vcond1, vcond2;
reg notifier;
   U_FD_P_RB_NO U_FD_P_RB_NO0 (Q, mux_out, CP, CDN, notifier);
   U_MUX_2_1 U_MUX_2_11 (mux_out, D, SD, SC);
   buf buf2 (CDN_buf, CDN);
   buf buf3 (SC_buf, SC);
   and _and4 (vcond1, CDN_buf, SC_buf);
   and _and5 (vcond2, CDN_buf, SC_buf);
endmodule
`endcelldefine

`celldefine
module sdcrq1 (CP, CDN, D, SC, SD, Q);
input CP, CDN, D, SC, SD;
output Q;
wire notifier, mux_out, CDN_buf, SC_buf, vcond1, vcond2;
reg notifier;
   U_FD_P_RB_NO U_FD_P_RB_NO0 (Q, mux_out, CP, CDN, notifier);
   U_MUX_2_1 U_MUX_2_11 (mux_out, D, SD, SC);
   buf buf2 (CDN_buf, CDN);
   buf buf3 (SC_buf, SC);
   and _and4 (vcond1, CDN_buf, SC_buf);
   and _and5 (vcond2, CDN_buf, SC_buf);
endmodule
`endcelldefine

`celldefine
module s_sdcrn (QN, CP, SC, CDN, SD, D, notifier);
input CP, SC, CDN, SD, D, notifier;
output QN;
wire _mux1;
   _DFF _dff0 (!CDN, 1'b0, CP, _mux1, QN);
   _MUX _mux1 (SC, !D, !SD, _mux1);
endmodule
`endcelldefine

`celldefine
module sdcrn2 (CP, CDN, D, SC, SD, QN);
input CP, CDN, D, SC, SD;
output QN;
wire notifier, CDN_buf, SC_buf, vcond1, vcond2;
reg notifier;
   s_sdcrn s_sdcrn0 (QN, CP, SC, CDN, SD, D, notifier);
   buf buf1 (CDN_buf, CDN);
   buf buf2 (SC_buf, SC);
   and _and3 (vcond1, CDN_buf, SC_buf);
   and _and4 (vcond2, CDN_buf, SC_buf);
endmodule
`endcelldefine

`celldefine
module sdcrn1 (CP, CDN, D, SC, SD, QN);
input CP, CDN, D, SC, SD;
output QN;
wire notifier, CDN_buf, SC_buf, vcond1, vcond2;
reg notifier;
   s_sdcrn s_sdcrn0 (QN, CP, SC, CDN, SD, D, notifier);
   buf buf1 (CDN_buf, CDN);
   buf buf2 (SC_buf, SC);
   and _and3 (vcond1, CDN_buf, SC_buf);
   and _and4 (vcond2, CDN_buf, SC_buf);
endmodule
`endcelldefine

`celldefine
module sdcrb2 (D, SD, SC, CP, CDN, Q, QN);
input D, SD, SC, CP, CDN;
output Q, QN;
wire notifier, buf_Q, mux_out, SC_buf, CDN_buf, vcond1, vcond2;
reg notifier;
   U_FD_P_RB_NO U_FD_P_RB_NO0 (buf_Q, mux_out, CP, CDN, notifier);
   U_MUX_2_1 U_MUX_2_11 (mux_out, D, SD, SC);
   buf buf2 (Q, buf_Q);
   not not3 (QN, buf_Q);
   buf buf4 (SC_buf, SC);
   buf buf5 (CDN_buf, CDN);
   and _and6 (vcond1, SC_buf, CDN_buf);
   and _and7 (vcond2, SC_buf, CDN_buf);
endmodule
`endcelldefine

`celldefine
module sdcrb1 (D, SD, SC, CP, CDN, Q, QN);
input D, SD, SC, CP, CDN;
output Q, QN;
wire notifier, buf_Q, mux_out, SC_buf, CDN_buf, vcond1, vcond2;
reg notifier;
   U_FD_P_RB_NO U_FD_P_RB_NO0 (buf_Q, mux_out, CP, CDN, notifier);
   U_MUX_2_1 U_MUX_2_11 (mux_out, D, SD, SC);
   buf buf2 (Q, buf_Q);
   not not3 (QN, buf_Q);
   buf buf4 (SC_buf, SC);
   buf buf5 (CDN_buf, CDN);
   and _and6 (vcond1, SC_buf, CDN_buf);
   and _and7 (vcond2, SC_buf, CDN_buf);
endmodule
`endcelldefine

`celldefine
module U_FD_N_RB_NO (Q, D, CP, RB, NOTIFIER_REG);
input D, CP, RB, NOTIFIER_REG;
output Q;
   _DFF _dff0 (1'b0, !RB, !CP, D, Q);
endmodule
`endcelldefine

`celldefine
module sdcfq2 (CPN, CDN, D, SC, SD, Q);
input CPN, CDN, D, SC, SD;
output Q;
wire notifier, mux_out, CDN_buf, SC_buf, vcond1, vcond2;
reg notifier;
   U_FD_N_RB_NO U_FD_N_RB_NO0 (Q, mux_out, CPN, CDN, notifier);
   U_MUX_2_1 U_MUX_2_11 (mux_out, D, SD, SC);
   buf buf2 (CDN_buf, CDN);
   buf buf3 (SC_buf, SC);
   and _and4 (vcond1, CDN_buf, SC_buf);
   and _and5 (vcond2, CDN_buf, SC_buf);
endmodule
`endcelldefine

`celldefine
module sdcfq1 (CPN, CDN, D, SC, SD, Q);
input CPN, CDN, D, SC, SD;
output Q;
wire notifier, mux_out, CDN_buf, SC_buf, vcond1, vcond2;
reg notifier;
   U_FD_N_RB_NO U_FD_N_RB_NO0 (Q, mux_out, CPN, CDN, notifier);
   U_MUX_2_1 U_MUX_2_11 (mux_out, D, SD, SC);
   buf buf2 (CDN_buf, CDN);
   buf buf3 (SC_buf, SC);
   and _and4 (vcond1, CDN_buf, SC_buf);
   and _and5 (vcond2, CDN_buf, SC_buf);
endmodule
`endcelldefine

`celldefine
module U_LD_P_RB_NO (Q, D, G, RB, NOTI_REG);
input D, G, RB, NOTI_REG;
output Q;
wire _and1;
   _DLAT _dlat0 (1'b0, !RB, _and1, D, Q);
   _AND _and1 (RB, G, _and1);
endmodule
`endcelldefine

`celldefine
module laclq2 (EN, D, CDN, Q);
input EN, D, CDN;
output Q;
wire notifier, not_EN;
reg notifier;
   U_LD_P_RB_NO U_LD_P_RB_NO0 (Q, D, not_EN, CDN, notifier);
   not not1 (not_EN, EN);
endmodule
`endcelldefine

`celldefine
module laclq1 (EN, D, CDN, Q);
input EN, D, CDN;
output Q;
wire notifier, not_EN;
reg notifier;
   U_LD_P_RB_NO U_LD_P_RB_NO0 (Q, D, not_EN, CDN, notifier);
   not not1 (not_EN, EN);
endmodule
`endcelldefine

`celldefine
module lachq2 (E, D, CDN, Q);
input E, D, CDN;
output Q;
wire notifier;
reg notifier;
   U_LD_P_RB_NO U_LD_P_RB_NO0 (Q, D, E, CDN, notifier);
endmodule
`endcelldefine

`celldefine
module lachq1 (E, D, CDN, Q);
input E, D, CDN;
output Q;
wire notifier;
reg notifier;
   U_LD_P_RB_NO U_LD_P_RB_NO0 (Q, D, E, CDN, notifier);
endmodule
`endcelldefine

`celldefine
module dfcrq2 (D, CP, CDN, Q);
input D, CP, CDN;
output Q;
wire notifier;
reg notifier;
   U_FD_P_RB_NO U_FD_P_RB_NO0 (Q, D, CP, CDN, notifier);
endmodule
`endcelldefine

`celldefine
module dfcrq1 (D, CP, CDN, Q);
input D, CP, CDN;
output Q;
wire notifier;
reg notifier;
   U_FD_P_RB_NO U_FD_P_RB_NO0 (Q, D, CP, CDN, notifier);
endmodule
`endcelldefine

`celldefine
module s_dfcrn2 (QN, CP, CDN, D, notifier);
input CP, CDN, D, notifier;
output QN;
   _DFF _dff0 (!CDN, 1'b0, CP, !D, QN);
endmodule
`endcelldefine

`celldefine
module dfcrn2 (D, CP, CDN, QN);
input D, CP, CDN;
output QN;
wire notifier;
reg notifier;
   s_dfcrn2 s_dfcrn20 (QN, CP, CDN, D, notifier);
endmodule
`endcelldefine

`celldefine
module s_dfcrn1 (QN, CP, CDN, D, notifier);
input CP, CDN, D, notifier;
output QN;
   _DFF _dff0 (!CDN, 1'b0, CP, !D, QN);
endmodule
`endcelldefine

`celldefine
module dfcrn1 (D, CP, CDN, QN);
input D, CP, CDN;
output QN;
wire notifier;
reg notifier;
   s_dfcrn1 s_dfcrn10 (QN, CP, CDN, D, notifier);
endmodule
`endcelldefine

`celldefine
module dfcrb2 (D, CP, CDN, Q, QN);
input D, CP, CDN;
output Q, QN;
wire notifier, buf_Q;
reg notifier;
   U_FD_P_RB_NO U_FD_P_RB_NO0 (buf_Q, D, CP, CDN, notifier);
   buf buf1 (Q, buf_Q);
   not not2 (QN, buf_Q);
endmodule
`endcelldefine

`celldefine
module dfcrb1 (D, CP, CDN, Q, QN);
input D, CP, CDN;
output Q, QN;
wire notifier, buf_Q;
reg notifier;
   U_FD_P_RB_NO U_FD_P_RB_NO0 (buf_Q, D, CP, CDN, notifier);
   buf buf1 (Q, buf_Q);
   not not2 (QN, buf_Q);
endmodule
`endcelldefine

`celldefine
module dfcfq2 (D, CPN, CDN, Q);
input D, CPN, CDN;
output Q;
wire notifier;
reg notifier;
   U_FD_N_RB_NO U_FD_N_RB_NO0 (Q, D, CPN, CDN, notifier);
endmodule
`endcelldefine

`celldefine
module dfcfq1 (D, CPN, CDN, Q);
input D, CPN, CDN;
output Q;
wire notifier;
reg notifier;
   U_FD_N_RB_NO U_FD_N_RB_NO0 (Q, D, CPN, CDN, notifier);
endmodule
`endcelldefine

`celldefine
module dfcfb2 (D, CPN, CDN, Q, QN);
input D, CPN, CDN;
output Q, QN;
wire notifier, buf_Q;
reg notifier;
   U_FD_N_RB_NO U_FD_N_RB_NO0 (buf_Q, D, CPN, CDN, notifier);
   buf buf1 (Q, buf_Q);
   not not2 (QN, buf_Q);
endmodule
`endcelldefine

`celldefine
module dfcfb1 (D, CPN, CDN, Q, QN);
input D, CPN, CDN;
output Q, QN;
wire notifier, buf_Q;
reg notifier;
   U_FD_N_RB_NO U_FD_N_RB_NO0 (buf_Q, D, CPN, CDN, notifier);
   buf buf1 (Q, buf_Q);
   not not2 (QN, buf_Q);
endmodule
`endcelldefine

`celldefine
module s_decrq2 (Q, CP, ENN, CDN, D, notifier);
input CP, ENN, CDN, D, notifier;
output Q;
wire _mux1;
   _DFF _dff0 (1'b0, !CDN, CP, _mux1, Q);
   _MUX _mux1 (ENN, D, Q, _mux1);
endmodule
`endcelldefine

`celldefine
module decrq2 (CP, CDN, D, ENN, Q);
input CP, CDN, D, ENN;
output Q;
wire CP_buf, CDN_buf, D_buf, ENN_buf, BOOL_OUT, _or5, _and4, notifier,
       vcond1;
reg notifier;
   buf buf0 (CP_buf, CP);
   buf buf1 (CDN_buf, CDN);
   buf buf2 (D_buf, D);
   buf buf3 (ENN_buf, ENN);
   and _and4 (_and4, !ENN_buf, D_buf, !ENN_buf);
   or _or5 (_or5, !Q, !ENN_buf);
   or _or6 (BOOL_OUT, _and4, !_or5);
   s_decrq2 s_decrq27 (Q, CP, ENN, CDN, D, notifier);
   and _and8 (vcond1, CDN_buf, ENN_buf);
endmodule
`endcelldefine

`celldefine
module s_decrq1 (Q, CP, ENN, CDN, D, notifier);
input CP, ENN, CDN, D, notifier;
output Q;
wire _mux1;
   _DFF _dff0 (1'b0, !CDN, CP, _mux1, Q);
   _MUX _mux1 (ENN, D, Q, _mux1);
endmodule
`endcelldefine

`celldefine
module decrq1 (CP, CDN, D, ENN, Q);
input CP, CDN, D, ENN;
output Q;
wire CP_buf, CDN_buf, D_buf, ENN_buf, BOOL_OUT, _or5, _and4, notifier,
       vcond1;
reg notifier;
   buf buf0 (CP_buf, CP);
   buf buf1 (CDN_buf, CDN);
   buf buf2 (D_buf, D);
   buf buf3 (ENN_buf, ENN);
   and _and4 (_and4, !ENN_buf, D_buf, !ENN_buf);
   or _or5 (_or5, !Q, !ENN_buf);
   or _or6 (BOOL_OUT, _and4, !_or5);
   s_decrq1 s_decrq17 (Q, CP, ENN, CDN, D, notifier);
   and _and8 (vcond1, CDN_buf, ENN_buf);
endmodule
`endcelldefine

`celldefine
module slchq4 (E, D, SD, SC, CDN, Q, SO);
input E, D, SD, SC, CDN;
output Q, SO;
wire notifier, mux_out, SC_buf, CDN_buf, vcond1, vcond2;
reg notifier;
   U_MUX_2_1 U_MUX_2_10 (mux_out, D, SD, SC);
   U_LD_P_RB_NO U_LD_P_RB_NO1 (Q, mux_out, E, CDN, notifier);
   U_LD_N_NO U_LD_N_NO2 (SO, Q, E, notifier);
   buf buf3 (SC_buf, SC);
   buf buf4 (CDN_buf, CDN);
   and _and5 (vcond1, SC_buf, CDN_buf);
   and _and6 (vcond2, SC_buf, CDN_buf);
endmodule
`endcelldefine

`celldefine
module slchq2 (E, D, SD, SC, CDN, Q, SO);
input E, D, SD, SC, CDN;
output Q, SO;
wire notifier, mux_out, SC_buf, CDN_buf, vcond1, vcond2;
reg notifier;
   U_MUX_2_1 U_MUX_2_10 (mux_out, D, SD, SC);
   U_LD_P_RB_NO U_LD_P_RB_NO1 (Q, mux_out, E, CDN, notifier);
   U_LD_N_NO U_LD_N_NO2 (SO, Q, E, notifier);
   buf buf3 (SC_buf, SC);
   buf buf4 (CDN_buf, CDN);
   and _and5 (vcond1, SC_buf, CDN_buf);
   and _and6 (vcond2, SC_buf, CDN_buf);
endmodule
`endcelldefine

`celldefine
module slchq1 (E, D, SD, SC, CDN, Q, SO);
input E, D, SD, SC, CDN;
output Q, SO;
wire notifier, mux_out, SC_buf, CDN_buf, vcond1, vcond2;
reg notifier;
   U_MUX_2_1 U_MUX_2_10 (mux_out, D, SD, SC);
   U_LD_P_RB_NO U_LD_P_RB_NO1 (Q, mux_out, E, CDN, notifier);
   U_LD_N_NO U_LD_N_NO2 (SO, Q, E, notifier);
   buf buf3 (SC_buf, SC);
   buf buf4 (CDN_buf, CDN);
   and _and5 (vcond1, SC_buf, CDN_buf);
   and _and6 (vcond2, SC_buf, CDN_buf);
endmodule
`endcelldefine

`celldefine
module s_secrq4 (Q, CP, ENN, SC, CDN, D, SD, notifier);
input CP, ENN, SC, CDN, D, SD, notifier;
output Q;
wire _mux1, _mux2;
   _DFF _dff0 (1'b0, !CDN, CP, _mux2, Q);
   _MUX _mux1 (ENN, !D, !Q, _mux1);
   _MUX _mux2 (SC, !_mux1, SD, _mux2);
endmodule
`endcelldefine

`celldefine
module secrq4 (CP, CDN, ENN, D, SC, SD, Q);
input CP, CDN, ENN, D, SC, SD;
output Q;
wire notifier, CDN_buf, SC_buf, ENN_buf, vcond1, vcond_CDN_vio, vcond_ENN_vio,
       vcond_D_vio, vcond2;
reg notifier;
   s_secrq4 s_secrq40 (Q, CP, ENN, SC, CDN, D, SD, notifier);
   buf buf1 (CDN_buf, CDN);
   buf buf2 (SC_buf, SC);
   buf buf3 (ENN_buf, ENN);
   and _and4 (vcond1, CDN_buf, SC_buf);
   or _or5 (vcond_CDN_vio, ENN_buf, SC_buf);
   and _and6 (vcond_ENN_vio, CDN_buf, SC_buf);
   and _and7 (vcond_D_vio, CDN_buf, SC_buf, ENN_buf);
   and _and8 (vcond2, CDN_buf, SC_buf);
endmodule
`endcelldefine

`celldefine
module s_secfq4 (Q, CPN, ENN, SC, CDN, D, SD, notifier);
input CPN, ENN, SC, CDN, D, SD, notifier;
output Q;
wire _mux1, _mux2;
   _DFF _dff0 (1'b0, !CDN, !CPN, _mux2, Q);
   _MUX _mux1 (ENN, !D, !Q, _mux1);
   _MUX _mux2 (SC, !_mux1, SD, _mux2);
endmodule
`endcelldefine

`celldefine
module secfq4 (CPN, CDN, ENN, D, SC, SD, Q);
input CPN, CDN, ENN, D, SC, SD;
output Q;
wire notifier, CDN_buf, SC_buf, ENN_buf, vcond1, vcond_CDN_vio, vcond_ENN_vio,
       vcond_D_vio, vcond2;
reg notifier;
   s_secfq4 s_secfq40 (Q, CPN, ENN, SC, CDN, D, SD, notifier);
   buf buf1 (CDN_buf, CDN);
   buf buf2 (SC_buf, SC);
   buf buf3 (ENN_buf, ENN);
   and _and4 (vcond1, CDN_buf, SC_buf);
   or _or5 (vcond_CDN_vio, ENN_buf, SC_buf);
   and _and6 (vcond_ENN_vio, CDN_buf, SC_buf);
   and _and7 (vcond_D_vio, CDN_buf, SC_buf, ENN_buf);
   and _and8 (vcond2, CDN_buf, SC_buf);
endmodule
`endcelldefine

`celldefine
module s_secfq2 (Q, CPN, ENN, SC, CDN, D, SD, notifier);
input CPN, ENN, SC, CDN, D, SD, notifier;
output Q;
wire _mux1, _mux2;
   _DFF _dff0 (1'b0, !CDN, !CPN, _mux2, Q);
   _MUX _mux1 (ENN, !D, !Q, _mux1);
   _MUX _mux2 (SC, !_mux1, SD, _mux2);
endmodule
`endcelldefine

`celldefine
module secfq2 (CPN, CDN, ENN, D, SC, SD, Q);
input CPN, CDN, ENN, D, SC, SD;
output Q;
wire notifier, CDN_buf, SC_buf, ENN_buf, vcond1, vcond_CDN_vio, vcond_ENN_vio,
       vcond_D_vio, vcond2;
reg notifier;
   s_secfq2 s_secfq20 (Q, CPN, ENN, SC, CDN, D, SD, notifier);
   buf buf1 (CDN_buf, CDN);
   buf buf2 (SC_buf, SC);
   buf buf3 (ENN_buf, ENN);
   and _and4 (vcond1, CDN_buf, SC_buf);
   or _or5 (vcond_CDN_vio, ENN_buf, SC_buf);
   and _and6 (vcond_ENN_vio, CDN_buf, SC_buf);
   and _and7 (vcond_D_vio, CDN_buf, SC_buf, ENN_buf);
   and _and8 (vcond2, CDN_buf, SC_buf);
endmodule
`endcelldefine

`celldefine
module s_secfq1 (Q, CPN, ENN, SC, CDN, D, SD, notifier);
input CPN, ENN, SC, CDN, D, SD, notifier;
output Q;
wire _mux1, _mux2;
   _DFF _dff0 (1'b0, !CDN, !CPN, _mux2, Q);
   _MUX _mux1 (ENN, !D, !Q, _mux1);
   _MUX _mux2 (SC, !_mux1, SD, _mux2);
endmodule
`endcelldefine

`celldefine
module secfq1 (CPN, CDN, ENN, D, SC, SD, Q);
input CPN, CDN, ENN, D, SC, SD;
output Q;
wire notifier, CDN_buf, SC_buf, ENN_buf, vcond1, vcond_CDN_vio, vcond_ENN_vio,
       vcond_D_vio, vcond2;
reg notifier;
   s_secfq1 s_secfq10 (Q, CPN, ENN, SC, CDN, D, SD, notifier);
   buf buf1 (CDN_buf, CDN);
   buf buf2 (SC_buf, SC);
   buf buf3 (ENN_buf, ENN);
   and _and4 (vcond1, CDN_buf, SC_buf);
   or _or5 (vcond_CDN_vio, ENN_buf, SC_buf);
   and _and6 (vcond_ENN_vio, CDN_buf, SC_buf);
   and _and7 (vcond_D_vio, CDN_buf, SC_buf, ENN_buf);
   and _and8 (vcond2, CDN_buf, SC_buf);
endmodule
`endcelldefine

`celldefine
module sdcrq4 (CP, CDN, D, SC, SD, Q);
input CP, CDN, D, SC, SD;
output Q;
wire notifier, mux_out, CDN_buf, SC_buf, vcond1, vcond2;
reg notifier;
   U_FD_P_RB_NO U_FD_P_RB_NO0 (Q, mux_out, CP, CDN, notifier);
   U_MUX_2_1 U_MUX_2_11 (mux_out, D, SD, SC);
   buf buf2 (CDN_buf, CDN);
   buf buf3 (SC_buf, SC);
   and _and4 (vcond1, CDN_buf, SC_buf);
   and _and5 (vcond2, CDN_buf, SC_buf);
endmodule
`endcelldefine

`celldefine
module sdcrn4 (CP, CDN, D, SC, SD, QN);
input CP, CDN, D, SC, SD;
output QN;
wire notifier, CDN_buf, SC_buf, vcond1, vcond2;
reg notifier;
   s_sdcrn s_sdcrn0 (QN, CP, SC, CDN, SD, D, notifier);
   buf buf1 (CDN_buf, CDN);
   buf buf2 (SC_buf, SC);
   and _and3 (vcond1, CDN_buf, SC_buf);
   and _and4 (vcond2, CDN_buf, SC_buf);
endmodule
`endcelldefine

`celldefine
module sdcrb4 (D, SD, SC, CP, CDN, Q, QN);
input D, SD, SC, CP, CDN;
output Q, QN;
wire notifier, buf_Q, mux_out, SC_buf, CDN_buf, vcond1, vcond2;
reg notifier;
   U_FD_P_RB_NO U_FD_P_RB_NO0 (buf_Q, mux_out, CP, CDN, notifier);
   U_MUX_2_1 U_MUX_2_11 (mux_out, D, SD, SC);
   buf buf2 (Q, buf_Q);
   not not3 (QN, buf_Q);
   buf buf4 (SC_buf, SC);
   buf buf5 (CDN_buf, CDN);
   and _and6 (vcond1, SC_buf, CDN_buf);
   and _and7 (vcond2, SC_buf, CDN_buf);
endmodule
`endcelldefine

`celldefine
module sdcfq4 (CPN, CDN, D, SC, SD, Q);
input CPN, CDN, D, SC, SD;
output Q;
wire notifier, mux_out, CDN_buf, SC_buf, vcond1, vcond2;
reg notifier;
   U_FD_N_RB_NO U_FD_N_RB_NO0 (Q, mux_out, CPN, CDN, notifier);
   U_MUX_2_1 U_MUX_2_11 (mux_out, D, SD, SC);
   buf buf2 (CDN_buf, CDN);
   buf buf3 (SC_buf, SC);
   and _and4 (vcond1, CDN_buf, SC_buf);
   and _and5 (vcond2, CDN_buf, SC_buf);
endmodule
`endcelldefine

`celldefine
module sdcfb4 (D, SD, SC, CPN, CDN, Q, QN);
input D, SD, SC, CPN, CDN;
output Q, QN;
wire notifier, buf_Q, mux_out, SC_buf, CDN_buf, vcond1, vcond2;
reg notifier;
   U_FD_N_RB_NO U_FD_N_RB_NO0 (buf_Q, mux_out, CPN, CDN, notifier);
   U_MUX_2_1 U_MUX_2_11 (mux_out, D, SD, SC);
   buf buf2 (Q, buf_Q);
   not not3 (QN, buf_Q);
   buf buf4 (SC_buf, SC);
   buf buf5 (CDN_buf, CDN);
   and _and6 (vcond1, SC_buf, CDN_buf);
   and _and7 (vcond2, SC_buf, CDN_buf);
endmodule
`endcelldefine

`celldefine
module sdcfb2 (D, SD, SC, CPN, CDN, Q, QN);
input D, SD, SC, CPN, CDN;
output Q, QN;
wire notifier, buf_Q, mux_out, SC_buf, CDN_buf, vcond1, vcond2;
reg notifier;
   U_FD_N_RB_NO U_FD_N_RB_NO0 (buf_Q, mux_out, CPN, CDN, notifier);
   U_MUX_2_1 U_MUX_2_11 (mux_out, D, SD, SC);
   buf buf2 (Q, buf_Q);
   not not3 (QN, buf_Q);
   buf buf4 (SC_buf, SC);
   buf buf5 (CDN_buf, CDN);
   and _and6 (vcond1, SC_buf, CDN_buf);
   and _and7 (vcond2, SC_buf, CDN_buf);
endmodule
`endcelldefine

`celldefine
module sdcfb1 (D, SD, SC, CPN, CDN, Q, QN);
input D, SD, SC, CPN, CDN;
output Q, QN;
wire notifier, buf_Q, mux_out, SC_buf, CDN_buf, vcond1, vcond2;
reg notifier;
   U_FD_N_RB_NO U_FD_N_RB_NO0 (buf_Q, mux_out, CPN, CDN, notifier);
   U_MUX_2_1 U_MUX_2_11 (mux_out, D, SD, SC);
   buf buf2 (Q, buf_Q);
   not not3 (QN, buf_Q);
   buf buf4 (SC_buf, SC);
   buf buf5 (CDN_buf, CDN);
   and _and6 (vcond1, SC_buf, CDN_buf);
   and _and7 (vcond2, SC_buf, CDN_buf);
endmodule
`endcelldefine

`celldefine
module laclq4 (EN, D, CDN, Q);
input EN, D, CDN;
output Q;
wire notifier, not_EN;
reg notifier;
   U_LD_P_RB_NO U_LD_P_RB_NO0 (Q, D, not_EN, CDN, notifier);
   not not1 (not_EN, EN);
endmodule
`endcelldefine

`celldefine
module lachq4 (E, D, CDN, Q);
input E, D, CDN;
output Q;
wire notifier;
reg notifier;
   U_LD_P_RB_NO U_LD_P_RB_NO0 (Q, D, E, CDN, notifier);
endmodule
`endcelldefine

`celldefine
module s_decfq4 (Q, CPN, ENN, CDN, D, notifier);
input CPN, ENN, CDN, D, notifier;
output Q;
wire _mux1;
   _DFF _dff0 (1'b0, !CDN, !CPN, _mux1, Q);
   _MUX _mux1 (ENN, D, Q, _mux1);
endmodule
`endcelldefine

`celldefine
module decfq4 (CPN, CDN, D, ENN, Q);
input CPN, CDN, D, ENN;
output Q;
wire CPN_buf, CDN_buf, D_buf, ENN_buf, BOOL_OUT, _or5, _and4, notifier,
       vcond1;
reg notifier;
   buf buf0 (CPN_buf, CPN);
   buf buf1 (CDN_buf, CDN);
   buf buf2 (D_buf, D);
   buf buf3 (ENN_buf, ENN);
   and _and4 (_and4, !ENN_buf, D_buf, !ENN_buf);
   or _or5 (_or5, !Q, !ENN_buf);
   or _or6 (BOOL_OUT, _and4, !_or5);
   s_decfq4 s_decfq47 (Q, CPN, ENN, CDN, D, notifier);
   and _and8 (vcond1, CDN_buf, ENN_buf);
endmodule
`endcelldefine

`celldefine
module s_decrq4 (Q, CP, ENN, CDN, D, notifier);
input CP, ENN, CDN, D, notifier;
output Q;
wire _mux1;
   _DFF _dff0 (1'b0, !CDN, CP, _mux1, Q);
   _MUX _mux1 (ENN, D, Q, _mux1);
endmodule
`endcelldefine

`celldefine
module decrq4 (CP, CDN, D, ENN, Q);
input CP, CDN, D, ENN;
output Q;
wire CP_buf, CDN_buf, D_buf, ENN_buf, BOOL_OUT, _or5, _and4, notifier,
       vcond1;
reg notifier;
   buf buf0 (CP_buf, CP);
   buf buf1 (CDN_buf, CDN);
   buf buf2 (D_buf, D);
   buf buf3 (ENN_buf, ENN);
   and _and4 (_and4, !ENN_buf, D_buf, !ENN_buf);
   or _or5 (_or5, !Q, !ENN_buf);
   or _or6 (BOOL_OUT, _and4, !_or5);
   s_decrq4 s_decrq47 (Q, CP, ENN, CDN, D, notifier);
   and _and8 (vcond1, CDN_buf, ENN_buf);
endmodule
`endcelldefine

`celldefine
module dfcfb4 (D, CPN, CDN, Q, QN);
input D, CPN, CDN;
output Q, QN;
wire notifier, buf_Q;
reg notifier;
   U_FD_N_RB_NO U_FD_N_RB_NO0 (buf_Q, D, CPN, CDN, notifier);
   buf buf1 (Q, buf_Q);
   not not2 (QN, buf_Q);
endmodule
`endcelldefine

`celldefine
module dfcfq4 (D, CPN, CDN, Q);
input D, CPN, CDN;
output Q;
wire notifier;
reg notifier;
   U_FD_N_RB_NO U_FD_N_RB_NO0 (Q, D, CPN, CDN, notifier);
endmodule
`endcelldefine

`celldefine
module dfcrb4 (D, CP, CDN, Q, QN);
input D, CP, CDN;
output Q, QN;
wire notifier, buf_Q;
reg notifier;
   U_FD_P_RB_NO U_FD_P_RB_NO0 (buf_Q, D, CP, CDN, notifier);
   buf buf1 (Q, buf_Q);
   not not2 (QN, buf_Q);
endmodule
`endcelldefine

`celldefine
module s_dfcrn4 (QN, CP, CDN, D, notifier);
input CP, CDN, D, notifier;
output QN;
   _DFF _dff0 (!CDN, 1'b0, CP, !D, QN);
endmodule
`endcelldefine

`celldefine
module dfcrn4 (D, CP, CDN, QN);
input D, CP, CDN;
output QN;
wire notifier;
reg notifier;
   s_dfcrn4 s_dfcrn40 (QN, CP, CDN, D, notifier);
endmodule
`endcelldefine

`celldefine
module dfcrq4 (D, CP, CDN, Q);
input D, CP, CDN;
output Q;
wire notifier;
reg notifier;
   U_FD_P_RB_NO U_FD_P_RB_NO0 (Q, D, CP, CDN, notifier);
endmodule
`endcelldefine

`celldefine
module slclq1 (EN, D, SD, SC, CDN, Q, SO);
input EN, D, SD, SC, CDN;
output Q, SO;
wire notifier, not_EN, mux_out, SC_buf, CDN_buf, vcond1, vcond2;
reg notifier;
   not not0 (not_EN, EN);
   U_MUX_2_1 U_MUX_2_11 (mux_out, D, SD, SC);
   U_LD_P_RB_NO U_LD_P_RB_NO2 (Q, mux_out, not_EN, CDN, notifier);
   U_LD_P_NO U_LD_P_NO3 (SO, Q, EN, notifier);
   buf buf4 (SC_buf, SC);
   buf buf5 (CDN_buf, CDN);
   and _and6 (vcond1, SC_buf, CDN_buf);
   and _and7 (vcond2, SC_buf, CDN_buf);
endmodule
`endcelldefine

`celldefine
module slclq2 (EN, D, SD, SC, CDN, Q, SO);
input EN, D, SD, SC, CDN;
output Q, SO;
wire notifier, not_EN, mux_out, SC_buf, CDN_buf, vcond1, vcond2;
reg notifier;
   not not0 (not_EN, EN);
   U_MUX_2_1 U_MUX_2_11 (mux_out, D, SD, SC);
   U_LD_P_RB_NO U_LD_P_RB_NO2 (Q, mux_out, not_EN, CDN, notifier);
   U_LD_P_NO U_LD_P_NO3 (SO, Q, EN, notifier);
   buf buf4 (SC_buf, SC);
   buf buf5 (CDN_buf, CDN);
   and _and6 (vcond1, SC_buf, CDN_buf);
   and _and7 (vcond2, SC_buf, CDN_buf);
endmodule
`endcelldefine

`celldefine
module slclq4 (EN, D, SD, SC, CDN, Q, SO);
input EN, D, SD, SC, CDN;
output Q, SO;
wire notifier, not_EN, mux_out, SC_buf, CDN_buf, vcond1, vcond2;
reg notifier;
   not not0 (not_EN, EN);
   U_MUX_2_1 U_MUX_2_11 (mux_out, D, SD, SC);
   U_LD_P_RB_NO U_LD_P_RB_NO2 (Q, mux_out, not_EN, CDN, notifier);
   U_LD_P_NO U_LD_P_NO3 (SO, Q, EN, notifier);
   buf buf4 (SC_buf, SC);
   buf buf5 (CDN_buf, CDN);
   and _and6 (vcond1, SC_buf, CDN_buf);
   and _and7 (vcond2, SC_buf, CDN_buf);
endmodule
`endcelldefine

`celldefine
module s_decfq1 (Q, CPN, ENN, CDN, D, notifier);
input CPN, ENN, CDN, D, notifier;
output Q;
wire _mux1;
   _DFF _dff0 (1'b0, !CDN, !CPN, _mux1, Q);
   _MUX _mux1 (ENN, D, Q, _mux1);
endmodule
`endcelldefine

`celldefine
module decfq1 (CPN, CDN, D, ENN, Q);
input CPN, CDN, D, ENN;
output Q;
wire CPN_buf, CDN_buf, D_buf, ENN_buf, BOOL_OUT, _or5, _and4, notifier,
       vcond1;
reg notifier;
   buf buf0 (CPN_buf, CPN);
   buf buf1 (CDN_buf, CDN);
   buf buf2 (D_buf, D);
   buf buf3 (ENN_buf, ENN);
   and _and4 (_and4, !ENN_buf, D_buf, !ENN_buf);
   or _or5 (_or5, !Q, !ENN_buf);
   or _or6 (BOOL_OUT, _and4, !_or5);
   s_decfq1 s_decfq17 (Q, CPN, ENN, CDN, D, notifier);
   and _and8 (vcond1, CDN_buf, ENN_buf);
endmodule
`endcelldefine

`celldefine
module s_decfq2 (Q, CPN, ENN, CDN, D, notifier);
input CPN, ENN, CDN, D, notifier;
output Q;
wire _mux1;
   _DFF _dff0 (1'b0, !CDN, !CPN, _mux1, Q);
   _MUX _mux1 (ENN, D, Q, _mux1);
endmodule
`endcelldefine

`celldefine
module decfq2 (CPN, CDN, D, ENN, Q);
input CPN, CDN, D, ENN;
output Q;
wire CPN_buf, CDN_buf, D_buf, ENN_buf, BOOL_OUT, _or5, _and4, notifier,
       vcond1;
reg notifier;
   buf buf0 (CPN_buf, CPN);
   buf buf1 (CDN_buf, CDN);
   buf buf2 (D_buf, D);
   buf buf3 (ENN_buf, ENN);
   and _and4 (_and4, !ENN_buf, D_buf, !ENN_buf);
   or _or5 (_or5, !Q, !ENN_buf);
   or _or6 (BOOL_OUT, _and4, !_or5);
   s_decfq2 s_decfq27 (Q, CPN, ENN, CDN, D, notifier);
   and _and8 (vcond1, CDN_buf, ENN_buf);
endmodule
`endcelldefine

`celldefine
module U_FD_N_R_S_NO_QN (QN, D, CP, R, S, NOTIFIER_REG);
input D, CP, R, S, NOTIFIER_REG;
output QN;
   _DFF _dff0 (R, S, !CP, !D, QN);
endmodule
`endcelldefine

`celldefine
module U_FD_P_RB_SB_NO (Q, D, CP, RB, SB, NOTIFIER_REG);
input D, CP, RB, SB, NOTIFIER_REG;
output Q;
   _DFF _dff0 (!SB, !RB, CP, D, Q);
endmodule
`endcelldefine

`celldefine
module sdbrb2 (D, SD, SC, CP, SDN, CDN, Q, QN);
input D, SD, SC, CP, SDN, CDN;
output Q, QN;
wire notifier, mux_out, not_CP, not_CDN, not_SDN, SC_buf, SDN_buf, CDN_buf,
       vcond1, vcond2, vcond3;
reg notifier;
   U_FD_N_R_S_NO_QN U_FD_N_R_S_NO_QN0 (QN, mux_out, not_CP, not_CDN, not_SDN,
          notifier);
   U_FD_P_RB_SB_NO U_FD_P_RB_SB_NO1 (Q, mux_out, CP, CDN, SDN, notifier);
   U_MUX_2_1 U_MUX_2_12 (mux_out, D, SD, SC);
   not not3 (not_CP, CP);
   not not4 (not_SDN, SDN);
   not not5 (not_CDN, CDN);
   buf buf6 (SC_buf, SC);
   buf buf7 (SDN_buf, SDN);
   buf buf8 (CDN_buf, CDN);
   and _and9 (vcond1, SC_buf, SDN_buf, CDN_buf);
   and _and10 (vcond2, SDN_buf, CDN_buf);
   and _and11 (vcond3, SC_buf, SDN_buf, CDN_buf);
endmodule
`endcelldefine

`celldefine
module sdbrb1 (D, SD, SC, CP, SDN, CDN, Q, QN);
input D, SD, SC, CP, SDN, CDN;
output Q, QN;
wire notifier, mux_out, not_CP, not_CDN, not_SDN, SC_buf, SDN_buf, CDN_buf,
       vcond1, vcond2, vcond3;
reg notifier;
   U_FD_N_R_S_NO_QN U_FD_N_R_S_NO_QN0 (QN, mux_out, not_CP, not_CDN, not_SDN,
          notifier);
   U_FD_P_RB_SB_NO U_FD_P_RB_SB_NO1 (Q, mux_out, CP, CDN, SDN, notifier);
   U_MUX_2_1 U_MUX_2_12 (mux_out, D, SD, SC);
   not not3 (not_CP, CP);
   not not4 (not_SDN, SDN);
   not not5 (not_CDN, CDN);
   buf buf6 (SC_buf, SC);
   buf buf7 (SDN_buf, SDN);
   buf buf8 (CDN_buf, CDN);
   and _and9 (vcond1, SC_buf, SDN_buf, CDN_buf);
   and _and10 (vcond2, SDN_buf, CDN_buf);
   and _and11 (vcond3, SC_buf, SDN_buf, CDN_buf);
endmodule
`endcelldefine

`celldefine
module U_LD_P_SB_RB_QN_NO (QN, D, CK, RB, SB, NOTIFIER_REG);
input D, CK, RB, SB, NOTIFIER_REG;
output QN;
   _DLAT _dlat0 (!RB, !SB, CK, !D, QN);
endmodule
`endcelldefine

`celldefine
module U_LD_P_SB_RB_NO (Q, D, G, RB, SB, NOTI_REG);
input D, G, RB, SB, NOTI_REG;
output Q;
   _DLAT _dlat0 (!SB, !RB, G, D, Q);
endmodule
`endcelldefine

`celldefine
module labhb2 (E, D, CDN, SDN, Q, QN);
input E, D, CDN, SDN;
output Q, QN;
wire notifier, CDN_buf, SDN_buf, vcond1;
reg notifier;
   U_LD_P_SB_RB_QN_NO U_LD_P_SB_RB_QN_NO0 (QN, D, E, CDN, SDN, notifier);
   U_LD_P_SB_RB_NO U_LD_P_SB_RB_NO1 (Q, D, E, CDN, SDN, notifier);
   buf buf2 (CDN_buf, CDN);
   buf buf3 (SDN_buf, SDN);
   and _and4 (vcond1, CDN_buf, SDN_buf);
endmodule
`endcelldefine

`celldefine
module labhb1 (E, D, CDN, SDN, Q, QN);
input E, D, CDN, SDN;
output Q, QN;
wire notifier, CDN_buf, SDN_buf, vcond1;
reg notifier;
   U_LD_P_SB_RB_QN_NO U_LD_P_SB_RB_QN_NO0 (QN, D, E, CDN, SDN, notifier);
   U_LD_P_SB_RB_NO U_LD_P_SB_RB_NO1 (Q, D, E, CDN, SDN, notifier);
   buf buf2 (CDN_buf, CDN);
   buf buf3 (SDN_buf, SDN);
   and _and4 (vcond1, CDN_buf, SDN_buf);
endmodule
`endcelldefine

`celldefine
module s_jkbrb2_qn (QN, J, K, CP, RB, SB, NOTIFIER_REG);
input J, K, CP, RB, SB, NOTIFIER_REG;
output QN;
wire _mux1;
   _DFF _dff0 (!RB, !SB, CP, _mux1, QN);
   _MUX _mux1 (QN, K, !J, _mux1);
endmodule
`endcelldefine

`celldefine
module s_jkbrb2_q (Q, J, K, CP, RB, SB, NOTIFIER_REG);
input J, K, CP, RB, SB, NOTIFIER_REG;
output Q;
wire _mux1;
   _DFF _dff0 (!SB, !RB, CP, _mux1, Q);
   _MUX _mux1 (Q, J, !K, _mux1);
endmodule
`endcelldefine

`celldefine
module jkbrb2 (J, KZ, CP, Q, QN, SDN, CDN);
input J, KZ, CP, SDN, CDN;
output Q, QN;
wire notifier, not_KZ, not_CP, SDN_buf, CDN_buf, vcond1;
reg notifier;
   s_jkbrb2_qn s_jkbrb2_qn0 (QN, J, not_KZ, CP, CDN, SDN, notifier);
   s_jkbrb2_q s_jkbrb2_q1 (Q, J, not_KZ, CP, CDN, SDN, notifier);
   not not2 (not_KZ, KZ);
   not not3 (not_CP, CP);
   buf buf4 (SDN_buf, SDN);
   buf buf5 (CDN_buf, CDN);
   and _and6 (vcond1, SDN_buf, CDN_buf);
endmodule
`endcelldefine

`celldefine
module s_jkbrb1_qn (QN, J, K, CP, RB, SB, NOTIFIER_REG);
input J, K, CP, RB, SB, NOTIFIER_REG;
output QN;
wire _mux1;
   _DFF _dff0 (!RB, !SB, CP, _mux1, QN);
   _MUX _mux1 (QN, K, !J, _mux1);
endmodule
`endcelldefine

`celldefine
module s_jkbrb1_q (Q, J, K, CP, RB, SB, NOTIFIER_REG);
input J, K, CP, RB, SB, NOTIFIER_REG;
output Q;
wire _mux1;
   _DFF _dff0 (!SB, !RB, CP, _mux1, Q);
   _MUX _mux1 (Q, J, !K, _mux1);
endmodule
`endcelldefine

`celldefine
module jkbrb1 (J, KZ, CP, Q, QN, SDN, CDN);
input J, KZ, CP, SDN, CDN;
output Q, QN;
wire notifier, not_KZ, not_CP, SDN_buf, CDN_buf, vcond1;
reg notifier;
   s_jkbrb1_qn s_jkbrb1_qn0 (QN, J, not_KZ, CP, CDN, SDN, notifier);
   s_jkbrb1_q s_jkbrb1_q1 (Q, J, not_KZ, CP, CDN, SDN, notifier);
   not not2 (not_KZ, KZ);
   not not3 (not_CP, CP);
   buf buf4 (SDN_buf, SDN);
   buf buf5 (CDN_buf, CDN);
   and _and6 (vcond1, SDN_buf, CDN_buf);
endmodule
`endcelldefine

`celldefine
module dfbrb2 (D, CP, SDN, CDN, Q, QN);
input D, CP, SDN, CDN;
output Q, QN;
wire notifier, not_CP, not_CDN, not_SDN, SDN_buf, CDN_buf, vcond1;
reg notifier;
   U_FD_N_R_S_NO_QN U_FD_N_R_S_NO_QN0 (QN, D, not_CP, not_CDN, not_SDN,
          notifier);
   U_FD_P_RB_SB_NO U_FD_P_RB_SB_NO1 (Q, D, CP, CDN, SDN, notifier);
   not not2 (not_CP, CP);
   not not3 (not_SDN, SDN);
   not not4 (not_CDN, CDN);
   buf buf5 (SDN_buf, SDN);
   buf buf6 (CDN_buf, CDN);
   and _and7 (vcond1, SDN_buf, CDN_buf);
endmodule
`endcelldefine

`celldefine
module dfbrb1 (D, CP, SDN, CDN, Q, QN);
input D, CP, SDN, CDN;
output Q, QN;
wire notifier, not_CP, not_CDN, not_SDN, SDN_buf, CDN_buf, vcond1;
reg notifier;
   U_FD_N_R_S_NO_QN U_FD_N_R_S_NO_QN0 (QN, D, not_CP, not_CDN, not_SDN,
          notifier);
   U_FD_P_RB_SB_NO U_FD_P_RB_SB_NO1 (Q, D, CP, CDN, SDN, notifier);
   not not2 (not_CP, CP);
   not not3 (not_SDN, SDN);
   not not4 (not_CDN, CDN);
   buf buf5 (SDN_buf, SDN);
   buf buf6 (CDN_buf, CDN);
   and _and7 (vcond1, SDN_buf, CDN_buf);
endmodule
`endcelldefine

`celldefine
module U_FD_N_RB_SB_NO (Q, D, CP, RB, SB, NOTIFY_REG);
input D, CP, RB, SB, NOTIFY_REG;
output Q;
   _DFF _dff0 (!SB, !RB, !CP, D, Q);
endmodule
`endcelldefine

`celldefine
module dfbfb2 (D, CPN, SDN, CDN, Q, QN);
input D, CPN, SDN, CDN;
output Q, QN;
wire notifier, not_CDN, not_SDN, SDN_buf, CDN_buf, vcond1;
reg notifier;
   U_FD_N_R_S_NO_QN U_FD_N_R_S_NO_QN0 (QN, D, CPN, not_CDN, not_SDN, notifier);
   U_FD_N_RB_SB_NO U_FD_N_RB_SB_NO1 (Q, D, CPN, CDN, SDN, notifier);
   not not2 (not_SDN, SDN);
   not not3 (not_CDN, CDN);
   buf buf4 (SDN_buf, SDN);
   buf buf5 (CDN_buf, CDN);
   and _and6 (vcond1, SDN_buf, CDN_buf);
endmodule
`endcelldefine

`celldefine
module dfbfb1 (D, CPN, SDN, CDN, Q, QN);
input D, CPN, SDN, CDN;
output Q, QN;
wire notifier, not_CDN, not_SDN, SDN_buf, CDN_buf, vcond1;
reg notifier;
   U_FD_N_R_S_NO_QN U_FD_N_R_S_NO_QN0 (QN, D, CPN, not_CDN, not_SDN, notifier);
   U_FD_N_RB_SB_NO U_FD_N_RB_SB_NO1 (Q, D, CPN, CDN, SDN, notifier);
   not not2 (not_SDN, SDN);
   not not3 (not_CDN, CDN);
   buf buf4 (SDN_buf, SDN);
   buf buf5 (CDN_buf, CDN);
   and _and6 (vcond1, SDN_buf, CDN_buf);
endmodule
`endcelldefine

`celldefine
module slbhb4 (E, SC, D, SD, CDN, SDN, Q, QN, SO);
input E, SC, D, SD, CDN, SDN;
output Q, QN, SO;
wire notifier, mux_out, SC_buf, CDN_buf, SDN_buf, vcond1, vcond2, vcond3;
reg notifier;
   U_MUX_2_1 U_MUX_2_10 (mux_out, D, SD, SC);
   U_LD_P_SB_RB_QN_NO U_LD_P_SB_RB_QN_NO1 (QN, mux_out, E, CDN, SDN, notifier);
   U_LD_P_SB_RB_NO U_LD_P_SB_RB_NO2 (Q, mux_out, E, CDN, SDN, notifier);
   U_LD_N_NO U_LD_N_NO3 (SO, Q, E, notifier);
   buf buf4 (SC_buf, SC);
   buf buf5 (CDN_buf, CDN);
   buf buf6 (SDN_buf, SDN);
   and _and7 (vcond1, SC_buf, SDN_buf, CDN_buf);
   and _and8 (vcond2, SDN_buf, CDN_buf);
   and _and9 (vcond3, SC_buf, SDN_buf, CDN_buf);
endmodule
`endcelldefine

`celldefine
module slbhb2 (E, SC, D, SD, CDN, SDN, Q, QN, SO);
input E, SC, D, SD, CDN, SDN;
output Q, QN, SO;
wire notifier, mux_out, SC_buf, CDN_buf, SDN_buf, vcond1, vcond2, vcond3;
reg notifier;
   U_MUX_2_1 U_MUX_2_10 (mux_out, D, SD, SC);
   U_LD_P_SB_RB_QN_NO U_LD_P_SB_RB_QN_NO1 (QN, mux_out, E, CDN, SDN, notifier);
   U_LD_P_SB_RB_NO U_LD_P_SB_RB_NO2 (Q, mux_out, E, CDN, SDN, notifier);
   U_LD_N_NO U_LD_N_NO3 (SO, Q, E, notifier);
   buf buf4 (SC_buf, SC);
   buf buf5 (CDN_buf, CDN);
   buf buf6 (SDN_buf, SDN);
   and _and7 (vcond1, SC_buf, SDN_buf, CDN_buf);
   and _and8 (vcond2, SDN_buf, CDN_buf);
   and _and9 (vcond3, SC_buf, SDN_buf, CDN_buf);
endmodule
`endcelldefine

`celldefine
module slbhb1 (E, SC, D, SD, CDN, SDN, Q, QN, SO);
input E, SC, D, SD, CDN, SDN;
output Q, QN, SO;
wire notifier, mux_out, SC_buf, CDN_buf, SDN_buf, vcond1, vcond2, vcond3;
reg notifier;
   U_MUX_2_1 U_MUX_2_10 (mux_out, D, SD, SC);
   U_LD_P_SB_RB_QN_NO U_LD_P_SB_RB_QN_NO1 (QN, mux_out, E, CDN, SDN, notifier);
   U_LD_P_SB_RB_NO U_LD_P_SB_RB_NO2 (Q, mux_out, E, CDN, SDN, notifier);
   U_LD_N_NO U_LD_N_NO3 (SO, Q, E, notifier);
   buf buf4 (SC_buf, SC);
   buf buf5 (CDN_buf, CDN);
   buf buf6 (SDN_buf, SDN);
   and _and7 (vcond1, SC_buf, SDN_buf, CDN_buf);
   and _and8 (vcond2, SDN_buf, CDN_buf);
   and _and9 (vcond3, SC_buf, SDN_buf, CDN_buf);
endmodule
`endcelldefine

`celldefine
module skbrb4 (J, KZ, SD, SC, CP, Q, QN, SDN, CDN);
input J, KZ, SD, SC, CP, SDN, CDN;
output Q, QN;
wire temp, not_J, not_KZ, not_temp_2, temp_2, notifier, not_SD, not_CP,
       not_CDN, not_SDN, SDN_buf, CDN_buf, SC_buf, vcond1, vcond2, vcond3;
reg notifier;
   U_MUX_2_1 U_MUX_2_10 (temp, not_J, not_KZ, Q);
   not not1 (not_temp_2, temp_2);
   U_MUX_2_1 U_MUX_2_12 (temp_2, temp, not_SD, SC);
   U_FD_N_R_S_NO_QN U_FD_N_R_S_NO_QN3 (QN, not_temp_2, not_CP, not_CDN,
          not_SDN, notifier);
   U_FD_P_RB_SB_NO U_FD_P_RB_SB_NO4 (Q, not_temp_2, CP, CDN, SDN, notifier);
   not not5 (not_J, J);
   not not6 (not_KZ, KZ);
   not not7 (not_SD, SD);
   not not8 (not_SDN, SDN);
   not not9 (not_CDN, CDN);
   not not10 (not_CP, CP);
   buf buf11 (SDN_buf, SDN);
   buf buf12 (CDN_buf, CDN);
   buf buf13 (SC_buf, SC);
   and _and14 (vcond1, SC_buf, SDN_buf, CDN_buf);
   and _and15 (vcond2, SDN_buf, CDN_buf);
   and _and16 (vcond3, SC_buf, SDN_buf, CDN_buf);
endmodule
`endcelldefine

`celldefine
module skbrb2 (J, KZ, SD, SC, CP, Q, QN, SDN, CDN);
input J, KZ, SD, SC, CP, SDN, CDN;
output Q, QN;
wire temp, not_J, not_KZ, not_temp_2, temp_2, notifier, not_SD, not_CP,
       not_CDN, not_SDN, SDN_buf, CDN_buf, SC_buf, vcond1, vcond2, vcond3;
reg notifier;
   U_MUX_2_1 U_MUX_2_10 (temp, not_J, not_KZ, Q);
   not not1 (not_temp_2, temp_2);
   U_MUX_2_1 U_MUX_2_12 (temp_2, temp, not_SD, SC);
   U_FD_N_R_S_NO_QN U_FD_N_R_S_NO_QN3 (QN, not_temp_2, not_CP, not_CDN,
          not_SDN, notifier);
   U_FD_P_RB_SB_NO U_FD_P_RB_SB_NO4 (Q, not_temp_2, CP, CDN, SDN, notifier);
   not not5 (not_J, J);
   not not6 (not_KZ, KZ);
   not not7 (not_SD, SD);
   not not8 (not_SDN, SDN);
   not not9 (not_CDN, CDN);
   not not10 (not_CP, CP);
   buf buf11 (SDN_buf, SDN);
   buf buf12 (CDN_buf, CDN);
   buf buf13 (SC_buf, SC);
   and _and14 (vcond1, SC_buf, SDN_buf, CDN_buf);
   and _and15 (vcond2, SDN_buf, CDN_buf);
   and _and16 (vcond3, SC_buf, SDN_buf, CDN_buf);
endmodule
`endcelldefine

`celldefine
module skbrb1 (J, KZ, SD, SC, CP, Q, QN, SDN, CDN);
input J, KZ, SD, SC, CP, SDN, CDN;
output Q, QN;
wire temp, not_J, not_KZ, not_temp_2, temp_2, notifier, not_SD, not_CP,
       not_CDN, not_SDN, SDN_buf, CDN_buf, SC_buf, vcond1, vcond2, vcond3;
reg notifier;
   U_MUX_2_1 U_MUX_2_10 (temp, not_J, not_KZ, Q);
   not not1 (not_temp_2, temp_2);
   U_MUX_2_1 U_MUX_2_12 (temp_2, temp, not_SD, SC);
   U_FD_N_R_S_NO_QN U_FD_N_R_S_NO_QN3 (QN, not_temp_2, not_CP, not_CDN,
          not_SDN, notifier);
   U_FD_P_RB_SB_NO U_FD_P_RB_SB_NO4 (Q, not_temp_2, CP, CDN, SDN, notifier);
   not not5 (not_J, J);
   not not6 (not_KZ, KZ);
   not not7 (not_SD, SD);
   not not8 (not_SDN, SDN);
   not not9 (not_CDN, CDN);
   not not10 (not_CP, CP);
   buf buf11 (SDN_buf, SDN);
   buf buf12 (CDN_buf, CDN);
   buf buf13 (SC_buf, SC);
   and _and14 (vcond1, SC_buf, SDN_buf, CDN_buf);
   and _and15 (vcond2, SDN_buf, CDN_buf);
   and _and16 (vcond3, SC_buf, SDN_buf, CDN_buf);
endmodule
`endcelldefine

`celldefine
module sdbrb4 (D, SD, SC, CP, SDN, CDN, Q, QN);
input D, SD, SC, CP, SDN, CDN;
output Q, QN;
wire notifier, mux_out, not_CP, not_CDN, not_SDN, SC_buf, SDN_buf, CDN_buf,
       vcond1, vcond2, vcond3;
reg notifier;
   U_FD_N_R_S_NO_QN U_FD_N_R_S_NO_QN0 (QN, mux_out, not_CP, not_CDN, not_SDN,
          notifier);
   U_FD_P_RB_SB_NO U_FD_P_RB_SB_NO1 (Q, mux_out, CP, CDN, SDN, notifier);
   U_MUX_2_1 U_MUX_2_12 (mux_out, D, SD, SC);
   not not3 (not_CP, CP);
   not not4 (not_SDN, SDN);
   not not5 (not_CDN, CDN);
   buf buf6 (SC_buf, SC);
   buf buf7 (SDN_buf, SDN);
   buf buf8 (CDN_buf, CDN);
   and _and9 (vcond1, SC_buf, SDN_buf, CDN_buf);
   and _and10 (vcond2, SDN_buf, CDN_buf);
   and _and11 (vcond3, SC_buf, SDN_buf, CDN_buf);
endmodule
`endcelldefine

`celldefine
module sdbfb4 (D, SD, SC, CPN, SDN, CDN, Q, QN);
input D, SD, SC, CPN, SDN, CDN;
output Q, QN;
wire notifier, mux_out, not_CDN, not_SDN, not_CPN, SC_buf, SDN_buf, CDN_buf,
       vcond1, vcond2, vcond3;
reg notifier;
   U_FD_N_R_S_NO_QN U_FD_N_R_S_NO_QN0 (QN, mux_out, CPN, not_CDN, not_SDN,
          notifier);
   U_FD_N_RB_SB_NO U_FD_N_RB_SB_NO1 (Q, mux_out, CPN, CDN, SDN, notifier);
   U_MUX_2_1 U_MUX_2_12 (mux_out, D, SD, SC);
   not not3 (not_CPN, CPN);
   not not4 (not_SDN, SDN);
   not not5 (not_CDN, CDN);
   buf buf6 (SC_buf, SC);
   buf buf7 (SDN_buf, SDN);
   buf buf8 (CDN_buf, CDN);
   and _and9 (vcond1, SC_buf, SDN_buf, CDN_buf);
   and _and10 (vcond2, SDN_buf, CDN_buf);
   and _and11 (vcond3, SC_buf, SDN_buf, CDN_buf);
endmodule
`endcelldefine

`celldefine
module sdbfb2 (D, SD, SC, CPN, SDN, CDN, Q, QN);
input D, SD, SC, CPN, SDN, CDN;
output Q, QN;
wire notifier, mux_out, not_CDN, not_SDN, not_CPN, SC_buf, SDN_buf, CDN_buf,
       vcond1, vcond2, vcond3;
reg notifier;
   U_FD_N_R_S_NO_QN U_FD_N_R_S_NO_QN0 (QN, mux_out, CPN, not_CDN, not_SDN,
          notifier);
   U_FD_N_RB_SB_NO U_FD_N_RB_SB_NO1 (Q, mux_out, CPN, CDN, SDN, notifier);
   U_MUX_2_1 U_MUX_2_12 (mux_out, D, SD, SC);
   not not3 (not_CPN, CPN);
   not not4 (not_SDN, SDN);
   not not5 (not_CDN, CDN);
   buf buf6 (SC_buf, SC);
   buf buf7 (SDN_buf, SDN);
   buf buf8 (CDN_buf, CDN);
   and _and9 (vcond1, SC_buf, SDN_buf, CDN_buf);
   and _and10 (vcond2, SDN_buf, CDN_buf);
   and _and11 (vcond3, SC_buf, SDN_buf, CDN_buf);
endmodule
`endcelldefine

`celldefine
module sdbfb1 (D, SD, SC, CPN, SDN, CDN, Q, QN);
input D, SD, SC, CPN, SDN, CDN;
output Q, QN;
wire notifier, mux_out, not_CDN, not_SDN, not_CPN, SC_buf, SDN_buf, CDN_buf,
       vcond1, vcond2, vcond3;
reg notifier;
   U_FD_N_R_S_NO_QN U_FD_N_R_S_NO_QN0 (QN, mux_out, CPN, not_CDN, not_SDN,
          notifier);
   U_FD_N_RB_SB_NO U_FD_N_RB_SB_NO1 (Q, mux_out, CPN, CDN, SDN, notifier);
   U_MUX_2_1 U_MUX_2_12 (mux_out, D, SD, SC);
   not not3 (not_CPN, CPN);
   not not4 (not_SDN, SDN);
   not not5 (not_CDN, CDN);
   buf buf6 (SC_buf, SC);
   buf buf7 (SDN_buf, SDN);
   buf buf8 (CDN_buf, CDN);
   and _and9 (vcond1, SC_buf, SDN_buf, CDN_buf);
   and _and10 (vcond2, SDN_buf, CDN_buf);
   and _and11 (vcond3, SC_buf, SDN_buf, CDN_buf);
endmodule
`endcelldefine

`celldefine
module labhb4 (E, D, CDN, SDN, Q, QN);
input E, D, CDN, SDN;
output Q, QN;
wire notifier, CDN_buf, SDN_buf, vcond1;
reg notifier;
   U_LD_P_SB_RB_QN_NO U_LD_P_SB_RB_QN_NO0 (QN, D, E, CDN, SDN, notifier);
   U_LD_P_SB_RB_NO U_LD_P_SB_RB_NO1 (Q, D, E, CDN, SDN, notifier);
   buf buf2 (CDN_buf, CDN);
   buf buf3 (SDN_buf, SDN);
   and _and4 (vcond1, CDN_buf, SDN_buf);
endmodule
`endcelldefine

`celldefine
module s_jkbrb4_qn (QN, J, K, CP, RB, SB, NOTIFIER_REG);
input J, K, CP, RB, SB, NOTIFIER_REG;
output QN;
wire _mux1;
   _DFF _dff0 (!RB, !SB, CP, _mux1, QN);
   _MUX _mux1 (QN, K, !J, _mux1);
endmodule
`endcelldefine

`celldefine
module s_jkbrb4_q (Q, J, K, CP, RB, SB, NOTIFIER_REG);
input J, K, CP, RB, SB, NOTIFIER_REG;
output Q;
wire _mux1;
   _DFF _dff0 (!SB, !RB, CP, _mux1, Q);
   _MUX _mux1 (Q, J, !K, _mux1);
endmodule
`endcelldefine

`celldefine
module jkbrb4 (J, KZ, CP, Q, QN, SDN, CDN);
input J, KZ, CP, SDN, CDN;
output Q, QN;
wire notifier, not_KZ, not_CP, SDN_buf, CDN_buf, vcond1;
reg notifier;
   s_jkbrb4_qn s_jkbrb4_qn0 (QN, J, not_KZ, CP, CDN, SDN, notifier);
   s_jkbrb4_q s_jkbrb4_q1 (Q, J, not_KZ, CP, CDN, SDN, notifier);
   not not2 (not_KZ, KZ);
   not not3 (not_CP, CP);
   buf buf4 (SDN_buf, SDN);
   buf buf5 (CDN_buf, CDN);
   and _and6 (vcond1, SDN_buf, CDN_buf);
endmodule
`endcelldefine

`celldefine
module dfbfb4 (D, CPN, SDN, CDN, Q, QN);
input D, CPN, SDN, CDN;
output Q, QN;
wire notifier, not_CDN, not_SDN, SDN_buf, CDN_buf, vcond1;
reg notifier;
   U_FD_N_R_S_NO_QN U_FD_N_R_S_NO_QN0 (QN, D, CPN, not_CDN, not_SDN, notifier);
   U_FD_N_RB_SB_NO U_FD_N_RB_SB_NO1 (Q, D, CPN, CDN, SDN, notifier);
   not not2 (not_SDN, SDN);
   not not3 (not_CDN, CDN);
   buf buf4 (SDN_buf, SDN);
   buf buf5 (CDN_buf, CDN);
   and _and6 (vcond1, SDN_buf, CDN_buf);
endmodule
`endcelldefine

`celldefine
module dfbrb4 (D, CP, SDN, CDN, Q, QN);
input D, CP, SDN, CDN;
output Q, QN;
wire notifier, not_CP, not_CDN, not_SDN, SDN_buf, CDN_buf, vcond1;
reg notifier;
   U_FD_N_R_S_NO_QN U_FD_N_R_S_NO_QN0 (QN, D, not_CP, not_CDN, not_SDN,
          notifier);
   U_FD_P_RB_SB_NO U_FD_P_RB_SB_NO1 (Q, D, CP, CDN, SDN, notifier);
   not not2 (not_CP, CP);
   not not3 (not_SDN, SDN);
   not not4 (not_CDN, CDN);
   buf buf5 (SDN_buf, SDN);
   buf buf6 (CDN_buf, CDN);
   and _and7 (vcond1, SDN_buf, CDN_buf);
endmodule
`endcelldefine

`celldefine
module invtda (I, ZN, EN);
input I, EN;
output ZN;
   notif0 notif00 (ZN, I, EN);
endmodule
`endcelldefine

`celldefine
module invtd7 (I, ZN, EN);
input I, EN;
output ZN;
   notif0 notif00 (ZN, I, EN);
endmodule
`endcelldefine

`celldefine
module invtd4 (I, ZN, EN);
input I, EN;
output ZN;
   notif0 notif00 (ZN, I, EN);
endmodule
`endcelldefine

`celldefine
module invtd2 (I, ZN, EN);
input I, EN;
output ZN;
   notif0 notif00 (ZN, I, EN);
endmodule
`endcelldefine

`celldefine
module invtd1 (I, ZN, EN);
input I, EN;
output ZN;
   notif0 notif00 (ZN, I, EN);
endmodule
`endcelldefine

`celldefine
module invbd4 (I, ZN);
input I;
output ZN;
   not not0 (ZN, I);
endmodule
`endcelldefine

`celldefine
module invbd2 (I, ZN);
input I;
output ZN;
   not not0 (ZN, I);
endmodule
`endcelldefine

`celldefine
module inv0da (I, ZN);
input I;
output ZN;
   not not0 (ZN, I);
endmodule
`endcelldefine

`celldefine
module inv0d7 (I, ZN);
input I;
output ZN;
   not not0 (ZN, I);
endmodule
`endcelldefine

`celldefine
module inv0d4 (I, ZN);
input I;
output ZN;
   not not0 (ZN, I);
endmodule
`endcelldefine

`celldefine
module inv0d2 (I, ZN);
input I;
output ZN;
   not not0 (ZN, I);
endmodule
`endcelldefine

`celldefine
module inv0d1 (I, ZN);
input I;
output ZN;
   not not0 (ZN, I);
endmodule
`endcelldefine

`celldefine
module inv0d0 (I, ZN);
input I;
output ZN;
   not not0 (ZN, I);
endmodule
`endcelldefine

`celldefine
module invbdk (I, ZN);
input I;
output ZN;
   not not0 (ZN, I);
endmodule
`endcelldefine

`celldefine
module invbd7 (I, ZN);
input I;
output ZN;
   not not0 (ZN, I);
endmodule
`endcelldefine

`celldefine
module invbda (I, ZN);
input I;
output ZN;
   not not0 (ZN, I);
endmodule
`endcelldefine

`celldefine
module invbdf (I, ZN);
input I;
output ZN;
   not not0 (ZN, I);
endmodule
`endcelldefine

`celldefine
module pt3t03 (PAD, OEN, I);
input OEN, I;
output PAD;
   bufif0 bufif00 (PAD, I, OEN);
endmodule
`endcelldefine

`celldefine
module pt3t02 (PAD, OEN, I);
input OEN, I;
output PAD;
   bufif0 bufif00 (PAD, I, OEN);
endmodule
`endcelldefine

`celldefine
module pt3t01 (PAD, OEN, I);
input OEN, I;
output PAD;
   bufif0 bufif00 (PAD, I, OEN);
endmodule
`endcelldefine

`celldefine
module pt3o03 (PAD, I);
input I;
output PAD;
   buf buf0 (PAD, I);
endmodule
`endcelldefine

`celldefine
module pt3o02 (PAD, I);
input I;
output PAD;
   buf buf0 (PAD, I);
endmodule
`endcelldefine

`celldefine
module pt3o01 (PAD, I);
input I;
output PAD;
   buf buf0 (PAD, I);
endmodule
`endcelldefine

`celldefine
module pt3b03 (PAD, OEN, I, CIN);
input OEN, I;
output CIN;
inout PAD;
   buf buf0 (CIN, PAD);
   bufif0 bufif01 (PAD, I, OEN);
endmodule
`endcelldefine

`celldefine
module pt3b02 (PAD, OEN, I, CIN);
input OEN, I;
output CIN;
inout PAD;
   buf buf0 (CIN, PAD);
   bufif0 bufif01 (PAD, I, OEN);
endmodule
`endcelldefine

`celldefine
module pt3b01 (PAD, OEN, I, CIN);
input OEN, I;
output CIN;
inout PAD;
   buf buf0 (CIN, PAD);
   bufif0 bufif01 (PAD, I, OEN);
endmodule
`endcelldefine

`celldefine
module pc3x13 (XIN, XOUT, Z, EN);
input XIN, EN;
output Z;
inout XOUT;
wire N2;
   not G2 (N2, EN);
   notif1 G3 (XOUT, XIN, N2);
   nand G5 (Z, XOUT, N2);
endmodule
`endcelldefine

`celldefine
module pc3x12 (XIN, XOUT, Z, EN);
input XIN, EN;
output Z;
inout XOUT;
wire N2;
   not G2 (N2, EN);
   notif1 G3 (XOUT, XIN, N2);
   nand G5 (Z, XOUT, N2);
endmodule
`endcelldefine

`celldefine
module pc3x11 (XIN, XOUT, Z, EN);
input XIN, EN;
output Z;
inout XOUT;
wire N2;
   not G2 (N2, EN);
   notif1 G3 (XOUT, XIN, N2);
   nand G5 (Z, XOUT, N2);
endmodule
`endcelldefine

`celldefine
module pc3t05 (PAD, OEN, I);
input OEN, I;
output PAD;
   bufif0 bufif00 (PAD, I, OEN);
endmodule
`endcelldefine

`celldefine
module pc3t04 (PAD, OEN, I);
input OEN, I;
output PAD;
   bufif0 bufif00 (PAD, I, OEN);
endmodule
`endcelldefine

`celldefine
module pc3b01 (PAD, OEN, I, CIN);
input OEN, I;
output CIN;
inout PAD;
   buf buf0 (CIN, PAD);
   bufif0 bufif01 (PAD, I, OEN);
endmodule
`endcelldefine

`celldefine
module pc3b02 (PAD, OEN, I, CIN);
input OEN, I;
output CIN;
inout PAD;
   buf buf0 (CIN, PAD);
   bufif0 bufif01 (PAD, I, OEN);
endmodule
`endcelldefine

`celldefine
module pc3b03 (PAD, OEN, I, CIN);
input OEN, I;
output CIN;
inout PAD;
   buf buf0 (CIN, PAD);
   bufif0 bufif01 (PAD, I, OEN);
endmodule
`endcelldefine

`celldefine
module pc3b04 (PAD, OEN, I, CIN);
input OEN, I;
output CIN;
inout PAD;
   buf buf0 (CIN, PAD);
   bufif0 bufif01 (PAD, I, OEN);
endmodule
`endcelldefine

`celldefine
module pc3b05 (PAD, OEN, I, CIN);
input OEN, I;
output CIN;
inout PAD;
   buf buf0 (CIN, PAD);
   bufif0 bufif01 (PAD, I, OEN);
endmodule
`endcelldefine

`celldefine
module pc3c01 (CCLK, CP);
input CCLK;
output CP;
   buf buf0 (CP, CCLK);
endmodule
`endcelldefine

`celldefine
module pc3d00 (PAD);
inout PAD;
wire DeadEnd;
   buf E0 (DeadEnd, PAD);
endmodule
`endcelldefine

`celldefine
module pc3d01 (PAD, CIN);
input PAD;
output CIN;
   buf buf0 (CIN, PAD);
endmodule
`endcelldefine

`celldefine
module pc3d10 (PAD);
inout PAD;
wire DeadEnd;
   buf E0 (DeadEnd, PAD);
endmodule
`endcelldefine

`celldefine
module pc3d11 (PAD, CIN);
input PAD;
output CIN;
   not not0 (CIN, PAD);
endmodule
`endcelldefine

`celldefine
module pc3d21 (PAD, CIN);
input PAD;
output CIN;
   buf buf0 (CIN, PAD);
endmodule
`endcelldefine

`celldefine
module pc3d31 (PAD, CIN);
input PAD;
output CIN;
   not not0 (CIN, PAD);
endmodule
`endcelldefine

`celldefine
module pc3o01 (PAD, I);
input I;
output PAD;
   buf buf0 (PAD, I);
endmodule
`endcelldefine

`celldefine
module pc3o02 (PAD, I);
input I;
output PAD;
   buf buf0 (PAD, I);
endmodule
`endcelldefine

`celldefine
module pc3o03 (PAD, I);
input I;
output PAD;
   buf buf0 (PAD, I);
endmodule
`endcelldefine

`celldefine
module pc3o04 (PAD, I);
input I;
output PAD;
   buf buf0 (PAD, I);
endmodule
`endcelldefine

`celldefine
module pc3o05 (PAD, I);
input I;
output PAD;
   buf buf0 (PAD, I);
endmodule
`endcelldefine

`celldefine
module pc3t01 (PAD, OEN, I);
input OEN, I;
output PAD;
   bufif0 bufif00 (PAD, I, OEN);
endmodule
`endcelldefine

`celldefine
module pc3t02 (PAD, OEN, I);
input OEN, I;
output PAD;
   bufif0 bufif00 (PAD, I, OEN);
endmodule
`endcelldefine

`celldefine
module pc3t03 (PAD, OEN, I);
input OEN, I;
output PAD;
   bufif0 bufif00 (PAD, I, OEN);
endmodule
`endcelldefine

`celldefine
module pt3t03u (PAD, OEN, I);
input OEN, I;
output PAD;
   _WBUF tri_0 (1'b1, PAD);
   bufif0 bufif01 (PAD, I, OEN);
endmodule
`endcelldefine

`celldefine
module pt3t03d (PAD, OEN, I);
input OEN, I;
output PAD;
   _WBUF tri_0 (1'b0, PAD);
   bufif0 bufif01 (PAD, I, OEN);
endmodule
`endcelldefine

`celldefine
module pt3t02u (PAD, OEN, I);
input OEN, I;
output PAD;
   _WBUF tri_0 (1'b1, PAD);
   bufif0 bufif01 (PAD, I, OEN);
endmodule
`endcelldefine

`celldefine
module pt3t02d (PAD, OEN, I);
input OEN, I;
output PAD;
   _WBUF tri_0 (1'b0, PAD);
   bufif0 bufif01 (PAD, I, OEN);
endmodule
`endcelldefine

`celldefine
module pt3t01u (PAD, OEN, I);
input OEN, I;
output PAD;
   _WBUF tri_0 (1'b1, PAD);
   bufif0 bufif01 (PAD, I, OEN);
endmodule
`endcelldefine

`celldefine
module pt3t01d (PAD, OEN, I);
input OEN, I;
output PAD;
   _WBUF tri_0 (1'b0, PAD);
   bufif0 bufif01 (PAD, I, OEN);
endmodule
`endcelldefine

`celldefine
module pt3b03u (PAD, OEN, I, CIN);
input OEN, I;
output CIN;
inout PAD;
   _WBUF tri_0 (1'b1, PAD);
   buf buf1 (CIN, PAD);
   bufif0 bufif02 (PAD, I, OEN);
endmodule
`endcelldefine

`celldefine
module pt3b03d (PAD, OEN, I, CIN);
input OEN, I;
output CIN;
inout PAD;
   _WBUF tri_0 (1'b0, PAD);
   buf buf1 (CIN, PAD);
   bufif0 bufif02 (PAD, I, OEN);
endmodule
`endcelldefine

`celldefine
module pt3b02u (PAD, OEN, I, CIN);
input OEN, I;
output CIN;
inout PAD;
   _WBUF tri_0 (1'b1, PAD);
   buf buf1 (CIN, PAD);
   bufif0 bufif02 (PAD, I, OEN);
endmodule
`endcelldefine

`celldefine
module pt3b02d (PAD, OEN, I, CIN);
input OEN, I;
output CIN;
inout PAD;
   _WBUF tri_0 (1'b0, PAD);
   buf buf1 (CIN, PAD);
   bufif0 bufif02 (PAD, I, OEN);
endmodule
`endcelldefine

`celldefine
module pt3b01u (PAD, OEN, I, CIN);
input OEN, I;
output CIN;
inout PAD;
   _WBUF tri_0 (1'b1, PAD);
   buf buf1 (CIN, PAD);
   bufif0 bufif02 (PAD, I, OEN);
endmodule
`endcelldefine

`celldefine
module pt3b01d (PAD, OEN, I, CIN);
input OEN, I;
output CIN;
inout PAD;
   _WBUF tri_0 (1'b0, PAD);
   buf buf1 (CIN, PAD);
   bufif0 bufif02 (PAD, I, OEN);
endmodule
`endcelldefine

`celldefine
module pc3t05u (PAD, OEN, I);
input OEN, I;
output PAD;
   _WBUF tri_0 (1'b1, PAD);
   bufif0 bufif01 (PAD, I, OEN);
endmodule
`endcelldefine

`celldefine
module pc3t05d (PAD, OEN, I);
input OEN, I;
output PAD;
   _WBUF tri_0 (1'b0, PAD);
   bufif0 bufif01 (PAD, I, OEN);
endmodule
`endcelldefine

`celldefine
module pc3t04u (PAD, OEN, I);
input OEN, I;
output PAD;
   _WBUF tri_0 (1'b1, PAD);
   bufif0 bufif01 (PAD, I, OEN);
endmodule
`endcelldefine

`celldefine
module pc3t04d (PAD, OEN, I);
input OEN, I;
output PAD;
   _WBUF tri_0 (1'b0, PAD);
   bufif0 bufif01 (PAD, I, OEN);
endmodule
`endcelldefine

`celldefine
module pc3b01d (PAD, OEN, I, CIN);
input OEN, I;
output CIN;
inout PAD;
   _WBUF tri_0 (1'b0, PAD);
   buf buf1 (CIN, PAD);
   bufif0 bufif02 (PAD, I, OEN);
endmodule
`endcelldefine

`celldefine
module pc3b01u (PAD, OEN, I, CIN);
input OEN, I;
output CIN;
inout PAD;
   _WBUF tri_0 (1'b1, PAD);
   buf buf1 (CIN, PAD);
   bufif0 bufif02 (PAD, I, OEN);
endmodule
`endcelldefine

`celldefine
module pc3b02d (PAD, OEN, I, CIN);
input OEN, I;
output CIN;
inout PAD;
   _WBUF tri_0 (1'b0, PAD);
   buf buf1 (CIN, PAD);
   bufif0 bufif02 (PAD, I, OEN);
endmodule
`endcelldefine

`celldefine
module pc3b02u (PAD, OEN, I, CIN);
input OEN, I;
output CIN;
inout PAD;
   _WBUF tri_0 (1'b1, PAD);
   buf buf1 (CIN, PAD);
   bufif0 bufif02 (PAD, I, OEN);
endmodule
`endcelldefine

`celldefine
module pc3b03d (PAD, OEN, I, CIN);
input OEN, I;
output CIN;
inout PAD;
   _WBUF tri_0 (1'b0, PAD);
   buf buf1 (CIN, PAD);
   bufif0 bufif02 (PAD, I, OEN);
endmodule
`endcelldefine

`celldefine
module pc3b03u (PAD, OEN, I, CIN);
input OEN, I;
output CIN;
inout PAD;
   _WBUF tri_0 (1'b1, PAD);
   buf buf1 (CIN, PAD);
   bufif0 bufif02 (PAD, I, OEN);
endmodule
`endcelldefine

`celldefine
module pc3b04d (PAD, OEN, I, CIN);
input OEN, I;
output CIN;
inout PAD;
   _WBUF tri_0 (1'b0, PAD);
   buf buf1 (CIN, PAD);
   bufif0 bufif02 (PAD, I, OEN);
endmodule
`endcelldefine

`celldefine
module pc3b04u (PAD, OEN, I, CIN);
input OEN, I;
output CIN;
inout PAD;
   _WBUF tri_0 (1'b1, PAD);
   buf buf1 (CIN, PAD);
   bufif0 bufif02 (PAD, I, OEN);
endmodule
`endcelldefine

`celldefine
module pc3b05d (PAD, OEN, I, CIN);
input OEN, I;
output CIN;
inout PAD;
   _WBUF tri_0 (1'b0, PAD);
   buf buf1 (CIN, PAD);
   bufif0 bufif02 (PAD, I, OEN);
endmodule
`endcelldefine

`celldefine
module pc3b05u (PAD, OEN, I, CIN);
input OEN, I;
output CIN;
inout PAD;
   _WBUF tri_0 (1'b1, PAD);
   buf buf1 (CIN, PAD);
   bufif0 bufif02 (PAD, I, OEN);
endmodule
`endcelldefine

`celldefine
module pc3d01d (PAD, CIN);
input PAD;
output CIN;
   _WBUF tri_0 (1'b0, PAD);
   buf buf1 (CIN, PAD);
endmodule
`endcelldefine

`celldefine
module pc3d01u (PAD, CIN);
input PAD;
output CIN;
   _WBUF tri_0 (1'b1, PAD);
   buf buf1 (CIN, PAD);
endmodule
`endcelldefine

`celldefine
module pc3d11d (PAD, CIN);
input PAD;
output CIN;
   _WBUF tri_0 (1'b0, PAD);
   not not1 (CIN, PAD);
endmodule
`endcelldefine

`celldefine
module pc3d11u (PAD, CIN);
input PAD;
output CIN;
   _WBUF tri_0 (1'b1, PAD);
   not not1 (CIN, PAD);
endmodule
`endcelldefine

`celldefine
module pc3d21d (PAD, CIN);
input PAD;
output CIN;
   _WBUF tri_0 (1'b0, PAD);
   buf buf1 (CIN, PAD);
endmodule
`endcelldefine

`celldefine
module pc3d21u (PAD, CIN);
input PAD;
output CIN;
   _WBUF tri_0 (1'b1, PAD);
   buf buf1 (CIN, PAD);
endmodule
`endcelldefine

`celldefine
module pc3d31d (PAD, CIN);
input PAD;
output CIN;
   _WBUF tri_0 (1'b0, PAD);
   not not1 (CIN, PAD);
endmodule
`endcelldefine

`celldefine
module pc3d31u (PAD, CIN);
input PAD;
output CIN;
   _WBUF tri_0 (1'b1, PAD);
   not not1 (CIN, PAD);
endmodule
`endcelldefine

`celldefine
module pc3t01d (PAD, OEN, I);
input OEN, I;
output PAD;
   _WBUF tri_0 (1'b0, PAD);
   bufif0 bufif01 (PAD, I, OEN);
endmodule
`endcelldefine

`celldefine
module pc3t01u (PAD, OEN, I);
input OEN, I;
output PAD;
   _WBUF tri_0 (1'b1, PAD);
   bufif0 bufif01 (PAD, I, OEN);
endmodule
`endcelldefine

`celldefine
module pc3t02d (PAD, OEN, I);
input OEN, I;
output PAD;
   _WBUF tri_0 (1'b0, PAD);
   bufif0 bufif01 (PAD, I, OEN);
endmodule
`endcelldefine

`celldefine
module pc3t02u (PAD, OEN, I);
input OEN, I;
output PAD;
   _WBUF tri_0 (1'b1, PAD);
   bufif0 bufif01 (PAD, I, OEN);
endmodule
`endcelldefine

`celldefine
module pc3t03d (PAD, OEN, I);
input OEN, I;
output PAD;
   _WBUF tri_0 (1'b0, PAD);
   bufif0 bufif01 (PAD, I, OEN);
endmodule
`endcelldefine

`celldefine
module pc3t03u (PAD, OEN, I);
input OEN, I;
output PAD;
   _WBUF tri_0 (1'b1, PAD);
   bufif0 bufif01 (PAD, I, OEN);
endmodule
`endcelldefine

`celldefine
module pvdi (VDD);
output VDD;
   pullup G2 (VDD);
endmodule
`endcelldefine

`celldefine
module pv0i (VSS);
output VSS;
   pulldown G2 (VSS);
endmodule
`endcelldefine

`celldefine
module pv0f (VSS);
output VSS;
   pulldown G2 (VSS);
endmodule
`endcelldefine

`celldefine
module pvde (VDDO);
output VDDO;
   pullup G2 (VDDO);
endmodule
`endcelldefine

`celldefine
module pv0e (VSSO);
output VSSO;
   pulldown G2 (VSSO);
endmodule
`endcelldefine

`celldefine
module pvdd (VDDQ);
output VDDQ;
   pullup G2 (VDDQ);
endmodule
`endcelldefine

`celldefine
module pv0d (VSSQ);
output VSSQ;
   pulldown G2 (VSSQ);
endmodule
`endcelldefine

`celldefine
module pvdc (VDDC);
output VDDC;
   pullup G2 (VDDC);
endmodule
`endcelldefine

`celldefine
module pv0c (VSSC);
output VSSC;
   pulldown G2 (VSSC);
endmodule
`endcelldefine

`celldefine
module pv0b (VSS);
output VSS;
   pulldown G2 (VSS);
endmodule
`endcelldefine

`celldefine
module pvda (VDDO);
output VDDO;
   pullup G2 (VDDO);
endmodule
`endcelldefine

`celldefine
module pv0a (VSSO);
output VSSO;
   pulldown G2 (VSSO);
endmodule
`endcelldefine

